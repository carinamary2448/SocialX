/**
 * SocialFish v3.0 - Main JavaScript Module
 * Handles global functionality and utilities
 */

console.log('[*] SocialFish v3.0 Main Module Loaded');

// Global namespace
window.SocialFish = {
    api: {
        base: '/',
        
        call: async function(endpoint, method = 'GET', data = null) {
            try {
                let options = {
                    method: method,
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    }
                };
                
                if (data && method !== 'GET') {
                    options.body = JSON.stringify(data);
                }
                
                const response = await fetch(this.base + endpoint, options);
                return await response.json();
            } catch (e) {
                console.error('[!] API Error:', e);
                return null;
            }
        }
    },
    
    ui: {
        /**
         * Show notification toast
         */
        notify: function(message, type = 'info', duration = 3000) {
            const toast = document.createElement('div');
            toast.className = `alert alert-${type} alert-dismissible fade show`;
            toast.innerHTML = `
                ${message}
                <button type="button" class="close" data-dismiss="alert">
                    <span>&times;</span>
                </button>
            `;
            
            const container = document.querySelector('.container-fluid') || document.body;
            container.insertBefore(toast, container.firstChild);
            
            if (duration > 0) {
                setTimeout(() => toast.remove(), duration);
            }
        },
        
        /**
         * Format bytes to human readable
         */
        formatBytes: function(bytes, decimals = 2) {
            if (bytes === 0) return '0 Bytes';
            const k = 1024;
            const dm = decimals < 0 ? 0 : decimals;
            const sizes = ['Bytes', 'KB', 'MB', 'GB'];
            const i = Math.floor(Math.log(bytes) / Math.log(k));
            return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
        },
        
        /**
         * Escape HTML special characters
         */
        escapeHtml: function(text) {
            const map = {
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            };
            return text.replace(/[&<>"']/g, m => map[m]);
        }
    },
    
    storage: {
        /**
         * Local storage wrapper with auto-JSON serialization
         */
        set: function(key, value) {
            localStorage.setItem(key, JSON.stringify(value));
        },
        
        get: function(key, defaultValue = null) {
            try {
                const item = localStorage.getItem(key);
                return item ? JSON.parse(item) : defaultValue;
            } catch (e) {
                return defaultValue;
            }
        },
        
        remove: function(key) {
            localStorage.removeItem(key);
        },
        
        clear: function() {
            localStorage.clear();
        }
    },
    
    security: {
        /**
         * Generate random token
         */
        generateToken: function(length = 32) {
            const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
            let token = '';
            for (let i = 0; i < length; i++) {
                token += chars.charAt(Math.floor(Math.random() * chars.length));
            }
            return token;
        },
        
        /**
         * Hash string using SHA256 (if available)
         */
        sha256: async function(text) {
            const encoder = new TextEncoder();
            const data = encoder.encode(text);
            const hashBuffer = await crypto.subtle.digest('SHA-256', data);
            const hashArray = Array.from(new Uint8Array(hashBuffer));
            return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
        }
    },
    
    time: {
        /**
         * Get current timestamp
         */
        now: function() {
            return Math.floor(Date.now() / 1000);
        },
        
        /**
         * Format timestamp to readable date
         */
        format: function(timestamp, format = 'short') {
            const date = new Date(timestamp * 1000);
            if (format === 'short') {
                return date.toLocaleString();
            } else if (format === 'iso') {
                return date.toISOString();
            }
            return date.toString();
        },
        
        /**
         * Get countdown timer
         */
        countdown: function(seconds) {
            return Math.max(0, seconds);
        }
    },
    
    log: {
        /**
         * Centralized logging
         */
        debug: function(msg, data = null) {
            console.debug('[DEBUG]', msg, data);
        },
        
        info: function(msg, data = null) {
            console.log('[INFO]', msg, data);
        },
        
        warn: function(msg, data = null) {
            console.warn('[WARN]', msg, data);
        },
        
        error: function(msg, data = null) {
            console.error('[ERROR]', msg, data);
        }
    }
};

// Page initialization
document.addEventListener('DOMContentLoaded', function() {
    SocialFish.log.info('Page loaded');
    
    // Initialize tooltips if Bootstrap is available
    if (typeof $ !== 'undefined' && $.fn.tooltip) {
        $('[data-toggle="tooltip"]').tooltip();
    }
});

console.log('[+] SocialFish Main Module Ready');
