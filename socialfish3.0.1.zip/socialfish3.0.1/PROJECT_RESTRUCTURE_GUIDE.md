# SocialFish Project Structure Reorganization

## Overview
The project has been reorganized to separate core functionality from utility scripts, enhance cloning features, and improve maintainability.

## Folder Structure

### Core Modules (`/core`)
Main functionality for SocialFish:
- **SocialFish.py** - Main Flask application
- **config.py** - Configuration settings
- **view.py** - Web interface
- **dbsf.py** - Database management
- **scansf.py** - Network scanning
- **clonesf.py** - Basic website cloning (legacy)
- **real_cloner.py** - Enhanced website cloning
- **page_analyzer.py** - Page structure analysis
- **genToken.py** - Token generation
- **sendMail.py** - Email functionality
- **genReport.py** - Report generation
- **tracegeoIp.py** - GeoIP tracing
- **cleanFake.py** - Cleanup utilities
- **auth_flow_tester.py** - Authentication testing
- **advanced_attacks.py** - Advanced attack vectors
- **recorder_playwright.py** - Playwright recording
- **recorder_selenium.py** - Selenium recording
- **cookie_analyzer.py** - Cookie analysis
- **cookie_inspector.py** - Cookie inspection
- **tunnel_manager.py** - Tunnel management
- **webhook_manager.py** - Webhook management
- **mock_server.py** - Mock login server
- **db_migration.py** - Database migrations

### Enhanced Features (`/features/cloning`)
Advanced website cloning and lure management:
- **form_capture.py** - Advanced form data capture with CSRF token handling
  - `FormFieldAnalyzer` - Identify form field types (username, password, email, etc.)
  - `CsrfTokenExtractor` - Extract and preserve CSRF tokens
  - `FormDataCapture` - Comprehensive form data analysis
  - `FormInterceptor` - JavaScript interception code generation

- **lure_manager.py** - Template and lure management
  - `LureManager` - Create, save, and deploy templates
  - `LureTemplate` - Template data structure
  - Template deployment tracking
  - Template variations and versioning

- **dynamic_page_cloner.py** - JavaScript-rendered page cloning
  - `DynamicPageCloner` - Clone JavaScript-heavy websites
  - User interaction recording
  - Form detection on dynamic pages
  - Screenshot capture

- **asset_manager.py** - Enhanced asset handling
  - `AssetDownloader` - Download CSS, JS, images, fonts
  - Asset optimization and caching
  - `CdnAssetManager` - CDN fallback management
  - Tracking pixel injection

### Utilities & Scripts (`/utilities`)
Testing, debugging, and analysis scripts:

#### Testing Scripts
- automated_test.py
- automated_browser_test.py
- automated_browser_advanced.py
- final_comprehensive_tests.py
- comprehensive_test_and_browser.py

#### Debugging Scripts
- comprehensive_debug.py
- debug_report.txt
- server.stderr.log
- server.stdout.log

#### Analysis Scripts
- analyze_logging.py
- ui_bug_scanner.py
- critical_scanner.py
- PROJECT_ANALYSIS_FROM_MD_FILES.txt

#### Database & Schema
- check_schema.py
- check_and_fix_schema.py
- verify_schema.py
- verify_debug_logging.py
- fix_schema.py
- fix_data_capture.py

#### Cleanup & Maintenance
- cleanup_duplicates.py
- cleanup_route_duplicates.py

#### Audit Scripts
- comprehensive_bug_audit.py
- comprehensive_system_fixer.py
- final_system_verification.py

#### Decorators & Utilities
- auto_logging_decorator.py
- automation_master.py

#### Quick Tests
- quick_test_capture.py

### Template Directories
- `/templates/static` - Static assets
- `/templates/admin` - Admin templates
- `/templates/clones` - Cloned pages
- `/templates/lures` - Saved lure templates
- `/templates/fake` - Fake pages
- `/templates/custom.html` - Custom templates

### Documentation Files
- README.md
- QUICK_START.md
- FEATURES_v3.md
- CODE_OF_CONDUCT.md
- CONTRIBUTING.md
- LICENSE

## New Features

### 1. Advanced Form Capture (`form_capture.py`)
- **Smart field identification**: Automatically identifies username, password, email, phone, OTP, and CSRF fields
- **CSRF token preservation**: Detects and preserves CSRF tokens from multiple sources
- **Multi-step form support**: Detects and handles multi-step forms
- **Form interception**: JavaScript code to intercept and log form submissions
- **Keylogger integration**: Optional keylogger for tracking user input

Usage:
```python
from features.cloning import FormDataCapture

capture = FormDataCapture()
forms = capture.capture_form_data(html, base_url, clone_id)
```

### 2. Lure & Template Management (`lure_manager.py`)
- **Template creation**: Save cloned pages as reusable templates
- **Template deployment**: Deploy templates as active lures
- **Custom JS/CSS**: Add custom JavaScript and CSS to templates
- **Template variations**: Create variations of templates
- **Import/export**: Export and import templates for sharing

Usage:
```python
from features.cloning import LureManager

manager = LureManager()
result = manager.create_template(
    name="Facebook Login Lure",
    url="https://facebook.com",
    clone_id="fb_clone_123",
    tags=["facebook", "login"]
)
```

### 3. Dynamic Page Cloning (`dynamic_page_cloner.py`)
- **JavaScript rendering**: Clone JavaScript-heavy modern websites
- **Interaction recording**: Record user interactions for playback
- **Form detection**: Detect forms on rendered pages
- **Screenshot capture**: Save page screenshots
- **Request interception**: Log network requests

Usage:
```python
from features.cloning import clone_dynamic_page_sync

result = clone_dynamic_page_sync(
    url="https://example.com",
    wait_for_selector="body",
    wait_time=5000
)
```

### 4. Enhanced Asset Management (`asset_manager.py`)
- **Multi-type support**: Handle CSS, JS, images, fonts, and media
- **Automatic optimization**: Minimize CSS and JavaScript
- **Asset caching**: Cache downloaded assets
- **CDN fallbacks**: Provide fallback CDN URLs
- **Tracking injection**: Inject tracking pixels
- **Size limits**: Prevent downloading huge files

Usage:
```python
from features.cloning import AssetDownloader

downloader = AssetDownloader()
assets = downloader.download_assets_from_html(html, base_url, clone_path)
```

## Migration Guide

### Files to Move
The following files should be moved to `/utilities`:

**Testing:**
- automated_test.py
- automated_browser_test.py
- automated_browser_advanced.py
- final_comprehensive_tests.py
- comprehensive_test_and_browser.py
- quick_test_capture.py

**Debugging:**
- comprehensive_debug.py
- verify_debug_logging.py
- debug_report.txt
- server.*.log

**Analysis:**
- analyze_logging.py
- ui_bug_scanner.py
- critical_scanner.py

**Database:**
- check_schema.py
- check_and_fix_schema.py
- verify_schema.py
- fix_schema.py
- fix_data_capture.py

**Cleanup:**
- cleanup_duplicates.py
- cleanup_route_duplicates.py

**Audit:**
- comprehensive_bug_audit.py
- comprehensive_system_fixer.py
- final_system_verification.py

**Utilities:**
- auto_logging_decorator.py
- automation_master.py

### Core Files (Keep in root or /core)
- SocialFish.py
- core/*
- requirements.txt
- setup.py
- docker-compose.yml
- Dockerfile

### Documentation Files (Keep in root)
- README.md
- QUICK_START.md
- FEATURES_v3.md
- CODE_OF_CONDUCT.md
- CONTRIBUTING.md
- LICENSE

## Integration with SocialFish.py

To use the new features in SocialFish.py, add these imports:

```python
from features.cloning import (
    FormDataCapture,
    FormFieldAnalyzer,
    CsrfTokenExtractor,
    FormInterceptor,
    LureManager,
    LureTemplate,
    DynamicPageCloner,
    AssetDownloader,
    CdnAssetManager
)

# Initialize managers
lure_manager = LureManager()
form_capture = FormDataCapture()
asset_downloader = AssetDownloader()
```

## API Endpoints (Recommended)

### Form Capture
- POST `/api/forms/capture` - Receive captured form data
- GET `/api/forms/templates` - List form templates
- GET `/api/forms/templates/{id}` - Get form template details

### Lure Management
- POST `/api/lures/create` - Create new lure
- GET `/api/lures/list` - List lures
- GET `/api/lures/{id}` - Get lure details
- POST `/api/lures/{id}/deploy` - Deploy lure
- GET `/api/lures/{id}/stats` - Get lure statistics

### Dynamic Cloning
- POST `/api/clone/dynamic` - Clone dynamic page
- POST `/api/clone/record-interactions` - Record page interactions
- GET `/api/clone/{id}/preview` - Preview cloned page

### Assets
- GET `/api/assets/cdn/{library}` - Get CDN URL
- POST `/api/assets/optimize` - Optimize CSS/JS
- GET `/api/assets/cache/status` - Check cache status

## Benefits of Reorganization

1. **Maintainability**: Clearer separation of concerns
2. **Scalability**: Easy to add new features
3. **Testability**: Utilities isolated for testing
4. **Organization**: Logical grouping of related functionality
5. **Reusability**: Features can be imported independently
6. **Documentation**: Clear purpose of each module

## Next Steps

1. Move utility scripts to `/utilities` folder
2. Update imports in SocialFish.py
3. Add new API endpoints for enhanced features
4. Create web UI for template management
5. Add database migrations for new tables
6. Update tests and documentation
