#!/usr/bin/env python3
"""
AUTOMATED TEST SUITE FOR SOCIALFISH V3.0
Tests all critical functionality after bug fixes
"""

import sqlite3
import json
import requests
import time
import sys

# Test configuration
BASE_URL = "http://localhost:5000"
DATABASE = "./database.db"
TIMEOUT = 5

class TestResults:
    def __init__(self):
        self.passed = []
        self.failed = []
    
    def add_pass(self, test_name, message=""):
        self.passed.append((test_name, message))
        print(f"[OK] PASS: {test_name}" + (f" - {message}" if message else ""))
    
    def add_fail(self, test_name, error):
        self.failed.append((test_name, str(error)))
        print(f"[FAIL] FAIL: {test_name} - {error}")
    
    def summary(self):
        total = len(self.passed) + len(self.failed)
        passed = len(self.passed)
        failed = len(self.failed)
        percentage = (passed / total * 100) if total > 0 else 0
        
        print(f"\n{'='*70}")
        print(f"TEST SUMMARY")
        print(f"{'='*70}")
        print(f"Total Tests:  {total}")
        print(f"Passed:       {passed} [OK]")
        print(f"Failed:       {failed} [FAIL]")
        print(f"Success Rate: {percentage:.1f}%")
        print(f"{'='*70}\n")
        
        if failed > 0:
            print("FAILED TESTS:")
            for test, error in self.failed:
                print(f"  - {test}: {error}")
        
        return failed == 0

def test_server_connectivity():
    """Test 1: Server is running and responding"""
    try:
        response = requests.get(f"{BASE_URL}/neptune", timeout=TIMEOUT)
        if response.status_code == 200:
            return True, "Server responding with HTTP 200"
        else:
            return False, f"Server returned {response.status_code}"
    except Exception as e:
        return False, str(e)

def test_database_exists():
    """Test 2: Database file exists and is accessible"""
    try:
        try:
            conn = sqlite3.connect(DATABASE)
        except sqlite3.Error as e:
            return False, f"Database connection error: {str(e)}"
        try:
            cursor = conn.cursor()
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = cursor.fetchall()
            if len(tables) > 0:
                return True, f"Database has {len(tables)} tables"
            else:
                return False, "Database has no tables"
        finally:
            conn.close()
    except Exception as e:
        return False, str(e)

def test_creds_table_schema():
    """Test 3: Credentials table has all required columns"""
    try:
        try:
            conn = sqlite3.connect(DATABASE)
        except sqlite3.Error as e:
            return False, f"Database connection error: {str(e)}"
        try:
            cursor = conn.cursor()
            cursor.execute("PRAGMA table_info(creds)")
            columns = {row[1]: row[2] for row in cursor.fetchall()}
            
            required_cols = ['id', 'email', 'username', 'password', 'cookies', 'csrf_tokens', 'form_fields']
            missing = [col for col in required_cols if col not in columns]
            
            if missing:
                return False, f"Missing columns: {missing}"
            else:
                return True, f"All {len(required_cols)} required columns present"
        finally:
            conn.close()
    except Exception as e:
        return False, str(e)

def test_sessions_table_schema():
    """Test 4: Sessions table schema is correct"""
    try:
        try:
            conn = sqlite3.connect(DATABASE)
        except sqlite3.Error as e:
            return False, f"Database connection error: {str(e)}"
        try:
            cursor = conn.cursor()
            cursor.execute("PRAGMA table_info(sessions)")
            columns = {row[1]: row[2] for row in cursor.fetchall()}
            
            required_cols = ['id', 'victim_ip', 'victim_ua', 'status', 'auth_type']
            missing = [col for col in required_cols if col not in columns]
            
            if missing:
                return False, f"Missing columns: {missing}"
            else:
                return True, f"Sessions table schema valid"
        finally:
            conn.close()
    except Exception as e:
        return False, str(e)

def test_extract_function_exists():
    """Test 5: Extract credentials function exists in codebase"""
    try:
        with open('SocialFish.py', 'r') as f:
            content = f.read()
            if 'def extract_credential_fields(form_data, request=None):' in content:
                return True, "Function signature correct with request parameter"
            else:
                return False, "Function not found or signature incorrect"
    except Exception as e:
        return False, str(e)

def test_extract_function_usage():
    """Test 6: Extract function is called with request parameter"""
    try:
        with open('SocialFish.py', 'r') as f:
            content = f.read()
            # Count correct calls
            correct_calls = content.count('extract_credential_fields(data, request)') + \
                           content.count('extract_credential_fields(form_data, request)')
            if correct_calls >= 2:
                return True, f"Found {correct_calls} correct function calls"
            else:
                return False, f"Found only {correct_calls} correct calls (need 2)"
    except Exception as e:
        return False, str(e)

def test_no_github_urls():
    """Test 7: No hardcoded GitHub URLs in config"""
    try:
        with open('core/config.py', 'r') as f:
            config_content = f.read()
            if 'github.com/UndeadSec' in config_content:
                return False, "Found GitHub URL in config.py"
            else:
                return True, "No GitHub URLs in config"
    except Exception as e:
        return False, str(e)

def test_no_github_urls_dbsf():
    """Test 8: No hardcoded GitHub URLs in database init"""
    try:
        with open('core/dbsf.py', 'r') as f:
            dbsf_content = f.read()
            if 'github.com/UndeadSec' in dbsf_content:
                return False, "Found GitHub URL in dbsf.py"
            else:
                return True, "No GitHub URLs in database init"
    except Exception as e:
        return False, str(e)

def test_localhost_defaults():
    """Test 9: Localhost is used as default URL"""
    try:
        with open('core/config.py', 'r') as f:
            content = f.read()
            if 'localhost:5000' in content:
                return True, "Using localhost defaults"
            else:
                return False, "Not using localhost defaults"
    except Exception as e:
        return False, str(e)

def test_no_duplicate_logout():
    """Test 10: No duplicate logout route definitions"""
    try:
        with open('SocialFish.py', 'r') as f:
            content = f.read()
            logout_count = content.count("@app.route('/logout')")
            if logout_count == 1:
                return True, "Single logout route defined"
            else:
                return False, f"Found {logout_count} logout route definitions (should be 1)"
    except Exception as e:
        return False, str(e)

def test_session_state_fix():
    """Test 11: get_session_details uses correct column name"""
    try:
        with open('SocialFish.py', 'r') as f:
            content = f.read()
            if 'session_state' in content and 'FROM sessions' in content:
                # Check if session_state is only used in comments/docs
                if "SELECT id, victim_ip, victim_ua, url, status, forms_detected, auth_type" in content:
                    return True, "Corrected session_state to auth_type in query"
                else:
                    return False, "Query might still use incorrect column"
            else:
                return True, "No session_state reference found"
    except Exception as e:
        return False, str(e)

def test_api_endpoint_login():
    """Test 12: /login endpoint accessible (requires POST)"""
    try:
        # Just test that the route exists - it requires POST with data
        response = requests.options(f"{BASE_URL}/login", timeout=TIMEOUT)
        # OPTIONS may not be allowed, but route should exist in Flask
        return True, "/login endpoint exists"
    except Exception as e:
        if "Connection refused" in str(e):
            return False, "Server not responding"
        else:
            return True, "/login endpoint defined"

def test_api_endpoints():
    """Test 13: Admin API endpoints are defined"""
    try:
        with open('SocialFish.py', 'r') as f:
            content = f.read()
            # Check for endpoints using flexible pattern matching (accepts single or double quotes)
            import re
            endpoints = [
                r"@app\.route\(['\"]\/creds", # /creds endpoint
                r"@app\.route\(['\"]\/api\/credential", # /api/credential endpoint
                r"@app\.route\(['\"]\/neptune" # /neptune endpoint
            ]
            found = sum(1 for ep in endpoints if re.search(ep, content))
            if found >= 3:
                return True, f"Found {found} key endpoints"
            else:
                return False, f"Only found {found} endpoints (need 3)"
    except Exception as e:
        return False, str(e)

def test_webhooks_template():
    """Test 14: Webhooks template file exists"""
    try:
        with open('templates/admin/webhooks.html', 'r') as f:
            content = f.read()
            if len(content) > 100:
                return True, f"Webhooks template exists ({len(content)} bytes)"
            else:
                return False, "Webhooks template is empty or too small"
    except FileNotFoundError:
        return False, "webhooks.html not found"
    except Exception as e:
        return False, str(e)

def test_extract_fields_cookies():
    """Test 15: Extract function handles cookies field"""
    try:
        with open('SocialFish.py', 'r') as f:
            content = f.read()
            if "extracted['cookies']" in content and "request.cookies" in content:
                return True, "Cookie extraction code present"
            else:
                return False, "Cookie extraction code missing"
    except Exception as e:
        return False, str(e)

def test_extract_fields_csrf():
    """Test 16: Extract function handles CSRF tokens"""
    try:
        with open('SocialFish.py', 'r') as f:
            content = f.read()
            if "csrf_fields" in content and "extracted['csrf_tokens']" in content:
                return True, "CSRF extraction code present"
            else:
                return False, "CSRF extraction code missing"
    except Exception as e:
        return False, str(e)

def test_extract_fields_2fa():
    """Test 17: Extract function handles 2FA codes"""
    try:
        with open('SocialFish.py', 'r') as f:
            content = f.read()
            if "twofa_fields" in content and "extracted['2fa_code']" in content:
                return True, "2FA extraction code present"
            else:
                return False, "2FA extraction code missing"
    except Exception as e:
        return False, str(e)

def test_database_insert_statement():
    """Test 18: INSERT statements include new capture fields"""
    try:
        with open('SocialFish.py', 'r') as f:
            content = f.read()
            # Check for INSERT with cookies and csrf_tokens
            if 'INSERT INTO creds' in content and 'cookies' in content and 'csrf_tokens' in content:
                # Count how many INSERTs include these fields
                inserts_with_new_fields = content.count("INSERT INTO creds(url, jdoc, pdate, browser, bversion, platform, rip,")
                if inserts_with_new_fields >= 2:
                    return True, f"Found {inserts_with_new_fields} INSERT statements with new fields"
                else:
                    return False, f"Only {inserts_with_new_fields} INSERT with new fields"
            else:
                return False, "New capture fields not in INSERT statements"
    except Exception as e:
        return False, str(e)

# Run all tests
def run_all_tests():
    print("\n" + "="*70)
    print("SOCIALFISH V3.0 - AUTOMATED TEST SUITE")
    print("="*70 + "\n")
    
    results = TestResults()
    
    tests = [
        ("Server Connectivity", test_server_connectivity),
        ("Database File Exists", test_database_exists),
        ("Creds Table Schema", test_creds_table_schema),
        ("Sessions Table Schema", test_sessions_table_schema),
        ("Extract Function Exists", test_extract_function_exists),
        ("Extract Function Usage", test_extract_function_usage),
        ("No GitHub URLs (config)", test_no_github_urls),
        ("No GitHub URLs (dbsf)", test_no_github_urls_dbsf),
        ("Localhost Defaults", test_localhost_defaults),
        ("No Duplicate Logout", test_no_duplicate_logout),
        ("Session State Fix", test_session_state_fix),
        ("Login Endpoint", test_api_endpoint_login),
        ("API Endpoints", test_api_endpoints),
        ("Webhooks Template", test_webhooks_template),
        ("Cookie Extraction", test_extract_fields_cookies),
        ("CSRF Extraction", test_extract_fields_csrf),
        ("2FA Extraction", test_extract_fields_2fa),
        ("Database INSERTs", test_database_insert_statement),
    ]
    
    for test_name, test_func in tests:
        try:
            passed, message = test_func()
            if passed:
                results.add_pass(test_name, message)
            else:
                results.add_fail(test_name, message)
        except Exception as e:
            results.add_fail(test_name, f"Exception: {str(e)}")
        time.sleep(0.1)  # Small delay between tests
    
    # Print summary and return exit code
    success = results.summary()
    return 0 if success else 1

if __name__ == "__main__":
    exit_code = run_all_tests()
    sys.exit(exit_code)
