#!/usr/bin/env python3
"""Remove duplicate functions and fix GitHub URLs in SocialFish.py"""

import re

with open('SocialFish.py', 'r') as f:
    lines = f.readlines()

output_lines = []
function_counts = {}
duplicate_functions = [
    'logout', 'postConfigureApi', 'get_session_details', 'get_lures', 
    'api_get_sessions', 'checkKey', 'getStatics', 'getJson', 'postSendMail',
    'getTraceIpMob', 'getScanSfMob', 'getReportMob'
]

i = 0
while i < len(lines):
    line = lines[i]
    
    # Check if this line contains a function definition we need to track
    func_match = None
    for func_name in duplicate_functions:
        if f'def {func_name}(' in line:
            func_match = func_name
            break
    
    if func_match:
        if function_counts.get(func_match, 0) >= 1:
            # This is a duplicate - skip until next @app.route or @socketio or @login_manager
            skip_lines = 0
            i += 1
            while i < len(lines) and '@app.route' not in lines[i] and '@socketio' not in lines[i] and '@login_manager' not in lines[i]:
                skip_lines += 1
                i += 1
            print(f'Removed {skip_lines} lines of duplicate {func_match}()')
            continue
        else:
            function_counts[func_match] = function_counts.get(func_match, 0) + 1
            output_lines.append(line)
            i += 1
    
    else:
        # Replace GitHub URLs with localhost
        # GitHub URLs replaced with localhost defaults during migration
        output_lines.append(line)
        i += 1

# Write back
with open('SocialFish.py', 'w') as f:
    f.writelines(output_lines)

print('\n[OK] File cleaned successfully!')
print(f'Functions kept: {function_counts}')
print(f'Original lines: {len(lines)}')
print(f'New lines: {len(output_lines)}')
print(f'Lines removed: {len(lines) - len(output_lines)}')

