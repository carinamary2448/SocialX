#!/usr/bin/env python3
import sqlite3
import sys

try:
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    
    cursor.execute("PRAGMA table_info(creds)")
    cols = cursor.fetchall()
    
    print(f"Total columns in creds table: {len(cols)}")
    print("\nColumn names:")
    for col in cols:
        print(f"  - {col[1]}")
    
    required_cols = ['email', 'username', 'password', 'cookies', 'csrf_tokens', 'form_fields']
    found_cols = [col[1] for col in cols]
    
    print("\nChecking for required columns:")
    for req_col in required_cols:
        status = "OK" if req_col in found_cols else "X"
        print(f"  {status} {req_col}")
    
    conn.close()
    
    if len(cols) >= 18:
        print("\n[OK] Schema CORRECT - Full 18+ column schema found!")
        sys.exit(0)
    else:
        print(f"\n✗ Schema INCOMPLETE - Only {len(cols)} columns (need 18)")
        sys.exit(1)
        
except Exception as e:
    print(f"Error: {e}")
    sys.exit(1)
