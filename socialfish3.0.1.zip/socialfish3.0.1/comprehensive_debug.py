#!/usr/bin/env python3
"""
COMPREHENSIVE DEBUG & TEST SUITE FOR SOCIALFISH V3.0
Tests all functionality, verifies fixes, and generates detailed report
"""

import sqlite3
import json
import requests
import time
import sys
import os
import subprocess
import platform
import socket
from datetime import datetime
from pathlib import Path

# Configuration
BASE_URL = "http://localhost:5000"
DATABASE = "./database.db"
TIMEOUT = 10
REPORT_FILE = "debug_report.txt"

class DebugReport:
    """Comprehensive debug report generator"""
    def __init__(self):
        self.sections = []
        self.start_time = datetime.now()
        
    def add_section(self, title, content):
        """Add a section to report"""
        self.sections.append({
            "title": title,
            "content": content,
            "timestamp": datetime.now().isoformat()
        })
    
    def save(self, filename=REPORT_FILE):
        """Save report to file"""
        with open(filename, 'w', encoding='utf-8') as f:
            f.write("="*80 + "\n")
            f.write("SOCIALFISH V3.0 - COMPREHENSIVE DEBUG REPORT\n")
            f.write(f"Generated: {self.start_time.strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write("="*80 + "\n\n")
            
            for section in self.sections:
                f.write(f"\n{'='*80}\n")
                f.write(f"[{section['timestamp']}] {section['title']}\n")
                f.write(f"{'='*80}\n")
                if isinstance(section['content'], list):
                    for item in section['content']:
                        f.write(f"  {item}\n")
                else:
                    f.write(str(section['content']) + "\n")
        print(f"[OK] Report saved to {filename}")

# ==================== SYSTEM CHECK ====================
def check_system():
    """Check system environment"""
    print("\n[*] SYSTEM CHECK")
    print("-" * 70)
    
    info = {
        "OS": platform.system(),
        "Python": platform.python_version(),
        "Architecture": platform.architecture()[0],
        "CWD": os.getcwd(),
        "Database Exists": os.path.exists(DATABASE),
        "Backup Exists": os.path.exists("database.db.backup"),
    }
    
    for key, value in info.items():
        print(f"  {key}: {value}")
    
    return info

# ==================== PORT CHECK ====================
def check_port_available():
    """Check if port 5000 is available"""
    print("\n[*] PORT AVAILABILITY CHECK")
    print("-" * 70)
    
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        result = sock.connect_ex(('127.0.0.1', 5000))
        if result == 0:
            print("  [OK] Port 5000 is OPEN (Server running)")
            return True
        else:
            print("  [FAIL] Port 5000 is CLOSED (Server not running)")
            return False
    finally:
        sock.close()

# ==================== PYTHON SYNTAX CHECK ====================
def check_python_syntax():
    """Check syntax of all Python files"""
    print("\n[*] PYTHON SYNTAX CHECK")
    print("-" * 70)
    
    py_files = list(Path(".").rglob("*.py"))
    errors = []
    valid_files = []
    
    for py_file in py_files:
        if '__pycache__' in str(py_file):
            continue
        try:
            with open(py_file, 'r', encoding='utf-8', errors='ignore') as f:
                compile(f.read(), str(py_file), 'exec')
            valid_files.append(str(py_file))
        except SyntaxError as e:
            errors.append(f"{py_file}: {str(e)}")
        except Exception as e:
            # Skip files that can't be read
            pass
    
    print(f"  Total Python files: {len(valid_files)}")
    print(f"  Syntax valid: {len(valid_files)}")
    print(f"  Syntax errors: {len(errors)}")
    
    if errors:
        print("\n  Errors found:")
        for error in errors:
            print(f"    - {error}")
    
    return {'valid': len(valid_files), 'errors': len(errors), 'error_list': errors}

# ==================== DATABASE SCHEMA CHECK ====================
def check_database():
    """Check database schema and integrity"""
    print("\n[*] DATABASE SCHEMA CHECK")
    print("-" * 70)
    
    if not os.path.exists(DATABASE):
        print(f"  [FAIL] Database file not found: {DATABASE}")
        return False
    
    try:
        conn = sqlite3.connect(DATABASE)
        cursor = conn.cursor()
        
        # Get all tables
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
        tables = [row[0] for row in cursor.fetchall()]
        
        print(f"  Total tables: {len(tables)}")
        print(f"  Tables: {', '.join(tables[:10])}")
        if len(tables) > 10:
            print(f"           ... and {len(tables)-10} more")
        
        # Check creds table
        cursor.execute("PRAGMA table_info(creds)")
        creds_columns = [row[1] for row in cursor.fetchall()]
        print(f"\n  Creds table columns: {len(creds_columns)}")
        print(f"    Required fields present:")
        required = ['id', 'url', 'username', 'password', 'cookies', 'csrf_tokens', 'created_at']
        for field in required:
            present = field in creds_columns
            print(f"      - {field}: {'[OK]' if present else '[FAIL]'}")
        
        # Check sessions table
        cursor.execute("PRAGMA table_info(sessions)")
        sessions_columns = [row[1] for row in cursor.fetchall()]
        print(f"\n  Sessions table columns: {len(sessions_columns)}")
        
        # Get row counts
        cursor.execute("SELECT COUNT(*) FROM creds")
        creds_count = cursor.fetchone()[0]
        cursor.execute("SELECT COUNT(*) FROM sessions")
        sessions_count = cursor.fetchone()[0]
        
        print(f"\n  Data in database:")
        print(f"    - Credentials: {creds_count} rows")
        print(f"    - Sessions: {sessions_count} rows")
        
        conn.close()
        return True
        
    except Exception as e:
        print(f"  [FAIL] Database check failed: {str(e)}")
        return False

# ==================== SERVER CONNECTIVITY ====================
def check_server():
    """Check if server is running and responsive"""
    print("\n[*] SERVER CONNECTIVITY CHECK")
    print("-" * 70)
    
    try:
        response = requests.get(f"{BASE_URL}/neptune", timeout=TIMEOUT)
        print(f"  [OK] Server responding")
        print(f"    - Status Code: {response.status_code}")
        print(f"    - Content Length: {len(response.content)} bytes")
        return True
    except requests.exceptions.ConnectionError:
        print(f"  [FAIL] Cannot connect to {BASE_URL}")
        return False
    except Exception as e:
        print(f"  [FAIL] Server check error: {str(e)}")
        return False

# ==================== ENDPOINT TESTS ====================
def test_endpoints():
    """Test all critical endpoints"""
    print("\n[*] ENDPOINT FUNCTIONALITY TESTS")
    print("-" * 70)
    
    endpoints = [
        ("Admin Panel", "GET", "/neptune", None),
        ("Live Panel", "GET", "/studio/live-panel", None),
        ("OTP Panel", "GET", "/studio/otp-panel", None),
        ("Recorder UI", "GET", "/studio/recorder", None),
        ("Login Page", "GET", "/login", None),
        ("API Get Templates", "GET", "/api/get-templates", None),
        ("API Get Lures", "GET", "/api/get-lures", None),
    ]
    
    results = {"success": 0, "failed": 0, "details": []}
    
    for name, method, endpoint, data in endpoints:
        try:
            url = f"{BASE_URL}{endpoint}"
            if method == "GET":
                response = requests.get(url, timeout=TIMEOUT)
            else:
                response = requests.post(url, json=data, timeout=TIMEOUT)
            
            success = response.status_code == 200
            status = "[OK]" if success else f"[{response.status_code}]"
            print(f"  {status} {name}: {endpoint}")
            results["details"].append(f"{name}: {response.status_code}")
            
            if success:
                results["success"] += 1
            else:
                results["failed"] += 1
                
        except Exception as e:
            print(f"  [FAIL] {name}: {str(e)}")
            results["failed"] += 1
            results["details"].append(f"{name}: ERROR - {str(e)}")
    
    print(f"\n  Endpoints passed: {results['success']}/{results['success']+results['failed']}")
    return results

# ==================== TEMPLATE SAVE TEST ====================
def test_template_save():
    """Test template save functionality"""
    print("\n[*] TEMPLATE SAVE ENDPOINT TEST")
    print("-" * 70)
    
    test_template = {
        "name": "Debug Test Template",
        "base_url": "http://test.example.com",
        "clone_mode": "full",
        "browser_engine": "playwright",
        "headless": 1,
        "stealth": 1,
        "description": "Test template for debugging",
        "tags": "test,debug"
    }
    
    try:
        # Note: This might fail due to CSRF, but we're checking if endpoint exists
        response = requests.post(
            f"{BASE_URL}/recorder/save-template",
            json=test_template,
            timeout=TIMEOUT
        )
        
        print(f"  Endpoint Status: {response.status_code}")
        print(f"  Response: {response.text[:200]}")
        
        if response.status_code == 200 or "CSRF" in response.text:
            print(f"  [OK] Endpoint exists and processes requests")
            return True
        else:
            print(f"  [FAIL] Unexpected response")
            return False
            
    except Exception as e:
        print(f"  [FAIL] Template save test error: {str(e)}")
        return False

# ==================== ROUTES CHECK ====================
def check_routes():
    """Check if all required routes are defined"""
    print("\n[*] ROUTES DEFINITION CHECK")
    print("-" * 70)
    
    try:
        with open("SocialFish.py", "r", encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        required_routes = [
            "/neptune",
            "/studio/recorder",
            "/studio/live-panel",
            "/studio/otp-panel",
            "/recorder/save-template",
            "/api/get-templates",
            "/api/get-lures",
            "/login",
        ]
        
        found = 0
        for route in required_routes:
            if f'@app.route("{route}"' in content or f"@app.route('{route}'" in content:
                print(f"  [OK] {route} defined")
                found += 1
            else:
                print(f"  [FAIL] {route} NOT found")
        
        print(f"\n  Routes found: {found}/{len(required_routes)}")
        return found == len(required_routes)
        
    except Exception as e:
        print(f"  [FAIL] Routes check error: {str(e)}")
        return False

# ==================== SOCKETIO CHECK ====================
def check_socketio():
    """Check Socket.IO configuration"""
    print("\n[*] SOCKET.IO CONFIGURATION CHECK")
    print("-" * 70)
    
    try:
        with open("SocialFish.py", "r", encoding='utf-8', errors='ignore') as f:
            content = f.read()
        
        checks = [
            ("SocketIO import", "from flask_socketio import SocketIO" in content),
            ("Socket instance created", "socketio = SocketIO" in content),
            ("allow_unsafe_werkzeug", "allow_unsafe_werkzeug=True" in content),
            ("Socket.IO events", "@socketio.on" in content),
        ]
        
        passed = 0
        for check_name, result in checks:
            status = "[OK]" if result else "[FAIL]"
            print(f"  {status} {check_name}")
            if result:
                passed += 1
        
        print(f"\n  Socket.IO checks: {passed}/{len(checks)} passed")
        return passed == len(checks)
        
    except Exception as e:
        print(f"  [FAIL] Socket.IO check error: {str(e)}")
        return False

# ==================== CODE QUALITY CHECK ====================
def check_code_quality():
    """Check code quality issues"""
    print("\n[*] CODE QUALITY CHECK")
    print("-" * 70)
    
    try:
        with open("SocialFish.py", "r", encoding='utf-8', errors='ignore') as f:
            lines = f.readlines()
        
        issues = {
            "bare_except": 0,
            "hardcoded_creds": 0,
            "logging_issues": 0,
            "duplicate_imports": 0,
        }
        
        for i, line in enumerate(lines):
            if "except:" in line and "except Exception" not in line:
                issues["bare_except"] += 1
            if "password = " in line.lower() and "admin" in line.lower():
                issues["hardcoded_creds"] += 1
            if "logging.info" in line or "logging.warning" in line:
                issues["logging_issues"] += 1
        
        print(f"  Bare except clauses: {issues['bare_except']}")
        print(f"  Potential hardcoded credentials: {issues['hardcoded_creds']}")
        print(f"  Logging inconsistencies: {issues['logging_issues']}")
        print(f"  Duplicate imports: {issues['duplicate_imports']}")
        
        total_issues = sum(issues.values())
        print(f"\n  Total code quality issues: {total_issues}")
        return total_issues
        
    except Exception as e:
        print(f"  [FAIL] Code quality check error: {str(e)}")
        return -1

# ==================== FILE INTEGRITY CHECK ====================
def check_file_integrity():
    """Check if critical files exist and are readable"""
    print("\n[*] FILE INTEGRITY CHECK")
    print("-" * 70)
    
    required_files = [
        "SocialFish.py",
        "database.db",
        "core/dbsf.py",
        "core/config.py",
        "templates/admin/templates.html",
        "templates/admin/index.html",
        "automated_test.py",
    ]
    
    found = 0
    for file_path in required_files:
        exists = os.path.exists(file_path)
        readable = os.access(file_path, os.R_OK) if exists else False
        status = "[OK]" if exists and readable else "[FAIL]"
        print(f"  {status} {file_path}")
        if exists and readable:
            found += 1
    
    print(f"\n  Files integrity: {found}/{len(required_files)} passed")
    return found == len(required_files)

# ==================== RUN ALL TESTS ====================
def run_comprehensive_tests():
    """Run all tests and generate report"""
    print("\n" + "="*70)
    print("SOCIALFISH V3.0 - COMPREHENSIVE DEBUG & TEST SUITE")
    print("="*70)
    
    report = DebugReport()
    results = {}
    
    # System checks
    system_info = check_system()
    report.add_section("System Information", 
        [f"{k}: {v}" for k, v in system_info.items()])
    
    # Port check
    port_available = check_port_available()
    
    # Python syntax
    syntax_result = check_python_syntax()
    report.add_section("Python Syntax Check", 
        [f"Valid files: {syntax_result['valid']}",
         f"Syntax errors: {syntax_result['errors']}"])
    
    # Database
    db_ok = check_database()
    report.add_section("Database Check", [f"Database OK: {db_ok}"])
    
    # Server
    server_ok = check_server()
    report.add_section("Server Connectivity", [f"Server running: {server_ok}"])
    
    # Routes
    routes_ok = check_routes()
    report.add_section("Routes Definition", [f"All routes defined: {routes_ok}"])
    
    # Socket.IO
    socketio_ok = check_socketio()
    report.add_section("Socket.IO Configuration", [f"Socket.IO configured: {socketio_ok}"])
    
    # Code quality
    code_issues = check_code_quality()
    report.add_section("Code Quality", [f"Total issues found: {code_issues}"])
    
    # File integrity
    files_ok = check_file_integrity()
    report.add_section("File Integrity", [f"Files integrity: {files_ok}"])
    
    # Endpoints
    endpoint_results = test_endpoints()
    report.add_section("Endpoint Tests", endpoint_results["details"])
    
    # Template save
    template_ok = test_template_save()
    report.add_section("Template Save Test", [f"Template endpoint working: {template_ok}"])
    
    # Summary
    print("\n" + "="*70)
    print("TEST SUMMARY")
    print("="*70)
    print(f"  System Check: {'[OK]' if system_info else '[FAIL]'}")
    print(f"  Port Available: {'[OK]' if port_available else '[FAIL]'}")
    print(f"  Python Syntax: {'[OK]' if syntax_result['errors'] == 0 else '[FAIL]'}")
    print(f"  Database: {'[OK]' if db_ok else '[FAIL]'}")
    print(f"  Server: {'[OK]' if server_ok else '[FAIL]'}")
    print(f"  Routes: {'[OK]' if routes_ok else '[FAIL]'}")
    print(f"  Socket.IO: {'[OK]' if socketio_ok else '[FAIL]'}")
    print(f"  Code Quality: Issues found: {code_issues}")
    print(f"  File Integrity: {'[OK]' if files_ok else '[FAIL]'}")
    print(f"  Endpoints: {endpoint_results['success']}/{endpoint_results['success']+endpoint_results['failed']}")
    print(f"  Template Save: {'[OK]' if template_ok else '[FAIL]'}")
    print("="*70 + "\n")
    
    # Save report
    report.save()
    
    # Determine overall status
    all_passed = (syntax_result['errors'] == 0 and db_ok and routes_ok and 
                  socketio_ok and files_ok and server_ok)
    
    return 0 if all_passed else 1

if __name__ == "__main__":
    exit_code = run_comprehensive_tests()
    sys.exit(exit_code)
