#!/usr/bin/env python3
"""
FINAL COMPREHENSIVE SYSTEM VERIFICATION
Complete end-to-end system testing and validation (Windows compatible)
"""

import os
import sys
import subprocess
import sqlite3
from pathlib import Path
from datetime import datetime
import json

class FinalSystemVerification:
    def __init__(self):
        self.results = []
        self.start_time = datetime.now()
        
    def test_section(self, name):
        """Print formatted test section header"""
        print("\n" + "="*80)
        print(f"[TEST] {name}")
        print("="*80)
    
    def add_result(self, test_name, passed, message=""):
        result = {
            'test': test_name,
            'passed': passed,
            'message': message,
            'timestamp': datetime.now().isoformat()
        }
        self.results.append(result)
        status = "[OK]" if passed else "[FAIL]"
        print(f"{status} {test_name}: {message}")
        
    def verify_database_integrity(self):
        """Verify all database components"""
        self.test_section("DATABASE INTEGRITY")
        
        try:
            db_path = 'database.db'
            if not os.path.exists(db_path):
                self.add_result('Database Exists', False, 'database.db not found')
                return
            
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            
            # Check tables
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = [row[0] for row in cursor.fetchall()]
            
            required_tables = ['creds', 'templates', 'lures', 'sessions', 'config']
            found = [t for t in required_tables if t in tables]
            self.add_result('Required Tables', len(found) == len(required_tables),
                          f'Found {len(found)}/{len(required_tables)}')
            
            # Check creds columns
            cursor.execute("PRAGMA table_info(creds)")
            columns = {row[1] for row in cursor.fetchall()}
            required_cols = {'email', 'password', 'username', 'cookies', 'csrf_tokens'}
            found_cols = required_cols & columns
            self.add_result('Credentials Columns', len(found_cols) == len(required_cols),
                          f'Found {len(found_cols)}/{len(required_cols)}')
            
            # Check record counts
            cursor.execute("SELECT COUNT(*) FROM creds")
            cred_count = cursor.fetchone()[0]
            self.add_result('Credential Records', True, f'Total: {cred_count}')
            
            conn.close()
            
        except Exception as e:
            self.add_result('Database Verification', False, str(e))
    
    def verify_file_structure(self):
        """Verify all critical files exist"""
        self.test_section("FILE STRUCTURE")
        
        critical_files = [
            'SocialFish.py',
            'requirements.txt',
            'core/config.py',
            'core/dbsf.py',
            'templates/admin/index.html',
            'templates/admin/recording_studio_real.html',
        ]
        
        for filepath in critical_files:
            exists = os.path.exists(filepath)
            self.add_result(f'File: {filepath}', exists, 
                          'Found' if exists else 'Missing')
    
    def verify_python_syntax(self):
        """Verify all Python files have valid syntax"""
        self.test_section("PYTHON SYNTAX VALIDATION")
        
        import py_compile
        
        python_files = [
            'SocialFish.py',
            'comprehensive_system_fixer.py',
            'final_comprehensive_tests.py',
        ]
        
        for py_file in python_files:
            try:
                py_compile.compile(py_file, doraise=True)
                self.add_result(f'Syntax: {py_file}', True, 'Valid')
            except Exception as e:
                self.add_result(f'Syntax: {py_file}', False, str(e)[:50])
    
    def verify_logging_coverage(self):
        """Verify logging is comprehensive"""
        self.test_section("LOGGING COVERAGE")
        
        try:
            with open('SocialFish.py', 'r') as f:
                content = f.read()
            
            # Count logging statements
            import re
            logger_calls = len(re.findall(r'logger\.(debug|info|warning|error|critical)', content))
            print_calls = len(re.findall(r'print\(', content))
            routes = len(re.findall(r'@app\.route', content))
            
            self.add_result('Logger Calls', logger_calls > 40, 
                          f'Found {logger_calls} logger calls')
            self.add_result('Print Statements', print_calls > 5,
                          f'Found {print_calls} print statements')
            self.add_result('Routes Present', routes > 50,
                          f'Found {routes} routes')
                          
        except Exception as e:
            self.add_result('Logging Analysis', False, str(e))
    
    def verify_critical_functions(self):
        """Verify all critical functions exist"""
        self.test_section("CRITICAL FUNCTIONS")
        
        try:
            with open('SocialFish.py', 'r') as f:
                content = f.read()
            
            critical_funcs = [
                'extract_credential_fields',
                'generate_lure_from_template',
                'capture_form',
                'victim_capture',
            ]
            
            for func in critical_funcs:
                exists = f'def {func}(' in content
                self.add_result(f'Function: {func}', exists,
                              'Defined' if exists else 'Missing')
                              
        except Exception as e:
            self.add_result('Function Verification', False, str(e))
    
    def verify_templates_present(self):
        """Verify all HTML templates"""
        self.test_section("TEMPLATE FILES")
        
        templates = [
            'templates/admin/index.html',
            'templates/admin/recording_studio_real.html',
            'templates/admin/live_login_panel.html',
            'templates/admin/sessions.html',
            'templates/admin/sfusers.html',
        ]
        
        for template in templates:
            exists = os.path.exists(template)
            size = os.path.getsize(template) if exists else 0
            self.add_result(f'Template: {template.split("/")[-1]}', exists,
                          f'{size} bytes' if exists else 'Missing')
    
    def verify_api_endpoints(self):
        """Verify all API endpoints are defined"""
        self.test_section("API ENDPOINTS")
        
        try:
            with open('SocialFish.py', 'r') as f:
                content = f.read()
            
            api_patterns = [
                '/api/generate-lure',
                '/api/credential-webhook',
                '/api/clone',
                '/api/save-template',
                '/hook.js',
                '/capture/',
            ]
            
            for pattern in api_patterns:
                exists = f'@app.route("{pattern}' in content or f"@app.route('{pattern}" in content
                self.add_result(f'Endpoint: {pattern}', exists,
                              'Defined' if exists else 'Missing')
                              
        except Exception as e:
            self.add_result('API Verification', False, str(e))
    
    def verify_error_handling(self):
        """Verify error handling coverage"""
        self.test_section("ERROR HANDLING")
        
        try:
            with open('SocialFish.py', 'r') as f:
                content = f.read()
            
            import re
            try_blocks = len(re.findall(r'try:', content))
            except_blocks = len(re.findall(r'except', content))
            
            self.add_result('Try Blocks', try_blocks > 20,
                          f'Found {try_blocks} try blocks')
            self.add_result('Except Handlers', except_blocks > 20,
                          f'Found {except_blocks} except blocks')
            self.add_result('Error Coverage', except_blocks >= try_blocks,
                          f'Coverage: {(except_blocks/max(1,try_blocks))*100:.0f}%')
                          
        except Exception as e:
            self.add_result('Error Handling Check', False, str(e))
    
    def verify_test_files(self):
        """Verify test automation files"""
        self.test_section("TEST AUTOMATION")
        
        test_files = [
            'automated_test.py',
            'comprehensive_audit_windows.py',
            'comprehensive_system_fixer.py',
            'final_comprehensive_tests.py',
        ]
        
        for test_file in test_files:
            exists = os.path.exists(test_file)
            self.add_result(f'Test File: {test_file}', exists,
                          'Found' if exists else 'Missing')
    
    def verify_configuration(self):
        """Verify configuration is complete"""
        self.test_section("CONFIGURATION")
        
        try:
            from core.config import DATABASE, HOST, PORT, APP_SECRET_KEY
            
            self.add_result('Database Config', DATABASE is not None,
                          f'Path: {DATABASE}')
            self.add_result('Host Config', HOST is not None,
                          f'Host: {HOST}')
            self.add_result('Port Config', PORT is not None,
                          f'Port: {PORT}')
            self.add_result('Secret Key Config', APP_SECRET_KEY is not None,
                          'Configured' if APP_SECRET_KEY else 'Missing')
                          
        except Exception as e:
            self.add_result('Configuration Check', False, str(e))
    
    def generate_summary_report(self):
        """Generate final summary report"""
        elapsed = datetime.now() - self.start_time
        passed = len([r for r in self.results if r['passed']])
        total = len(self.results)
        
        print("\n" + "="*80)
        print("FINAL SYSTEM VERIFICATION SUMMARY")
        print("="*80)
        
        summary = [
            "FINAL COMPREHENSIVE SYSTEM VERIFICATION REPORT",
            f"Generated: {datetime.now().isoformat()}",
            f"Execution Time: {elapsed.total_seconds():.2f}s",
            "",
            "="*80,
            "TEST RESULTS",
            "="*80,
            f"Tests Passed: {passed}/{total} ({(passed/total)*100:.1f}%)",
            f"Tests Failed: {total-passed}",
            "",
            "DETAILED RESULTS:",
            "-"*80,
        ]
        
        for result in self.results:
            status = "[OK]" if result['passed'] else "[FAIL]"
            summary.append(f"{status} {result['test']}: {result['message']}")
        
        summary.extend([
            "",
            "="*80,
            "SYSTEM HEALTH STATUS",
            "="*80,
            f"Overall Status: {'HEALTHY' if passed >= (total * 0.8) else 'NEEDS ATTENTION'}",
            f"Health Score: {(passed/total)*100:.0f}%",
            "",
            "CRITICAL SYSTEMS:",
            "-"*80,
        ])
        
        critical_tests = [r for r in self.results 
                         if any(x in r['test'] for x in ['Database', 'Python Syntax', 'CriticalFunctions'])]
        
        for test in critical_tests:
            status = "OK" if test['passed'] else "FAILED"
            summary.append(f"  {test['test']}: {status}")
        
        summary.extend([
            "",
            "NEXT STEPS:",
            "-"*80,
            "1. Review detailed test results above",
            "2. Fix any FAILED tests before production deployment",
            "3. Run complete test suite: python final_comprehensive_tests.py",
            "4. Launch browser tests: python comprehensive_test_and_browser.py",
            "5. Monitor logs during operation: [ROUTE] and [LOG] messages",
            "",
        ])
        
        report_content = '\n'.join(summary)
        report_file = Path('FINAL_SYSTEM_VERIFICATION_REPORT.txt')
        report_file.write_text(report_content, encoding='utf-8')
        
        print(report_content)
        print(f"\n[OK] Report saved to: {report_file}\n")
        
        return report_content
    
    def run_full_verification(self):
        """Run complete verification suite"""
        print("\n" + "="*80)
        print("STARTING FINAL COMPREHENSIVE SYSTEM VERIFICATION")
        print("="*80)
        
        self.verify_database_integrity()
        self.verify_file_structure()
        self.verify_python_syntax()
        self.verify_logging_coverage()
        self.verify_critical_functions()
        self.verify_templates_present()
        self.verify_api_endpoints()
        self.verify_error_handling()
        self.verify_test_files()
        self.verify_configuration()
        
        self.generate_summary_report()
        
        print("="*80)
        print("VERIFICATION COMPLETE")
        print("="*80 + "\n")

if __name__ == '__main__':
    verifier = FinalSystemVerification()
    verifier.run_full_verification()
