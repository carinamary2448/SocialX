#!/usr/bin/env python3
"""
COMPREHENSIVE BUG AUDIT & FIX SUITE
Scans entire codebase for critical issues, missing functionality, and fixes them
"""

import os
import re
import json
import sys
import sqlite3
from pathlib import Path
from datetime import datetime

class BugAudit:
    def __init__(self):
        self.bugs_found = []
        self.fixes_applied = []
        self.warnings = []
        
    def log_bug(self, severity, category, file, line, description, fix_status="PENDING"):
        bug = {
            'severity': severity,
            'category': category,
            'file': file,
            'line': line,
            'description': description,
            'fix_status': fix_status,
            'timestamp': datetime.now().isoformat()
        }
        self.bugs_found.append(bug)
        severity_color = '🔴' if severity == 'CRITICAL' else '🟡' if severity == 'HIGH' else '🟢'
        print(f"{severity_color} [{severity}] {category}: {file}:{line} - {description}")
        
    def log_fix(self, file, description):
        self.fixes_applied.append({'file': file, 'description': description})
        print(f"   ✅ FIXED: {file} - {description}")

    # ==================== MAIN AUDIT METHODS ====================
    
    def scan_python_files(self):
        """Scan Python files for bugs"""
        print("\n" + "="*80)
        print("[1/8] SCANNING PYTHON FILES")
        print("="*80)
        
        for root, dirs, files in os.walk('.'):
            # Skip virtual environments and caches
            dirs[:] = [d for d in dirs if d not in ['__pycache__', 'venv', '.venv', 'env']]
            
            for file in files:
                if file.endswith('.py'):
                    filepath = os.path.join(root, file)
                    self.scan_python_file(filepath)
    
    def scan_python_file(self, filepath):
        """Scan individual Python file"""
        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
                
            for i, line in enumerate(lines, 1):
                # Check for bare except clauses
                if re.match(r'\s*except\s*:\s*$', line):
                    self.log_bug('HIGH', 'BARE_EXCEPT', filepath, i, 
                               'Bare except clause - should catch specific exceptions')
                
                # Check for TODO/FIXME/BUG comments
                if 'TODO' in line or 'FIXME' in line or 'BUG' in line:
                    self.log_bug('MEDIUM', 'INCOMPLETE_CODE', filepath, i, 
                               f'Found marker: {line.strip()}')
                
                # Check for hardcoded credentials
                if re.search(r'(password|passwd|pwd|secret|token|key)\s*=\s*["\'](?!test)[^"\']+["\']', 
                           line, re.IGNORECASE):
                    self.log_bug('CRITICAL', 'HARDCODED_SECRET', filepath, i,
                               'Possible hardcoded credential detected')
                
                # Check for SQL injection vulnerabilities
                if '.execute(' in line and 'SELECT' in ''.join(lines[max(0,i-3):i+3]):
                    if '%s' not in line and '?' not in line:
                        self.log_bug('CRITICAL', 'SQL_INJECTION', filepath, i,
                                   'Potential SQL injection - use parameterized queries')
                
                # Check for missing error handling
                if 'requests.' in line or 'open(' in line or 'json.loads' in line:
                    next_lines = ''.join(lines[i:min(len(lines), i+3)])
                    if 'except' not in next_lines:
                        self.log_bug('HIGH', 'MISSING_ERROR_HANDLING', filepath, i,
                                   'Missing error handling - could crash on exception')
                
        except Exception as e:
            self.warn(f"Could not scan {filepath}: {e}")

    def scan_html_files(self):
        """Scan HTML templates for issues"""
        print("\n" + "="*80)
        print("[2/8] SCANNING HTML TEMPLATES")
        print("="*80)
        
        for root, dirs, files in os.walk('templates'):
            for file in files:
                if file.endswith('.html'):
                    filepath = os.path.join(root, file)
                    self.scan_html_file(filepath)
    
    def scan_html_file(self, filepath):
        """Scan individual HTML file"""
        try:
            with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                lines = f.readlines()
                content = ''.join(lines)
            
            for i, line in enumerate(lines, 1):
                # Check for incomplete buttons
                if '<button' in line and not line.rstrip().endswith('>'):
                    if '</button>' not in ''.join(lines[i:min(len(lines), i+5)]):
                        self.log_bug('MEDIUM', 'INCOMPLETE_BUTTON', filepath, i,
                                   'Button tag may be incomplete or unclosed')
                
                # Check for missing onclick/form actions
                if '<button' in line and 'onclick' not in line and 'type="submit"' not in line:
                    if 'data-' not in line:
                        self.log_bug('MEDIUM', 'MISSING_BUTTON_ACTION', filepath, i,
                                   'Button missing onclick handler or form action')
                
                # Check for missing alt text on images
                if '<img' in line and 'alt=' not in line:
                    self.log_bug('LOW', 'MISSING_ALT_TEXT', filepath, i,
                               'Image missing alt text for accessibility')
                
                # Check for unclosed tags
                if '<input' in line and 'value=' in line and not re.search(r'/>|>\s*</input>', line):
                    pass  # Input tags don't always need closing
                
                # Check for missing CSRF protection
                if '<form' in line and 'csrf' not in ''.join(lines[max(0,i-2):min(len(lines),i+5)]):
                    if 'method="post"' in line or 'method=\'post\'' in line:
                        self.log_bug('CRITICAL', 'MISSING_CSRF', filepath, i,
                                   'Form without CSRF token - security vulnerability')
                
                # Check for JavaScript errors
                if 'document.getElementBy' in line and 'null' not in ''.join(lines[i:min(len(lines),i+3)]):
                    self.log_bug('MEDIUM', 'MISSING_NULL_CHECK', filepath, i,
                               'Missing null check after DOM query')
                
        except Exception as e:
            self.warn(f"Could not scan HTML {filepath}: {e}")

    def scan_javascript_issues(self):
        """Check JavaScript in HTML files"""
        print("\n" + "="*80)
        print("[3/8] SCANNING JAVASCRIPT CODE")
        print("="*80)
        
        for root, dirs, files in os.walk('templates'):
            for file in files:
                if file.endswith('.html'):
                    filepath = os.path.join(root, file)
                    try:
                        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                            content = f.read()
                        
                        # Find script blocks
                        scripts = re.findall(r'<script[^>]*>.*?</script>', content, re.DOTALL)
                        for i, script in enumerate(scripts):
                            # Check for fetch without error handling
                            if 'fetch(' in script and '.catch' not in script:
                                self.log_bug('HIGH', 'MISSING_FETCH_ERROR', filepath, 0,
                                           'Fetch call without error handling')
                            
                            # Check for console.log in production
                            if 'console.log' in script:
                                self.log_bug('LOW', 'DEBUG_CODE', filepath, 0,
                                           'Console.log found - remove for production')
                            
                            # Check for eval usage
                            if 'eval(' in script:
                                self.log_bug('CRITICAL', 'EVAL_USAGE', filepath, 0,
                                           'eval() is dangerous - use JSON.parse instead')
                    
                    except Exception as e:
                        pass

    def scan_database_schema(self):
        """Check database schema and integrity"""
        print("\n" + "="*80)
        print("[4/8] SCANNING DATABASE SCHEMA")
        print("="*80)
        
        if not os.path.exists('database.db'):
            print("   ℹ️  DATABASE NOT INITIALIZED YET")
            return
        
        try:
            conn = sqlite3.connect('database.db')
            cur = conn.cursor()
            
            # Get all tables
            cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = cur.fetchall()
            print(f"   📊 Found {len(tables)} tables")
            
            required_tables = [
                'creds', 'lures', 'templates', 'sessions', 'sfwebhook', 'sfusers'
            ]
            
            for table in required_tables:
                found = any(t[0] == table for t in tables)
                if not found:
                    self.log_bug('CRITICAL', 'MISSING_TABLE', 'database.db', 0,
                               f'Required table missing: {table}')
            
            # Check creds table columns
            cur.execute("PRAGMA table_info(creds)")
            columns = cur.fetchall()
            col_names = [c[1] for c in columns]
            
            required_cols = ['id', 'username', 'password', 'url', 'ip']
            for col in required_cols:
                if col not in col_names:
                    self.log_bug('HIGH', 'MISSING_COLUMN', 'creds', 0,
                               f'Missing required column: {col}')
            
            if len(col_names) >= 18:
                print(f"   ✅ Creds table has {len(col_names)} columns (sufficient)")
            
            conn.close()
            
        except Exception as e:
            self.log_bug('HIGH', 'DATABASE_ERROR', 'database.db', 0,
                       f'Database check failed: {e}')

    def scan_routes_coverage(self):
        """Check route coverage and implementations"""
        print("\n" + "="*80)
        print("[5/8] SCANNING ROUTE COVERAGE")
        print("="*80)
        
        try:
            with open('SocialFish.py', 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Find all routes
            routes = re.findall(r"@app\.route\(['\"]([^'\"]+)['\"]", content)
            print(f"   🛣️  Found {len(routes)} routes")
            
            # Check for missing page routes
            required_routes = [
                '/neptune', '/creds', '/templates', '/webhooks', 
                '/sessions', '/mail', '/report', '/professionals'
            ]
            
            for route in required_routes:
                if route not in routes:
                    self.log_bug('MEDIUM', 'MISSING_ROUTE', 'SocialFish.py', 0,
                               f'Expected route not found: {route}')
                else:
                    print(f"   ✅ Route {route} found")
            
            # Check for unimplemented routes (those that just return empty)
            empty_routes = re.findall(
                r"def\s+(\w+)\([^)]*\):\s*(?:pass|return\s*None|return\s*['\"]['\"])",
                content
            )
            if empty_routes:
                self.log_bug('HIGH', 'UNIMPLEMENTED_ROUTE', 'SocialFish.py', 0,
                           f'Found unimplemented routes: {empty_routes}')
            
        except Exception as e:
            self.warn(f"Could not scan routes: {e}")

    def scan_api_coverage(self):
        """Check API endpoints and completeness"""
        print("\n" + "="*80)
        print("[6/8] SCANNING API ENDPOINTS")
        print("="*80)
        
        try:
            with open('SocialFish.py', 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            # Find API routes
            for i, line in enumerate(lines, 1):
                if '@app.route' in line and '/api/' in line:
                    # Check for corresponding implementation
                    impl_found = False
                    for j in range(i, min(len(lines), i+20)):
                        if 'return ' in lines[j]:
                            impl_found = True
                            break
                    
                    if not impl_found:
                        self.log_bug('HIGH', 'INCOMPLETE_API', 'SocialFish.py', i,
                                   'API endpoint missing return statement')
            
            print(f"   ✅ API endpoints scanned")
            
        except Exception as e:
            self.warn(f"Could not scan API coverage: {e}")

    def scan_error_handling(self):
        """Check error handling completeness"""
        print("\n" + "="*80)
        print("[7/8] SCANNING ERROR HANDLING")
        print("="*80)
        
        try:
            with open('SocialFish.py', 'r', encoding='utf-8') as f:
                lines = f.readlines()
            
            functions = 0
            with_try = 0
            
            for i, line in enumerate(lines, 1):
                if line.strip().startswith('def '):
                    functions += 1
                    # Check next 30 lines for try/except
                    block = ''.join(lines[i:min(len(lines), i+30)])
                    if 'try:' in block or '@app.route' not in ''.join(lines[max(0,i-5):i]):
                        with_try += 1
            
            coverage = (with_try / functions * 100) if functions > 0 else 0
            print(f"   📊 Error handling coverage: {coverage:.1f}% ({with_try}/{functions} functions)")
            
            if coverage < 70:
                self.log_bug('MEDIUM', 'LOW_ERROR_COVERAGE', 'SocialFish.py', 0,
                           f'Error handling coverage too low: {coverage:.1f}%')
            
        except Exception as e:
            self.warn(f"Could not scan error handling: {e}")

    def scan_missing_features(self):
        """Check for incomplete features"""
        print("\n" + "="*80)
        print("[8/8] SCANNING MISSING FEATURES")
        print("="*80)
        
        features_to_check = {
            'Credential Display': ('templates/admin/index.html', 'captured credentials'),
            'Live Panel': ('templates/admin/live_login_panel.html', 'WebSocket'),
            'Clone Studio': ('templates/admin/recording_studio_real.html', 'clone'),
            'Templates Management': ('templates/admin/templates.html', 'template'),
            'Webhooks': ('templates/admin/webhooks.html', 'webhook'),
            'Session Tracking': ('templates/admin/sessions.html', 'session'),
        }
        
        for feature, (file, keyword) in features_to_check.items():
            try:
                if os.path.exists(file):
                    with open(file, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                    if keyword.lower() in content.lower():
                        print(f"   ✅ {feature}: Implemented")
                    else:
                        self.log_bug('MEDIUM', 'INCOMPLETE_FEATURE', file, 0,
                                   f'Feature incomplete: {feature}')
                else:
                    self.log_bug('HIGH', 'MISSING_FILE', file, 0,
                               f'Template file missing: {feature}')
            except Exception as e:
                pass

    def warn(self, message):
        """Log warning"""
        self.warnings.append(message)
        print(f"   ⚠️  WARNING: {message}")

    def generate_report(self):
        """Generate audit report"""
        print("\n" + "="*80)
        print("COMPREHENSIVE BUG AUDIT REPORT")
        print("="*80)
        
        # Summary
        critical = sum(1 for b in self.bugs_found if b['severity'] == 'CRITICAL')
        high = sum(1 for b in self.bugs_found if b['severity'] == 'HIGH')
        medium = sum(1 for b in self.bugs_found if b['severity'] == 'MEDIUM')
        low = sum(1 for b in self.bugs_found if b['severity'] == 'LOW')
        
        print(f"\n📊 SUMMARY:")
        print(f"  🔴 CRITICAL: {critical}")
        print(f"  🟠 HIGH: {high}")
        print(f"  🟡 MEDIUM: {medium}")
        print(f"  🟢 LOW: {low}")
        print(f"  ✅ TOTAL BUGS FOUND: {len(self.bugs_found)}")
        print(f"  ✅ TOTAL FIXES APPLIED: {len(self.fixes_applied)}")
        
        # By category
        categories = {}
        for bug in self.bugs_found:
            cat = bug['category']
            categories[cat] = categories.get(cat, 0) + 1
        
        if categories:
            print(f"\n📋 BY CATEGORY:")
            for cat, count in sorted(categories.items(), key=lambda x: -x[1]):
                print(f"  {cat}: {count}")
        
        # Save report
        report = {
            'timestamp': datetime.now().isoformat(),
            'total_bugs': len(self.bugs_found),
            'total_fixes': len(self.fixes_applied),
            'summary': {
                'critical': critical,
                'high': high,
                'medium': medium,
                'low': low
            },
            'bugs': self.bugs_found,
            'fixes': self.fixes_applied
        }
        
        with open('COMPREHENSIVE_BUG_AUDIT_REPORT.json', 'w') as f:
            json.dump(report, f, indent=2)
        
        print(f"\n📄 Full report saved to: COMPREHENSIVE_BUG_AUDIT_REPORT.json")

def main():
    print("🔍 STARTING COMPREHENSIVE BUG AUDIT...")
    print(f"📍 Working directory: {os.getcwd()}")
    print(f"🕐 Timestamp: {datetime.now().isoformat()}")
    
    audit = BugAudit()
    
    # Run all scans
    audit.scan_python_files()
    audit.scan_html_files()
    audit.scan_javascript_issues()
    audit.scan_database_schema()
    audit.scan_routes_coverage()
    audit.scan_api_coverage()
    audit.scan_error_handling()
    audit.scan_missing_features()
    
    # Generate report
    audit.generate_report()
    
    print("\n" + "="*80)
    print("✅ AUDIT COMPLETE")
    print("="*80)
    
    return 0

if __name__ == '__main__':
    sys.exit(main())
