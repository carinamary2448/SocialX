#!/usr/bin/env python3
"""
Enhanced cloning features for SocialFish
Includes form capture, lure management, dynamic page cloning, and asset management
"""

from .form_capture import FormDataCapture, FormFieldAnalyzer, CsrfTokenExtractor, FormInterceptor
from .lure_manager import LureManager, LureTemplate
from .dynamic_page_cloner import DynamicPageCloner, clone_dynamic_page_sync
from .asset_manager import AssetDownloader, CdnAssetManager

__all__ = [
    'FormDataCapture',
    'FormFieldAnalyzer',
    'CsrfTokenExtractor',
    'FormInterceptor',
    'LureManager',
    'LureTemplate',
    'DynamicPageCloner',
    'clone_dynamic_page_sync',
    'AssetDownloader',
    'CdnAssetManager'
]
