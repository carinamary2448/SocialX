#!/usr/bin/env python3
"""
Dynamic page cloning with JavaScript rendering support
Uses Playwright to handle modern JavaScript-heavy websites
"""

import asyncio
import json
import hashlib
from pathlib import Path
from typing import Dict, Optional, List
from datetime import datetime
import logging

try:
    from playwright.async_api import async_playwright
except ImportError:
    print("[-] Playwright not installed. Run: pip install playwright")

logger = logging.getLogger(__name__)


class DynamicPageCloner:
    """Clone JavaScript-rendered pages using Playwright"""
    
    def __init__(self, clone_dir: str = "./templates/clones"):
        self.clone_dir = Path(clone_dir)
        self.clone_dir.mkdir(parents=True, exist_ok=True)
    
    async def clone_dynamic_page(self, url: str, wait_for_selector: str = 'body',
                                 wait_time: int = 5000, include_assets: bool = True) -> Dict:
        """Clone a JavaScript-rendered page"""
        
        try:
            logger.info(f"[+] Cloning dynamic page: {url}")
            
            async with async_playwright() as p:
                browser = await p.chromium.launch(headless=True)
                
                # Create context with stealth
                context = await browser.new_context(
                    user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
                )
                
                page = await context.new_page()
                
                # Intercept requests
                intercepted_requests = []
                
                async def log_request(request):
                    intercepted_requests.append({
                        'url': request.url,
                        'method': request.method,
                        'resource_type': request.resource_type
                    })
                
                page.on('request', log_request)
                
                # Navigate and wait for content
                await page.goto(url, wait_until='networkidle')
                
                # Wait for specific selector if provided
                if wait_for_selector:
                    try:
                        await page.wait_for_selector(wait_for_selector, timeout=wait_time)
                    except Exception as e:
                        logger.warning(f"[!] Selector timeout: {e}")
                
                # Get rendered HTML
                html_content = await page.content()
                
                # Capture screenshots
                screenshot = await page.screenshot(path=None)
                
                # Collect form data
                forms_data = await self._collect_forms_data(page)
                
                # Generate clone ID
                clone_id = self._generate_clone_id(url)
                clone_path = self.clone_dir / clone_id
                clone_path.mkdir(exist_ok=True)
                
                # Save HTML
                html_file = clone_path / "index.html"
                with open(html_file, 'w', encoding='utf-8', errors='ignore') as f:
                    f.write(html_content)
                
                # Save screenshot
                screenshot_file = clone_path / "screenshot.png"
                with open(screenshot_file, 'wb') as f:
                    f.write(screenshot)
                
                # Save metadata
                metadata = {
                    'clone_id': clone_id,
                    'original_url': url,
                    'cloned_at': datetime.utcnow().isoformat(),
                    'is_dynamic': True,
                    'forms': forms_data,
                    'intercepted_requests': intercepted_requests[:20],  # First 20 requests
                    'screenshot': 'screenshot.png'
                }
                
                # Save assets if requested
                if include_assets:
                    assets_info = await self._download_assets(page, clone_path, clone_id)
                    metadata['assets'] = assets_info
                
                metadata_file = clone_path / "metadata.json"
                with open(metadata_file, 'w') as f:
                    json.dump(metadata, f, indent=2)
                
                await browser.close()
                
                logger.info(f"[+] Dynamic page cloned successfully: {clone_id}")
                
                return {
                    'status': 'ok',
                    'clone_id': clone_id,
                    'clone_url': f'/clone/{clone_id}/',
                    'metadata': metadata
                }
        
        except Exception as e:
            logger.error(f"[-] Dynamic clone error: {str(e)}")
            return {'status': 'error', 'message': str(e)}
    
    async def _collect_forms_data(self, page) -> List[Dict]:
        """Collect all forms from rendered page"""
        
        try:
            forms_data = []
            
            # Get all form elements
            forms = await page.query_selector_all('form')
            
            for i, form in enumerate(forms):
                form_info = {
                    'form_id': await form.get_attribute('id') or f'form_{i}',
                    'action': await form.get_attribute('action') or '',
                    'method': await form.get_attribute('method') or 'POST',
                    'enctype': await form.get_attribute('enctype') or 'application/x-www-form-urlencoded',
                    'fields': []
                }
                
                # Get form fields
                inputs = await form.query_selector_all('input, textarea, select')
                
                for field in inputs:
                    field_name = await field.get_attribute('name')
                    if field_name:
                        field_info = {
                            'name': field_name,
                            'type': await field.get_attribute('type') or 'text',
                            'value': await field.get_attribute('value') or '',
                            'required': await field.get_attribute('required') is not None
                        }
                        form_info['fields'].append(field_info)
                
                forms_data.append(form_info)
            
            return forms_data
        
        except Exception as e:
            logger.warning(f"[-] Collect forms failed: {e}")
            return []
    
    async def _download_assets(self, page, clone_path: Path, clone_id: str) -> Dict:
        """Download page assets (CSS, JS, images)"""
        
        assets_info = {
            'stylesheets': [],
            'scripts': [],
            'images': [],
            'resources': []
        }
        
        try:
            # Get all stylesheets
            stylesheets = await page.evaluate('''() => {
                return Array.from(document.querySelectorAll('link[rel="stylesheet"]'))
                    .map(link => link.href);
            }''')
            
            assets_info['stylesheets'] = stylesheets
            
            # Get all scripts
            scripts = await page.evaluate('''() => {
                return Array.from(document.querySelectorAll('script[src]'))
                    .map(script => script.src);
            }''')
            
            assets_info['scripts'] = scripts
            
            # Get all images
            images = await page.evaluate('''() => {
                return Array.from(document.querySelectorAll('img[src]'))
                    .map(img => ({src: img.src, alt: img.alt}));
            }''')
            
            assets_info['images'] = images
        
        except Exception as e:
            logger.warning(f"[-] Asset collection failed: {e}")
        
        return assets_info
    
    def _generate_clone_id(self, url: str) -> str:
        """Generate unique clone ID"""
        url_hash = hashlib.md5(url.encode()).hexdigest()[:8]
        domain = url.split('//')[1].split('/')[0].replace('.', '_')
        return f"dynamic_{domain}_{url_hash}_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}"
    
    async def record_user_interaction(self, url: str, actions: List[Dict]) -> Dict:
        """Record user interactions on a page"""
        
        try:
            logger.info(f"[+] Recording interactions on: {url}")
            
            async with async_playwright() as p:
                browser = await p.chromium.launch(headless=False)
                page = await browser.new_page()
                
                await page.goto(url)
                
                # Execute recorded actions
                for action in actions:
                    action_type = action.get('type')
                    
                    if action_type == 'click':
                        await page.click(action['selector'])
                    elif action_type == 'fill':
                        await page.fill(action['selector'], action['value'])
                    elif action_type == 'wait':
                        await page.wait_for_timeout(action.get('duration', 1000))
                    elif action_type == 'screenshot':
                        await page.screenshot(path=action.get('path', 'screenshot.png'))
                
                # Get final HTML
                final_html = await page.content()
                
                await browser.close()
                
                return {
                    'status': 'ok',
                    'html': final_html,
                    'actions_executed': len(actions)
                }
        
        except Exception as e:
            logger.error(f"[-] Recording failed: {e}")
            return {'status': 'error', 'message': str(e)}


# Utility function for synchronous use
def clone_dynamic_page_sync(url: str, wait_for_selector: str = 'body',
                           wait_time: int = 5000) -> Dict:
    """Synchronous wrapper for cloning dynamic pages"""
    
    cloner = DynamicPageCloner()
    return asyncio.run(cloner.clone_dynamic_page(url, wait_for_selector, wait_time))
