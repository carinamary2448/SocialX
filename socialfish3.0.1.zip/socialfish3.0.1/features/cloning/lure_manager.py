#!/usr/bin/env python3
"""
Template and Lure management system
Save and manage cloned page templates with form configurations
"""

import json
import hashlib
import sqlite3
from datetime import datetime
from typing import Dict, List, Optional
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


class LureTemplate:
    """Represents a saved lure/template configuration"""
    
    def __init__(self, template_id: str, name: str, description: str = '', 
                 url: str = '', clone_id: str = '', tags: List[str] = None):
        self.template_id = template_id
        self.name = name
        self.description = description
        self.url = url
        self.clone_id = clone_id
        self.tags = tags or []
        self.forms_config = []
        self.assets = {}
        self.created_at = datetime.utcnow().isoformat()
        self.updated_at = self.created_at
        self.custom_js = ''
        self.custom_css = ''
        self.metadata = {}
    
    def to_dict(self) -> Dict:
        """Convert template to dictionary"""
        return {
            'template_id': self.template_id,
            'name': self.name,
            'description': self.description,
            'url': self.url,
            'clone_id': self.clone_id,
            'tags': self.tags,
            'forms_config': self.forms_config,
            'assets': self.assets,
            'created_at': self.created_at,
            'updated_at': self.updated_at,
            'custom_js': self.custom_js,
            'custom_css': self.custom_css,
            'metadata': self.metadata
        }
    
    @staticmethod
    def from_dict(data: Dict) -> 'LureTemplate':
        """Create template from dictionary"""
        template = LureTemplate(
            template_id=data.get('template_id'),
            name=data.get('name'),
            description=data.get('description'),
            url=data.get('url'),
            clone_id=data.get('clone_id'),
            tags=data.get('tags', [])
        )
        template.forms_config = data.get('forms_config', [])
        template.assets = data.get('assets', {})
        template.created_at = data.get('created_at', template.created_at)
        template.updated_at = data.get('updated_at', template.updated_at)
        template.custom_js = data.get('custom_js', '')
        template.custom_css = data.get('custom_css', '')
        template.metadata = data.get('metadata', {})
        return template


class LureManager:
    """Manage saved lure templates and configurations"""
    
    TEMPLATES_DIR = Path('./templates/lures')
    
    def __init__(self, database_path: str = './database.db'):
        self.db_path = database_path
        self.TEMPLATES_DIR.mkdir(parents=True, exist_ok=True)
        self._init_db()
    
    def _init_db(self):
        """Initialize database tables"""
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            # Lure templates table
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS lure_templates (
                    template_id TEXT PRIMARY KEY,
                    name TEXT NOT NULL,
                    description TEXT,
                    url TEXT,
                    clone_id TEXT,
                    tags TEXT,
                    forms_config TEXT,
                    assets TEXT,
                    custom_js TEXT,
                    custom_css TEXT,
                    metadata TEXT,
                    created_at TIMESTAMP,
                    updated_at TIMESTAMP,
                    created_by TEXT,
                    usage_count INTEGER DEFAULT 0
                )
            ''')
            
            # Template deployments tracking
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS template_deployments (
                    deployment_id TEXT PRIMARY KEY,
                    template_id TEXT,
                    deployed_url TEXT,
                    deployed_at TIMESTAMP,
                    victim_count INTEGER DEFAULT 0,
                    captures_count INTEGER DEFAULT 0,
                    status TEXT DEFAULT 'active',
                    notes TEXT,
                    FOREIGN KEY (template_id) REFERENCES lure_templates(template_id)
                )
            ''')
            
            # Template variations
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS template_variations (
                    variation_id TEXT PRIMARY KEY,
                    template_id TEXT,
                    variation_name TEXT,
                    description TEXT,
                    changes TEXT,
                    created_at TIMESTAMP,
                    FOREIGN KEY (template_id) REFERENCES lure_templates(template_id)
                )
            ''')
            
            conn.commit()
            conn.close()
            logger.info("[+] Lure database initialized")
        
        except Exception as e:
            logger.error(f"[-] Database initialization failed: {e}")
    
    def create_template(self, name: str, url: str, clone_id: str,
                       description: str = '', tags: List[str] = None,
                       created_by: str = 'system') -> Dict:
        """Create and save new lure template"""
        
        try:
            # Generate template ID
            template_id = self._generate_template_id(name, url)
            
            # Create template
            template = LureTemplate(
                template_id=template_id,
                name=name,
                description=description,
                url=url,
                clone_id=clone_id,
                tags=tags or []
            )
            
            # Save to database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO lure_templates 
                (template_id, name, description, url, clone_id, tags, created_at, updated_at, created_by)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                template_id,
                name,
                description,
                url,
                clone_id,
                json.dumps(tags or []),
                template.created_at,
                template.updated_at,
                created_by
            ))
            
            conn.commit()
            conn.close()
            
            logger.info(f"[+] Template created: {template_id}")
            return {
                'status': 'ok',
                'template_id': template_id,
                'template': template.to_dict()
            }
        
        except Exception as e:
            logger.error(f"[-] Template creation failed: {e}")
            return {'status': 'error', 'message': str(e)}
    
    def save_forms_config(self, template_id: str, forms_config: List[Dict]) -> bool:
        """Save form configurations to template"""
        
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                UPDATE lure_templates 
                SET forms_config = ?, updated_at = ?
                WHERE template_id = ?
            ''', (json.dumps(forms_config), datetime.utcnow().isoformat(), template_id))
            
            conn.commit()
            conn.close()
            
            logger.info(f"[+] Forms config saved for template: {template_id}")
            return True
        
        except Exception as e:
            logger.error(f"[-] Save forms config failed: {e}")
            return False
    
    def add_custom_js(self, template_id: str, js_code: str) -> bool:
        """Add custom JavaScript to template"""
        
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                UPDATE lure_templates 
                SET custom_js = ?, updated_at = ?
                WHERE template_id = ?
            ''', (js_code, datetime.utcnow().isoformat(), template_id))
            
            conn.commit()
            conn.close()
            
            logger.info(f"[+] Custom JS added to template: {template_id}")
            return True
        
        except Exception as e:
            logger.error(f"[-] Add custom JS failed: {e}")
            return False
    
    def add_custom_css(self, template_id: str, css_code: str) -> bool:
        """Add custom CSS to template"""
        
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                UPDATE lure_templates 
                SET custom_css = ?, updated_at = ?
                WHERE template_id = ?
            ''', (css_code, datetime.utcnow().isoformat(), template_id))
            
            conn.commit()
            conn.close()
            
            logger.info(f"[+] Custom CSS added to template: {template_id}")
            return True
        
        except Exception as e:
            logger.error(f"[-] Add custom CSS failed: {e}")
            return False
    
    def list_templates(self, tags: List[str] = None) -> List[Dict]:
        """List saved templates, optionally filter by tags"""
        
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            if tags:
                # Filter by tags
                query = 'SELECT * FROM lure_templates WHERE '
                query += ' OR '.join(['tags LIKE ?' for _ in tags])
                params = [f'%"{tag}"%' for tag in tags]
                cursor.execute(query, params)
            else:
                cursor.execute('SELECT * FROM lure_templates ORDER BY created_at DESC')
            
            templates = []
            for row in cursor.fetchall():
                templates.append({
                    'template_id': row[0],
                    'name': row[1],
                    'description': row[2],
                    'url': row[3],
                    'clone_id': row[4],
                    'tags': json.loads(row[5] or '[]'),
                    'created_at': row[11],
                    'usage_count': row[14]
                })
            
            conn.close()
            return templates
        
        except Exception as e:
            logger.error(f"[-] List templates failed: {e}")
            return []
    
    def get_template(self, template_id: str) -> Optional[Dict]:
        """Get specific template details"""
        
        try:
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('SELECT * FROM lure_templates WHERE template_id = ?', (template_id,))
            row = cursor.fetchone()
            conn.close()
            
            if not row:
                return None
            
            return {
                'template_id': row[0],
                'name': row[1],
                'description': row[2],
                'url': row[3],
                'clone_id': row[4],
                'tags': json.loads(row[5] or '[]'),
                'forms_config': json.loads(row[6] or '[]'),
                'assets': json.loads(row[7] or '{}'),
                'custom_js': row[8],
                'custom_css': row[9],
                'metadata': json.loads(row[10] or '{}'),
                'created_at': row[11],
                'updated_at': row[12],
                'created_by': row[13],
                'usage_count': row[14]
            }
        
        except Exception as e:
            logger.error(f"[-] Get template failed: {e}")
            return None
    
    def create_deployment(self, template_id: str, deployed_url: str, notes: str = '') -> Dict:
        """Create deployment from template"""
        
        try:
            deployment_id = self._generate_deployment_id(template_id)
            
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO template_deployments 
                (deployment_id, template_id, deployed_url, deployed_at, notes)
                VALUES (?, ?, ?, ?, ?)
            ''', (deployment_id, template_id, deployed_url, datetime.utcnow().isoformat(), notes))
            
            # Increment usage count
            cursor.execute('''
                UPDATE lure_templates SET usage_count = usage_count + 1
                WHERE template_id = ?
            ''', (template_id,))
            
            conn.commit()
            conn.close()
            
            logger.info(f"[+] Deployment created: {deployment_id}")
            return {
                'status': 'ok',
                'deployment_id': deployment_id,
                'deployed_url': deployed_url
            }
        
        except Exception as e:
            logger.error(f"[-] Deployment creation failed: {e}")
            return {'status': 'error', 'message': str(e)}
    
    def _generate_template_id(self, name: str, url: str) -> str:
        """Generate unique template ID"""
        combined = f"{name}_{url}_{datetime.utcnow().isoformat()}"
        return hashlib.sha256(combined.encode()).hexdigest()[:16]
    
    def _generate_deployment_id(self, template_id: str) -> str:
        """Generate unique deployment ID"""
        combined = f"{template_id}_{datetime.utcnow().isoformat()}"
        return hashlib.sha256(combined.encode()).hexdigest()[:16]
    
    def export_template(self, template_id: str, filepath: str) -> bool:
        """Export template as JSON"""
        
        try:
            template = self.get_template(template_id)
            if not template:
                return False
            
            with open(filepath, 'w') as f:
                json.dump(template, f, indent=2)
            
            logger.info(f"[+] Template exported: {filepath}")
            return True
        
        except Exception as e:
            logger.error(f"[-] Template export failed: {e}")
            return False
    
    def import_template(self, filepath: str) -> Optional[str]:
        """Import template from JSON"""
        
        try:
            with open(filepath, 'r') as f:
                template_data = json.load(f)
            
            # Generate new ID
            template_id = self._generate_template_id(
                template_data['name'],
                template_data['url']
            )
            
            # Insert into database
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                INSERT INTO lure_templates 
                (template_id, name, description, url, clone_id, tags, forms_config, 
                 assets, custom_js, custom_css, metadata, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                template_id,
                template_data.get('name'),
                template_data.get('description'),
                template_data.get('url'),
                template_data.get('clone_id'),
                json.dumps(template_data.get('tags', [])),
                json.dumps(template_data.get('forms_config', [])),
                json.dumps(template_data.get('assets', {})),
                template_data.get('custom_js', ''),
                template_data.get('custom_css', ''),
                json.dumps(template_data.get('metadata', {})),
                datetime.utcnow().isoformat(),
                datetime.utcnow().isoformat()
            ))
            
            conn.commit()
            conn.close()
            
            logger.info(f"[+] Template imported: {template_id}")
            return template_id
        
        except Exception as e:
            logger.error(f"[-] Template import failed: {e}")
            return None
