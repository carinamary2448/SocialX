#!/usr/bin/env python3
"""
Enhanced asset management for cloned pages
Handles CSS, JavaScript, images, HTML, and other assets with proper linking
"""

import requests
import hashlib
import mimetypes
import re
import base64
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup
import logging
import time

logger = logging.getLogger(__name__)


class AssetDownloader:
    """Download and cache website assets with complete HTML repair"""
    
    ASSET_TYPES = {
        'css': ['.css'],
        'js': ['.js'],
        'images': ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg', '.ico'],
        'fonts': ['.woff', '.woff2', '.ttf', '.eot', '.otf'],
        'media': ['.mp3', '.mp4', '.webm', '.m4a', '.avi', '.mov'],
        'html': ['.html', '.htm']
    }
    
    MAX_FILE_SIZE = 20 * 1024 * 1024  # 20MB max file size
    
    def __init__(self, clone_dir: str = "./templates/clones", timeout: int = 15):
        self.clone_dir = Path(clone_dir)
        self.clone_dir.mkdir(parents=True, exist_ok=True)
        self.timeout = timeout
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Accept-Encoding': 'gzip, deflate',
            'Cache-Control': 'no-cache'
        })
        self.cache = {}  # URL -> local path
        self.base_url = None
        self.clone_id = None
    
    def download_and_fix_html(self, html: str, base_url: str, clone_path: Path) -> Tuple[str, Dict]:
        """Download all assets and fix HTML to reference them locally"""
        
        self.base_url = base_url
        self.clone_id = clone_path.name
        
        soup = BeautifulSoup(html, 'html.parser')
        assets_info = {
            'css': [],
            'js': [],
            'images': [],
            'fonts': [],
            'videos': [],
            'iframes': [],
            'total_size': 0,
            'download_errors': [],
            'fixed_elements': 0
        }
        
        # 1. Download external stylesheets
        for link in soup.find_all('link', rel='stylesheet'):
            href = link.get('href')
            if href:
                result = self._download_and_replace_asset(href, 'css', clone_path)
                if result:
                    assets_info['css'].append(result)
                    link['href'] = result['local_url']
                    assets_info['total_size'] += result.get('size', 0)
                    assets_info['fixed_elements'] += 1
                    self._postprocess_css_file(result, clone_path, assets_info)
                else:
                    assets_info['download_errors'].append(href)
        
        # 2. Download external scripts
        for script in soup.find_all('script', src=True):
            src = script.get('src')
            if src:
                result = self._download_and_replace_asset(src, 'js', clone_path)
                if result:
                    assets_info['js'].append(result)
                    script['src'] = result['local_url']
                    assets_info['total_size'] += result.get('size', 0)
                    assets_info['fixed_elements'] += 1
                else:
                    assets_info['download_errors'].append(src)
        
        # 3. Process and download images
        for img in soup.find_all('img'):
            src = img.get('src')
            if src:
                result = self._process_image_url(src, 'images', clone_path)
                if result:
                    img['src'] = result['local_url']
                    assets_info['images'].append(result)
                    assets_info['total_size'] += result.get('size', 0)
                    assets_info['fixed_elements'] += 1
                    
                # Handle srcset for responsive images
                srcset = img.get('srcset')
                if srcset:
                    img['srcset'] = self._fix_srcset(srcset, clone_path)
        
        # 4. Process picture elements
        for picture in soup.find_all('picture'):
            for source in picture.find_all('source'):
                src = source.get('srcset')
                if src:
                    source['srcset'] = self._fix_srcset(src, clone_path)
                    assets_info['fixed_elements'] += 1
        
        # 5. Download videos
        for video in soup.find_all('video'):
            for source in video.find_all('source'):
                src = source.get('src')
                if src:
                    result = self._process_media_url(src, 'videos', clone_path)
                    if result:
                        source['src'] = result['local_url']
                        assets_info['videos'].append(result)
                        assets_info['total_size'] += result.get('size', 0)
                        assets_info['fixed_elements'] += 1
        
        # 6. Download audio
        for audio in soup.find_all('audio'):
            for source in audio.find_all('source'):
                src = source.get('src')
                if src:
                    result = self._process_media_url(src, 'media', clone_path)
                    if result:
                        source['src'] = result['local_url']
                        assets_info['total_size'] += result.get('size', 0)
                        assets_info['fixed_elements'] += 1
        
        # 7. Process inline styles for background images
        for element in soup.find_all(style=True):
            style = element.get('style', '')
            new_style = self._fix_css_urls(style, clone_path)
            if new_style != style:
                element['style'] = new_style
                assets_info['fixed_elements'] += 1
        
        # 8. Process inline styles in <style> tags
        for style_tag in soup.find_all('style'):
            if style_tag.string:
                original_css = style_tag.string
                new_css = self._fix_css_urls(original_css, clone_path)
                if new_css != original_css:
                    style_tag.string = new_css
                    assets_info['fixed_elements'] += 1
        
        # 9. Fix favicon
        favicon = soup.find('link', rel='icon')
        if favicon:
            href = favicon.get('href')
            if href:
                result = self._download_and_replace_asset(href, 'images', clone_path)
                if result:
                    favicon['href'] = result['local_url']
                    assets_info['fixed_elements'] += 1
        
        # 10. Fix canonical URLs if they point to the original site
        canonical = soup.find('link', rel='canonical')
        if canonical:
            canonical['href'] = base_url
        
        # 11. Remove tracking/analytics scripts (optional)
        self._remove_tracking_scripts(soup)
        
        # 12. Add data attribute to track this is a clone
        html_tag = soup.find('html')
        if html_tag:
            html_tag['data-clone-id'] = self.clone_id
            html_tag['data-cloned-from'] = base_url
        
        # Return fixed HTML
        fixed_html = str(soup.prettify())
        
        logger.info(f"[+] Fixed {assets_info['fixed_elements']} elements in HTML")
        logger.info(
            f"[+] Downloaded {len(assets_info['css'])} CSS, {len(assets_info['js'])} JS, "
            f"{len(assets_info['images'])} images, {len(assets_info['fonts'])} fonts"
        )
        
        return fixed_html, assets_info
    
    def _process_image_url(self, src: str, asset_type: str, clone_path: Path) -> Optional[Dict]:
        """Process image URLs (handle data URIs, relative, absolute)"""
        
        # Skip data URIs (already embedded)
        if src.startswith('data:'):
            return None
        
        # Skip placeholder services
        if any(x in src.lower() for x in ['placeholder', 'via.placeholder', 'lorempixel', 'dummyimage']):
            return None
        
        return self._download_and_replace_asset(src, asset_type, clone_path)
    
    def _process_media_url(self, src: str, asset_type: str, clone_path: Path) -> Optional[Dict]:
        """Process media URLs with size checking"""
        
        if src.startswith('data:'):
            return None
        
        return self._download_and_replace_asset(src, asset_type, clone_path)
    
    def _fix_srcset(self, srcset: str, clone_path: Path) -> str:
        """Fix srcset attribute to use local assets"""
        
        # Parse srcset format: "url1 1x, url2 2x" or "url1 100w, url2 200w"
        parts = srcset.split(',')
        fixed_parts = []
        
        for part in parts:
            part = part.strip()
            url = part.split()[0]  # Get URL part
            descriptor = ' '.join(part.split()[1:])  # Get descriptor (1x, 2w, etc)
            
            result = self._process_image_url(url, 'images', clone_path)
            if result:
                fixed_parts.append(f"{result['local_url']} {descriptor}".strip())
            else:
                fixed_parts.append(part)
        
        return ', '.join(fixed_parts)
    
    def _is_already_local_url(self, url: str, clone_path: Path) -> bool:
        """True when a CSS/HTML URL is already rewritten or exists on disk."""
        url = (url or '').strip()
        if not url or url.startswith('data:'):
            return True
        if url.startswith(f'/clone/{self.clone_id}/'):
            return True
        if url.startswith('/clone/'):
            return True
        if url.startswith('//'):
            return False
        if url.startswith('http'):
            parsed = urlparse(url)
            if self.base_url:
                base_host = urlparse(self.base_url).netloc
                if parsed.netloc and parsed.netloc != base_host:
                    return True
            if '/clone/' in parsed.path:
                return True
            return False
        local_candidate = (clone_path / url.lstrip('/')).resolve()
        try:
            local_candidate.relative_to(clone_path.resolve())
            if local_candidate.is_file():
                return True
        except ValueError:
            pass
        return False

    def _detect_asset_type(self, url: str) -> str:
        """Pick asset folder based on file extension."""
        ext = Path(urlparse(url).path).suffix.lower()
        for asset_type, extensions in self.ASSET_TYPES.items():
            if ext in extensions:
                return asset_type
        return 'images'

    def _fix_css_urls(self, css: str, clone_path: Path, default_type: str = 'images',
                      resolve_base: str = None) -> str:
        """Fix CSS URLs for background images, fonts, and other references."""
        pattern = r'url\([\'"]?([^)\'\"]+)[\'"]?\)'
        base = resolve_base or self.base_url

        def replace_url(match):
            url = match.group(1).strip()
            if self._is_already_local_url(url, clone_path):
                return match.group(0)
            if url.startswith('http') and self.base_url and self.base_url not in url:
                return match.group(0)
            asset_type = self._detect_asset_type(url) or default_type
            result = self._download_and_replace_asset(url, asset_type, clone_path, resolve_base=base)
            if result:
                return f"url('{result['local_url']}')"
            return match.group(0)

        return re.sub(pattern, replace_url, css, flags=re.IGNORECASE)

    def _postprocess_css_file(self, css_result: Dict, clone_path: Path, assets_info: Dict):
        """Rewrite downloaded CSS to pull in nested assets (fonts, images)."""
        try:
            local_file = self.clone_dir / css_result.get('local_path', '')
            if not local_file.is_file():
                local_file = clone_path / 'css' / Path(css_result['local_url']).name
            if not local_file.is_file():
                return
            with open(local_file, 'r', encoding='utf-8', errors='ignore') as f:
                css_content = f.read()
            css_base = css_result.get('original_url') or self.base_url
            new_css = self._fix_css_urls(css_content, clone_path, resolve_base=css_base)
            if new_css != css_content:
                with open(local_file, 'w', encoding='utf-8') as f:
                    f.write(new_css)
                assets_info['fixed_elements'] += 1
        except Exception as e:
            logger.debug(f"CSS post-process skipped: {e}")
    
    def _remove_tracking_scripts(self, soup: BeautifulSoup):
        """Remove tracking and analytics scripts"""
        
        tracking_domains = [
            'google-analytics',
            'analytics',
            'ga.js',
            'gtag',
            'facebook.com/en_US/sdk.js',
            'connect.facebook.net',
            'segment.com',
            'optimizely.com',
            'mixpanel.com'
        ]
        
        for script in soup.find_all('script'):
            src = script.get('src', '')
            content = script.string or ''
            
            for domain in tracking_domains:
                if domain.lower() in src.lower() or domain.lower() in content.lower():
                    script.decompose()
                    break
    
    def _download_and_replace_asset(self, url: str, asset_type: str,
                                   clone_path: Path, resolve_base: str = None) -> Optional[Dict]:
        """Download asset and return local path info"""
        
        try:
            if self._is_already_local_url(url, clone_path):
                return None

            base = resolve_base or self.base_url
            full_url = urljoin(base, url) if base else url

            if self._is_already_local_url(full_url, clone_path):
                return None
            
            # Check cache first
            if full_url in self.cache:
                return self.cache[full_url]
            
            # Download asset
            logger.debug(f"[*] Downloading asset: {full_url}")
            
            response = self.session.get(full_url, timeout=self.timeout, allow_redirects=True, stream=True)
            response.raise_for_status()
            
            # Check content length before downloading
            content_length = response.headers.get('content-length')
            if content_length and int(content_length) > self.MAX_FILE_SIZE:
                logger.warning(f"[!] Asset too large ({int(content_length) / 1024 / 1024:.1f}MB), skipping: {full_url}")
                return None
            
            # Download content
            content = response.content
            
            # Final size check
            if len(content) > self.MAX_FILE_SIZE:
                logger.warning(f"[!] Downloaded asset too large, skipping: {full_url}")
                return None
            
            # Generate filename
            filename = self._generate_asset_filename(full_url, asset_type)
            
            # Create asset directory
            asset_path = clone_path / asset_type
            asset_path.mkdir(parents=True, exist_ok=True)
            
            # Save asset
            local_file = asset_path / filename
            with open(local_file, 'wb') as f:
                f.write(content)
            
            # Generate local URL (always use forward slashes for web)
            local_url = f"/clone/{self.clone_id}/{asset_type}/{filename}"
            
            result = {
                'original_url': full_url,
                'local_path': str(local_file.relative_to(self.clone_dir)),
                'local_url': local_url,
                'size': len(content),
                'content_type': response.headers.get('content-type', 'application/octet-stream'),
                'asset_type': asset_type
            }
            
            self.cache[full_url] = result
            logger.debug(f"[+] Asset downloaded: {filename} ({len(content) / 1024:.1f}KB)")
            
            return result
        
        except requests.exceptions.Timeout:
            logger.warning(f"[!] Asset download timeout: {url}")
            return None
        except requests.exceptions.ConnectionError:
            logger.warning(f"[!] Connection error downloading: {url}")
            return None
        except requests.exceptions.RequestException as e:
            logger.warning(f"[!] Asset download failed ({url}): {str(e)}")
            return None
        except Exception as e:
            logger.error(f"[-] Asset processing error: {str(e)}")
            return None
    
    def _generate_asset_filename(self, url: str, asset_type: str) -> str:
        """Generate safe filename for asset"""
        
        # Get original filename
        path = urlparse(url).path
        original_filename = path.split('/')[-1] if path else 'asset'
        
        # Remove query parameters
        if '?' in original_filename:
            original_filename = original_filename.split('?')[0]
        
        # If no extension, add one
        if '.' not in original_filename:
            ext = self.ASSET_TYPES.get(asset_type, [''])[0]
            original_filename += ext
        
        # Generate hash for uniqueness
        url_hash = hashlib.md5(url.encode()).hexdigest()[:8]
        
        # Combine original name with hash
        name_parts = original_filename.rsplit('.', 1)
        if len(name_parts) == 2:
            return f"{name_parts[0]}_{url_hash}.{name_parts[1]}"
        else:
            return f"{original_filename}_{url_hash}"
    
    def optimize_css(self, css_content: str) -> str:
        """Optimize CSS (remove comments, minimize)"""
        
        import re
        
        # Remove comments
        css_content = re.sub(r'/\*.*?\*/', '', css_content, flags=re.DOTALL)
        
        # Remove unnecessary whitespace
        css_content = re.sub(r'\s+', ' ', css_content)
        css_content = re.sub(r'\s*([{}:;,])\s*', r'\1', css_content)
        
        return css_content.strip()
    
    def optimize_javascript(self, js_content: str) -> str:
        """Optimize JavaScript (remove comments, minimize)"""
        
        import re
        
        # Remove single-line comments
        js_content = re.sub(r'//.*?$', '', js_content, flags=re.MULTILINE)
        
        # Remove multi-line comments
        js_content = re.sub(r'/\*.*?\*/', '', js_content, flags=re.DOTALL)
        
        # Remove unnecessary whitespace (careful with strings)
        js_content = re.sub(r'\s+', ' ', js_content)
        
        return js_content.strip()
    
    def inject_tracking_pixel(self, html: str, pixel_url: str) -> str:
        """Inject tracking pixel into HTML"""
        
        # Add pixel to body close tag
        tracking_pixel = f'<img src="{pixel_url}" width="1" height="1" style="display:none;"/>'
        
        if '</body>' in html:
            html = html.replace('</body>', f'{tracking_pixel}\n</body>')
        else:
            html += f'\n{tracking_pixel}'
        
        return html
    
    def clear_cache(self):
        """Clear download cache"""
        self.cache.clear()
        logger.info("[+] Asset cache cleared")


class CdnAssetManager:
    """Manage CDN-hosted assets and provide fallbacks"""
    
    # Common CDN URLs for JavaScript libraries
    CDN_FALLBACKS = {
        'jquery': [
            'https://code.jquery.com/jquery-3.6.0.min.js',
            'https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js'
        ],
        'bootstrap': [
            'https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js',
            'https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.1.3/js/bootstrap.bundle.min.js'
        ],
        'axios': [
            'https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js',
            'https://cdnjs.cloudflare.com/ajax/libs/axios/0.27.2/axios.min.js'
        ]
    }
    
    @staticmethod
    def get_cdn_url(library: str, version: str = 'latest') -> Optional[str]:
        """Get CDN URL for a library"""
        if library in CdnAssetManager.CDN_FALLBACKS:
            return CdnAssetManager.CDN_FALLBACKS[library][0]
        return None
    
    @staticmethod
    def verify_asset_availability(url: str, timeout: int = 5) -> bool:
        """Verify if asset URL is still available"""
        try:
            response = requests.head(url, timeout=timeout, allow_redirects=True)
            return response.status_code == 200
        except:
            return False
