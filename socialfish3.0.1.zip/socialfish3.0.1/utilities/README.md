# Utilities Folder - Testing, Debugging & Analysis Scripts

This folder contains scripts that are not part of the core SocialFish functionality. These are used for testing, debugging, analysis, and maintenance purposes.

## Organization

### Testing Scripts
Scripts for automated testing and validation:

- `automated_test.py` - Basic automated tests
- `automated_browser_test.py` - Browser automation tests
- `automated_browser_advanced.py` - Advanced browser tests
- `comprehensive_test_and_browser.py` - Comprehensive test suite
- `final_comprehensive_tests.py` - Final validation tests
- `quick_test_capture.py` - Quick capture testing

**Usage:**
```bash
python utilities/automated_test.py
python utilities/comprehensive_test_and_browser.py
```

### Debugging Scripts
Scripts for debugging and troubleshooting:

- `comprehensive_debug.py` - Comprehensive system debugging
- `verify_debug_logging.py` - Verify debug logging
- `debug_report.txt` - Debug report output
- `server.stderr.log` - Server error logs
- `server.stdout.log` - Server output logs

**Usage:**
```bash
python utilities/comprehensive_debug.py
```

### Analysis Scripts
Scripts for code and system analysis:

- `analyze_logging.py` - Analyze logging behavior
- `ui_bug_scanner.py` - Scan for UI bugs
- `critical_scanner.py` - Scan for critical issues
- `PROJECT_ANALYSIS_FROM_MD_FILES.txt` - Analysis report

**Usage:**
```bash
python utilities/ui_bug_scanner.py
python utilities/critical_scanner.py
```

### Database & Schema Management
Scripts for database operations:

- `check_schema.py` - Verify database schema
- `check_and_fix_schema.py` - Check and fix schema issues
- `verify_schema.py` - Comprehensive schema verification
- `fix_schema.py` - Fix schema problems
- `fix_data_capture.py` - Fix data capture issues
- `db_migration.py` (in /core) - Handle migrations

**Usage:**
```bash
python utilities/check_schema.py
python utilities/check_and_fix_schema.py
python utilities/fix_schema.py
```

### Cleanup & Maintenance
Scripts for maintenance:

- `cleanup_duplicates.py` - Remove duplicate data
- `cleanup_route_duplicates.py` - Remove duplicate routes

**Usage:**
```bash
python utilities/cleanup_duplicates.py
python utilities/cleanup_route_duplicates.py
```

### System Audit
Scripts for comprehensive system audits:

- `comprehensive_bug_audit.py` - Bug audit
- `comprehensive_system_fixer.py` - System fixes
- `final_system_verification.py` - Final verification
- `COMPREHENSIVE_BUG_AUDIT_REPORT.txt` - Audit reports

**Usage:**
```bash
python utilities/comprehensive_bug_audit.py
python utilities/comprehensive_system_fixer.py
python utilities/final_system_verification.py
```

### Utilities & Helpers
Utility modules and decorators:

- `auto_logging_decorator.py` - Auto-logging decorator
- `automation_master.py` - Master automation script

**Usage:**
```python
from utilities.auto_logging_decorator import auto_log
```

## Running Tests

### Run All Tests
```bash
cd utilities
python -m pytest . -v
```

### Run Specific Test
```bash
python -m pytest comprehensive_test_and_browser.py -v
```

### Run with Coverage
```bash
python -m pytest . --cov=../core --cov=../features
```

## Debugging Workflow

1. **System Check**
   ```bash
   python comprehensive_debug.py
   ```

2. **Verify Schema**
   ```bash
   python check_schema.py
   ```

3. **Analyze Issues**
   ```bash
   python ui_bug_scanner.py
   python critical_scanner.py
   ```

4. **Fix Problems**
   ```bash
   python check_and_fix_schema.py
   python comprehensive_system_fixer.py
   ```

5. **Verify Fixes**
   ```bash
   python final_system_verification.py
   ```

## Log Files

- `debug_report.txt` - Last debug report
- `server.stderr.log` - Server errors
- `server.stdout.log` - Server output
- `test_output.txt` - Test output

View logs:
```bash
cat server.stderr.log
tail -f server.stdout.log
```

## Environment Setup

Ensure the parent directory is in Python path:
```bash
export PYTHONPATH="${PYTHONPATH}:./.."
cd utilities
python script_name.py
```

Or in the script:
```python
import sys
sys.path.insert(0, '..')
```

## Troubleshooting

### Import Errors
If you get import errors, ensure:
1. Python path is set correctly
2. All dependencies are installed
3. You're running from the project root

### Database Errors
1. Check `check_schema.py` for schema issues
2. Run `fix_schema.py` to fix problems
3. Verify with `verify_schema.py`

### Test Failures
1. Check logs in `debug_report.txt`
2. Run `comprehensive_debug.py` for system status
3. Review `server.stderr.log` for errors

## Contributing

When adding new scripts:
1. Place in appropriate subdirectory
2. Add docstring header
3. Include usage examples
4. Update this README

## Notes

- These scripts should NOT be moved to production
- Use in development/testing environments only
- Always backup database before running fix scripts
- Review logs carefully before and after changes
