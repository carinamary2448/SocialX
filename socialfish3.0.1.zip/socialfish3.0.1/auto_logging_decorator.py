#!/usr/bin/env python3
"""
AUTO-LOGGING DECORATOR
Wraps all route handlers with comprehensive logging
"""

import functools
import traceback
import time
import json
from datetime import datetime

def auto_log_route(f):
    """Decorator to automatically log all route handler activities"""
    @functools.wraps(f)
    def decorated_function(*args, **kwargs):
        func_name = f.__name__
        request_method = g.get_current_request().method if hasattr(g, 'get_current_request') else 'UNKNOWN'
        request_path = g.get_current_request().path if hasattr(g, 'get_current_request') else request.path
        
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'function': func_name,
            'method': request_method,
            'path': request_path,
            'args': str(args)[:100],
            'kwargs': str(kwargs)[:100]
        }
        
        print(f"[LOG:START] {func_name} | {request_method} {request_path} | {datetime.now()}")
        logger.debug(f"[ROUTE_START] {json.dumps(log_entry)}")
        
        start_time = time.time()
        try:
            result = f(*args, **kwargs)
            elapsed = time.time() - start_time
            logger.info(f"[ROUTE_END] {func_name} completed in {elapsed:.3f}s")
            print(f"[LOG:END] {func_name} | Success | {elapsed:.3f}s")
            return result
        except Exception as e:
            elapsed = time.time() - start_time
            error_trace = traceback.format_exc()
            logger.error(f"[ROUTE_ERROR] {func_name}: {str(e)} | Elapsed: {elapsed:.3f}s")
            logger.error(f"[TRACEBACK]\n{error_trace}")
            print(f"[LOG:ERROR] {func_name} | {str(e)[:100]}")
            raise
    
    return decorated_function
