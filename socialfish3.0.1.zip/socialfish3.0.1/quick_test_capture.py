#!/usr/bin/env python3
"""Quick test for real data capture - simplified version"""

import requests
import json
import sqlite3

BASE = "http://127.0.0.1:5000"

print("\n" + "="*80)
print("QUICK REAL DATA CAPTURE TEST")
print("="*80 + "\n")

# Test 1: Credential Webhook
print("[TEST 1] Credential Capture Webhook")
print("-" * 80)
try:
    data = {
        "email": "quicktest@example.com",
        "username": "quickuser",
        "password": "quickpass123"
    }
    r = requests.post(f"{BASE}/api/credential-webhook", data=data, timeout=5)
    print(f"Status: {r.status_code}")
    print(f"Response: {r.text}")
    
    if r.status_code == 200:
        resp = r.json()
        cred_id = resp.get('id')
        print(f"[+] Credential captured! ID: {cred_id}")
        
        # Verify in database
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        cursor.execute("SELECT email, username FROM creds WHERE id = ?", (cred_id,))
        row = cursor.fetchone()
        if row:
            print(f"[+] Verified in database: {row}")
        conn.close()
    else:
        print(f"[-] Failed: {r.text}")
except Exception as e:
    print(f"[-] Error: {e}")

# Test 2: Generate Lure
print("\n[TEST 2] Lure Generation")
print("-" * 80)
try:
    data = {
        "template_id": 1,
        "target_url": "https://example.com/login",
        "campaign_name": "quicktest"
    }
    r = requests.post(f"{BASE}/api/generate-lure", json=data, timeout=5)
    print(f"Status: {r.status_code}")
    print(f"Response: {r.text}")
    
    if r.status_code == 200:
        try:
            resp = r.json()
            print(f"[+] Lure generated: {resp.get('lure_url')}")
        except:
            print(f"[*] Response not JSON, checking database directly")
except Exception as e:
    print(f"[-] Error: {e}")

# Test 3: Sessions API
print("\n[TEST 3] Sessions List")
print("-" * 80)
try:
    r = requests.get(f"{BASE}/api/sessions", timeout=5)
    print(f"Status: {r.status_code}")
    print(f"Response: {r.text[:200]}")
except Exception as e:
    print(f"[-] Error: {e}")

# Test 4: Credentials API
print("\n[TEST 4] Credentials List")
print("-" * 80)
try:
    r = requests.get(f"{BASE}/api/credentials", timeout=5)
    print(f"Status: {r.status_code}")
    print(f"Response: {r.text[:200]}")
except Exception as e:
    print(f"[-] Error: {e}")

print("\n" + "="*80)
print("DIRECT DATABASE CHECK")
print("="*80 + "\n")

conn = sqlite3.connect('database.db')
cursor = conn.cursor()

# Count credentials
cursor.execute("SELECT COUNT(*) FROM creds")
cred_count = cursor.fetchone()[0]
print(f"[*] Total credentials in database: {cred_count}")

# Show latest
cursor.execute("SELECT id, email, username, password FROM creds ORDER BY id DESC LIMIT 3")
rows = cursor.fetchall()
for row in rows:
    print(f"    ID {row[0]}: {row[1]} / {row[2]} / {row[3]}")

# Count lures
cursor.execute("SELECT COUNT(*) FROM lure_urls")
lure_count = cursor.fetchone()[0]
print(f"\n[*] Total lures in database: {lure_count}")

if lure_count > 0:
    cursor.execute("SELECT id, target_url, click_count FROM lure_urls ORDER BY id DESC LIMIT 3")
    rows = cursor.fetchall()
    for row in rows:
        print(f"    ID {row[0]}: {row[1]} (clicks: {row[2]})")

conn.close()

print("\n[+] Test complete!")
