#!/usr/bin/env python3
"""
COMPREHENSIVE BUG AUDIT & FIX SUITE (Windows Compatible)
Audits entire codebase for critical issues and generates detailed report
"""

import os
import re
import json
import sys
import sqlite3
from pathlib import Path
from datetime import datetime

class ComprehensiveAudit:
    def __init__(self):
        self.bugs_found = []
        self.warnings = []
        self.fixes_needed = []
        
    def log_issue(self, severity, category, file, description):
        issue = {
            'severity': severity,
            'category': category,
            'file': file,
            'description': description,
            'timestamp': datetime.now().isoformat()
        }
        self.bugs_found.append(issue)
        severity_prefix = '[CRITICAL]' if severity == 'CRITICAL' else '[HIGH]' if severity == 'HIGH' else '[MEDIUM]'
        print(f"{severity_prefix} {category}: {file} - {description}")
        
    def log_warning(self, message):
        self.warnings.append(message)
        print(f"  WARNING: {message}")

    def scan_html_buttons(self):
        """Scan templates for missing buttons"""
        print("\n" + "="*80)
        print("[1/6] SCANNING HTML TEMPLATES FOR MISSING BUTTONS")
        print("="*80)
        
        button_patterns = [
            ('View Detail', r'View.*Detail', 'Data viewing action'),
            ('Edit', r'Edit|Modify', 'Edit action'),
            ('Delete', r'Delete|Remove', 'Delete action'),
            ('Export', r'Export|Download', 'Export action'),
            ('Refresh', r'Refresh|Reload', 'Refresh data'),
            ('Back/Home', r'Back|Home|Dashboard', 'Navigation'),
            ('Action Menu', r'Actions|Menu|More', 'Multiple actions'),
        ]
        
        html_files = list(Path('templates').rglob('*.html'))
        
        for html_file in html_files:
            try:
                content = html_file.read_text(encoding='utf-8')
                
                # Check for button existence
                button_count = len(re.findall(r'<button|<a.*btn', content, re.IGNORECASE))
                
                if button_count < 3:
                    self.log_issue('HIGH', 'Missing Buttons', str(html_file), 
                                 f'Only {button_count} buttons found (expected 5+)')
                
                # Check for specific missing buttons in admin pages
                if 'admin' in str(html_file).lower():
                    if 'index.html' in str(html_file) and button_count < 8:
                        self.log_issue('CRITICAL', 'Dashboard Incomplete', str(html_file),
                                     'Dashboard missing action buttons')
                        self.fixes_needed.append({
                            'file': str(html_file),
                            'action': 'Add View/Edit/Delete/Export buttons to tables'
                        })
                        
            except Exception as e:
                self.log_warning(f"Could not read {html_file}: {str(e)}")

    def scan_clone_functionality(self):
        """Scan for clone functionality issues"""
        print("\n" + "="*80)
        print("[2/6] SCANNING CLONE FUNCTIONALITY")
        print("="*80)
        
        try:
            sf_content = Path('SocialFish.py').read_text(encoding='utf-8')
            
            # Check for clone routes
            clone_routes = re.findall(r'@app\.route\(["\'].*clone.*["\']\)', sf_content, re.IGNORECASE)
            
            if len(clone_routes) < 2:
                self.log_issue('HIGH', 'Clone Routes', 'SocialFish.py',
                             f'Only {len(clone_routes)} clone-related routes found')
            
            # Check for URL generation in clone route
            if 'def.*clone' in sf_content:
                clone_section = re.search(r'def.*clone.*?(?=@app\.route|$)', sf_content, re.DOTALL)
                if clone_section:
                    if '3' in clone_section.group() or 'urls' in clone_section.group():
                        print("  [*] 3-URL generation found in clone functionality")
                    else:
                        self.log_issue('HIGH', 'Missing URLs', 'SocialFish.py',
                                     'Clone route not generating 3 URLs')
            
            # Check recording studio template
            studio_file = Path('templates/admin/recording_studio_real.html')
            if studio_file.exists():
                studio_content = studio_file.read_text(encoding='utf-8')
                
                # Check for form handling
                if 'fetch' not in studio_content and 'XMLHttpRequest' not in studio_content:
                    self.log_issue('HIGH', 'No API Call', str(studio_file),
                                 'Clone form not making API calls to backend')
                
                # Check for response display
                if 'response' not in studio_content.lower():
                    self.log_issue('HIGH', 'No Response Display', str(studio_file),
                                 'Clone form not displaying server response')
                    
        except Exception as e:
            self.log_warning(f"Clone scan error: {str(e)}")

    def scan_logging(self):
        """Scan for logging/error visibility"""
        print("\n" + "="*80)
        print("[3/6] SCANNING FOR LOGGING & ERROR VISIBILITY")
        print("="*80)
        
        try:
            sf_content = Path('SocialFish.py').read_text(encoding='utf-8')
            
            # Count print statements
            print_count = len(re.findall(r'print\(', sf_content))
            routes_count = len(re.findall(r'@app\.route', sf_content))
            
            logs_per_route = print_count / max(1, routes_count)
            
            if logs_per_route < 1:
                self.log_issue('HIGH', 'Insufficient Logging', 'SocialFish.py',
                             f'Only {print_count} print statements for {routes_count} routes')
                self.fixes_needed.append({
                    'file': 'SocialFish.py',
                    'action': 'Add logging to all route handlers (print statements)'
                })
            
            # Check for try-except blocks
            try_except_count = len(re.findall(r'try:|except', sf_content))
            
            if try_except_count < 10:
                self.log_issue('HIGH', 'Missing Error Handling', 'SocialFish.py',
                             f'Only {try_except_count // 2} try-except blocks found')
                self.fixes_needed.append({
                    'file': 'SocialFish.py',
                    'action': 'Add try-except blocks to all critical functions'
                })
            
        except Exception as e:
            self.log_warning(f"Logging scan error: {str(e)}")

    def scan_database(self):
        """Scan database schema for issues"""
        print("\n" + "="*80)
        print("[4/6] SCANNING DATABASE SCHEMA")
        print("="*80)
        
        try:
            db_path = 'database.db'
            if not os.path.exists(db_path):
                self.log_issue('HIGH', 'Database Missing', db_path, 'Database file not found')
                return
            
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            
            # Check creds table structure
            cursor.execute("PRAGMA table_info(creds)")
            columns = cursor.fetchall()
            column_names = [col[1] for col in columns]
            
            required_columns = ['email', 'password', 'username', 'cookies', 'csrf_tokens']
            missing_cols = [col for col in required_columns if col not in column_names]
            
            if missing_cols:
                self.log_issue('HIGH', 'Database Schema', 'creds table',
                             f'Missing columns: {", ".join(missing_cols)}')
            else:
                print("  [*] Credentials table has all required columns")
            
            # Count records
            cursor.execute("SELECT COUNT(*) FROM creds")
            cred_count = cursor.fetchone()[0]
            print(f"  [*] Credentials captured: {cred_count}")
            
            conn.close()
            
        except Exception as e:
            self.log_issue('MEDIUM', 'Database Error', 'database.db', str(e))

    def scan_function_connectivity(self):
        """Scan for function connectivity and data flow"""
        print("\n" + "="*80)
        print("[5/6] SCANNING FUNCTION CONNECTIVITY")
        print("="*80)
        
        try:
            sf_content = Path('SocialFish.py').read_text(encoding='utf-8')
            
            # Check for critical function definitions
            critical_functions = [
                'extract_credential_fields',
                'generate_lure',
                'clone_website',
                'capture_credentials'
            ]
            
            for func in critical_functions:
                if f'def {func}' in sf_content:
                    # Check if function is called
                    call_pattern = rf'{func}\s*\('
                    call_count = len(re.findall(call_pattern, sf_content))
                    
                    if call_count < 2:  # defined + called at least once
                        self.log_issue('HIGH', 'Unused Function', 'SocialFish.py',
                                     f'Function "{func}" defined but not called')
                    else:
                        print(f"  [*] Function '{func}' is connected ({call_count} usages)")
                else:
                    self.log_issue('CRITICAL', 'Missing Function', 'SocialFish.py',
                                 f'Critical function "{func}" not found')
            
            # Check for API endpoint connections
            api_endpoints = re.findall(r'@app\.route\(["\']\/api\/.*["\']\)', sf_content)
            print(f"  [*] Found {len(api_endpoints)} API endpoints")
            
        except Exception as e:
            self.log_warning(f"Connectivity scan error: {str(e)}")

    def scan_test_automation(self):
        """Scan for test automation completeness"""
        print("\n" + "="*80)
        print("[6/6] SCANNING TEST AUTOMATION")
        print("="*80)
        
        try:
            test_files = list(Path('.').glob('*test*.py'))
            
            if not test_files:
                self.log_issue('HIGH', 'No Tests', '.', 'No test files found')
                return
            
            print(f"  [*] Found {len(test_files)} test files")
            
            total_tests = 0
            for test_file in test_files:
                content = test_file.read_text(encoding='utf-8')
                test_count = len(re.findall(r'def test_|assert ', content))
                total_tests += test_count
                print(f"     - {test_file.name}: {test_count} tests/assertions")
            
            if total_tests < 20:
                self.log_issue('MEDIUM', 'Low Test Coverage', 'Test suite',
                             f'Only {total_tests} tests found (expecting 40+)')
            else:
                print(f"  [*] Total test coverage: {total_tests} assertions")
            
        except Exception as e:
            self.log_warning(f"Test scan error: {str(e)}")

    def generate_report(self):
        """Generate comprehensive report"""
        print("\n" + "="*80)
        print("COMPREHENSIVE AUDIT REPORT")
        print("="*80)
        
        # Summary
        print(f"\nTOTAL ISSUES FOUND: {len(self.bugs_found)}")
        print(f"CRITICAL ISSUES: {len([b for b in self.bugs_found if b['severity'] == 'CRITICAL'])}")
        print(f"HIGH PRIORITY: {len([b for b in self.bugs_found if b['severity'] == 'HIGH'])}")
        print(f"WARNINGS: {len(self.warnings)}")
        
        # Issues by category
        print("\n" + "-"*80)
        print("ISSUES BY CATEGORY:")
        print("-"*80)
        
        categories = {}
        for bug in self.bugs_found:
            cat = bug['category']
            if cat not in categories:
                categories[cat] = []
            categories[cat].append(bug)
        
        for category, issues in sorted(categories.items()):
            print(f"\n{category} ({len(issues)} issues):")
            for issue in issues:
                print(f"  - [{issue['severity']}] {issue['description']} ({issue['file']})")
        
        # Recommended fixes
        print("\n" + "-"*80)
        print("RECOMMENDED FIXES:")
        print("-"*80)
        
        for i, fix in enumerate(self.fixes_needed, 1):
            print(f"{i}. {fix['file']}")
            print(f"   Action: {fix['action']}")
        
        # Save report
        report_file = 'COMPREHENSIVE_BUG_AUDIT_REPORT.txt'
        with open(report_file, 'w') as f:
            f.write("COMPREHENSIVE AUDIT REPORT\n")
            f.write("="*80 + "\n")
            f.write(f"Generated: {datetime.now().isoformat()}\n\n")
            f.write(f"Total Issues: {len(self.bugs_found)}\n")
            f.write(f"Critical: {len([b for b in self.bugs_found if b['severity'] == 'CRITICAL'])}\n")
            f.write(f"High Priority: {len([b for b in self.bugs_found if b['severity'] == 'HIGH'])}\n\n")
            
            for bug in self.bugs_found:
                f.write(f"[{bug['severity']}] {bug['category']}\n")
                f.write(f"  File: {bug['file']}\n")
                f.write(f"  Description: {bug['description']}\n\n")
        
        print(f"\nReport saved to: {report_file}")

    def run_full_audit(self):
        """Run complete audit"""
        print("\n" + "="*80)
        print("RUNNING COMPREHENSIVE SYSTEM AUDIT")
        print("="*80)
        
        self.scan_html_buttons()
        self.scan_clone_functionality()
        self.scan_logging()
        self.scan_database()
        self.scan_function_connectivity()
        self.scan_test_automation()
        self.generate_report()

if __name__ == '__main__':
    audit = ComprehensiveAudit()
    audit.run_full_audit()
