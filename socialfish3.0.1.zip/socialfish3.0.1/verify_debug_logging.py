#!/usr/bin/env python3
"""
Debug Logging Verification Script
Tests terminal output visibility for lure generation and session retrieval
Run this AFTER starting the server with: python SocialFish.py admin password
"""

import requests
import time
import json
import sys
from datetime import datetime

BASE_URL = "http://127.0.0.1:5000"
ADMIN_USER = "admin"
ADMIN_PASS = "password"

# Colors for output
GREEN = '\033[92m'
RED = '\033[91m'
YELLOW = '\033[93m'
BLUE = '\033[94m'
RESET = '\033[0m'

def print_section(title):
    """Print a formatted section header"""
    print(f"\n{BLUE}{'='*80}")
    print(f"{title}")
    print(f"{'='*80}{RESET}\n")

def test_server_connection():
    """Test if server is reachable"""
    print_section("TEST 1: Server Connection")
    try:
        response = requests.get(f"{BASE_URL}/", timeout=5)
        print(f"{GREEN}[OK] Server is running on {BASE_URL}{RESET}")
        return True
    except requests.exceptions.ConnectionError:
        print(f"{RED}✗ Cannot connect to server at {BASE_URL}")
        print(f"  Start the server with: python SocialFish.py {ADMIN_USER} {ADMIN_PASS}{RESET}")
        return False
    except Exception as e:
        print(f"{RED}✗ Connection error: {e}{RESET}")
        return False

def test_lure_generation(template_id=1, target_url="https://linkedin.com/login"):
    """Test lure generation with debug output"""
    print_section("TEST 2: Lure Generation (Watch Terminal)")
    print(f"{YELLOW}[INFO] Sending request to /api/generate-lure...{RESET}")
    print(f"  - Template ID: {template_id}")
    print(f"  - Target URL: {target_url}")
    print(f"  - Campaign: 'Debug Test {datetime.now().strftime('%H:%M:%S')}'")
    print(f"\n{YELLOW}[ACTION] Check your terminal running SocialFish.py!{RESET}")
    print(f"{YELLOW}[EXPECTED] You should see:{RESET}")
    print(f"""
  ================================================================================
  [LURE START] Generating lure URL...
  [LURE] Template ID: {template_id}
  [LURE] Target URL: {target_url}
  [LURE] Campaign: Debug Test ...
  [LURE] Generated hash: ...
  [LURE] Lure URL: ...
    [OK] Lure stored successfully!
    [OK] Session created for lure
    [OK] WebSocket broadcast sent
  ================================================================================
    """)
    
    time.sleep(1)  # Give user time to prepare
    
    try:
        response = requests.post(
            f"{BASE_URL}/api/generate-lure",
            json={
                "template_id": template_id,
                "target_url": target_url,
                "campaign_name": f"Debug Test {datetime.now().strftime('%H:%M:%S')}"
            },
            timeout=10
        )
        
        if response.status_code == 200:
            data = response.json()
            print(f"\n{GREEN}[OK] Lure generation successful!{RESET}")
            print(f"  Response: {json.dumps(data, indent=2)}")
            return data
        else:
            print(f"{RED}✗ Request failed with status {response.status_code}{RESET}")
            print(f"  Response: {response.text}")
            return None
    except Exception as e:
        print(f"{RED}✗ Error: {e}{RESET}")
        return None

def test_sessions_retrieval():
    """Test sessions retrieval with debug output"""
    print_section("TEST 3: Sessions Retrieval (Watch Terminal)")
    print(f"{YELLOW}[INFO] Sending request to /api/sessions...{RESET}")
    print(f"\n{YELLOW}[ACTION] Check your terminal running SocialFish.py!{RESET}")
    print(f"{YELLOW}[EXPECTED] You should see:{RESET}")
    print(f"""
  [DEBUG] Sessions table columns: [...]
  [DEBUG] Selected columns for query: [...]
  [DEBUG] Executing query: SELECT ...
  [DEBUG] Fetched X sessions from database
  [DEBUG] Session 0: {{...}}
  [DEBUG] Session 1: {{...}}
    [OK] Returning X sessions
    """)
    
    time.sleep(1)
    
    try:
        response = requests.get(
            f"{BASE_URL}/api/sessions",
            timeout=10
        )
        
        if response.status_code == 200:
            data = response.json()
            sessions = data.get('data', [])
            print(f"\n{GREEN}[OK] Sessions retrieved successfully!{RESET}")
            print(f"  Total sessions: {len(sessions)}")
            
            if sessions:
                print(f"\n  Latest session:")
                latest = sessions[0]
                print(f"    - ID: {latest.get('id')}")
                print(f"    - URL: {latest.get('url')}")
                print(f"    - victim_ip: {latest.get('victim_ip')}")
                print(f"    - status: {latest.get('status')}")
                print(f"    - forms_detected: {latest.get('forms_detected')}")
                
                # Check for null URL
                if latest.get('url') is None:
                    print(f"\n{YELLOW}[!] WARNING: url field is NULL{RESET}")
                    print(f"    This means target URL was not captured")
                else:
                    print(f"\n{GREEN}[OK] URL field populated: {latest.get('url')}{RESET}")
            else:
                print(f"  {YELLOW}[*] No sessions in database yet{RESET}")
            
            return data
        else:
            print(f"{RED}✗ Request failed with status {response.status_code}{RESET}")
            print(f"  Response: {response.text}")
            return None
    except Exception as e:
        print(f"{RED}✗ Error: {e}{RESET}")
        return None

def test_database_schema():
    """Test database schema"""
    print_section("TEST 4: Database Schema Check")
    try:
        import sqlite3
        import os
        
        db_path = "database.db"
        if not os.path.exists(db_path):
            print(f"{RED}✗ database.db not found{RESET}")
            return False
        
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Check lure_urls table
        cursor.execute("PRAGMA table_info(lure_urls)")
        lure_cols = {row[1]: row[2] for row in cursor.fetchall()}
        
        print(f"{GREEN}[OK] lure_urls table columns:{RESET}")
        for col_name, col_type in lure_cols.items():
            marker = "OK" if col_name == "target_url" else " "
            print(f"    [{marker}] {col_name}: {col_type}")
        
        if "target_url" not in lure_cols:
            print(f"\n{RED}[X] target_url column missing from lure_urls!{RESET}")
            print(f"  Add with: ALTER TABLE lure_urls ADD COLUMN target_url TEXT;")
            return False
        
        # Check sessions table
        cursor.execute("PRAGMA table_info(sessions)")
        session_cols = {row[1]: row[2] for row in cursor.fetchall()}
        
        print(f"\n{GREEN}[OK] sessions table columns:{RESET}")
        for col_name, col_type in session_cols.items():
            marker = "OK" if col_name == "url" else " "
            print(f"    [{marker}] {col_name}: {col_type}")
        
        if "url" not in session_cols:
            print(f"\n{RED}✗ url column missing from sessions!{RESET}")
            return False
        
        conn.close()
        print(f"\n{GREEN}[OK] Database schema is valid{RESET}")
        return True
        
    except ImportError:
        print(f"{YELLOW}[!] sqlite3 not available, skipping schema check{RESET}")
        return True
    except Exception as e:
        print(f"{RED}✗ Error: {e}{RESET}")
        return False

def main():
    """Run all tests"""
    print(f"\n{BLUE}╔════════════════════════════════════════════════════════════╗")
    print(f"║ DEBUG LOGGING VERIFICATION SCRIPT                           ║")
    print(f"║ Tests: Terminal Debug Output, Lure Generation, Sessions     ║")
    print(f"╚════════════════════════════════════════════════════════════╝{RESET}\n")
    
    # Test 1: Connection
    if not test_server_connection():
        sys.exit(1)
    
    # Test 2: Database Schema
    if not test_database_schema():
        print(f"\n{YELLOW}[!] Schema issues detected, but continuing...{RESET}")
    
    time.sleep(2)
    
    # Test 3: Lure Generation
    lure_data = test_lure_generation()
    
    time.sleep(2)
    
    # Test 4: Sessions Retrieval
    sessions_data = test_sessions_retrieval()
    
    # Final Summary
    print_section("SUMMARY")
    
    checks = {
        "Server Connection": test_server_connection(),
        "Database Schema": test_database_schema(),
        "Lure Generation": lure_data is not None,
        "Sessions Retrieval": sessions_data is not None,
    }
    
    passed = sum(1 for v in checks.values() if v)
    total = len(checks)
    
    for check, result in checks.items():
        status = f"{GREEN}[OK] PASS{RESET}" if result else f"{RED}[X] FAIL{RESET}"
        print(f"  {check}: {status}")
    
    print(f"\n  {GREEN}Result: {passed}/{total} tests passed{RESET}")
    
    if passed == total:
        print(f"\n{GREEN}[OK] All tests passed! Debug logging is working correctly.{RESET}")
        print(f"  The system is now ready for real phishing campaigns.")
        print(f"  Debug output will be visible in the terminal running SocialFish.py")
        sys.exit(0)
    else:
        print(f"\n{YELLOW}[!] Some tests failed. Check the errors above.{RESET}")
        sys.exit(1)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n{YELLOW}[*] Test interrupted by user{RESET}")
        sys.exit(0)
