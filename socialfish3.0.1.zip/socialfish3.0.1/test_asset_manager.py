#!/usr/bin/env python3
"""
Test script for enhanced asset manager
Verifies that cloned pages have all assets properly downloaded and linked
"""

import sys
import json
from pathlib import Path
import logging

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='[%(levelname)s] %(name)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Add project to path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from core.real_cloner import RealCloner
from features.cloning import AssetDownloader


def test_asset_downloader():
    """Test basic asset downloader functionality"""
    logger.info("="*60)
    logger.info("TEST 1: Asset Downloader Initialization")
    logger.info("="*60)
    
    try:
        downloader = AssetDownloader(clone_dir="templates/test_clones")
        logger.info(f"[✓] AssetDownloader initialized")
        logger.info(f"    Clone dir: {downloader.clone_dir}")
        logger.info(f"    Max file size: {downloader.MAX_FILE_SIZE / 1024 / 1024}MB")
        logger.info(f"    Timeout: {downloader.timeout}s")
        return True
    except Exception as e:
        logger.error(f"[✗] Failed to initialize AssetDownloader: {e}")
        return False


def test_html_parsing():
    """Test HTML parsing without actual downloads"""
    logger.info("\n" + "="*60)
    logger.info("TEST 2: HTML Parsing")
    logger.info("="*60)
    
    try:
        from bs4 import BeautifulSoup
        
        html = """
        <html>
            <head>
                <link rel="stylesheet" href="/css/style.css">
                <link rel="stylesheet" href="https://cdn.example.com/bootstrap.css">
                <script src="/js/app.js"></script>
                <script src="https://cdn.example.com/jquery.js"></script>
                <link rel="icon" href="/favicon.ico">
            </head>
            <body>
                <img src="/images/logo.png">
                <img src="https://example.com/banner.jpg" srcset="
                    https://example.com/banner-small.jpg 480w,
                    https://example.com/banner-large.jpg 1920w
                ">
                <video src="/videos/intro.mp4" poster="/images/poster.jpg"></video>
                <form action="/login" method="POST">
                    <input type="text" name="username">
                    <input type="password" name="password">
                </form>
            </body>
        </html>
        """
        
        soup = BeautifulSoup(html, 'html.parser')
        
        # Count elements
        links = soup.find_all('link')
        scripts = soup.find_all('script')
        images = soup.find_all('img')
        videos = soup.find_all('video')
        forms = soup.find_all('form')
        
        logger.info(f"[✓] HTML parsed successfully")
        logger.info(f"    Links: {len(links)}")
        logger.info(f"    Scripts: {len(scripts)}")
        logger.info(f"    Images: {len(images)}")
        logger.info(f"    Videos: {len(videos)}")
        logger.info(f"    Forms: {len(forms)}")
        
        # Check for srcset
        srcset_count = sum(1 for img in images if img.get('srcset'))
        logger.info(f"    Responsive images: {srcset_count}")
        
        return True
    except Exception as e:
        logger.error(f"[✗] HTML parsing failed: {e}")
        return False


def test_real_cloner():
    """Test RealCloner initialization"""
    logger.info("\n" + "="*60)
    logger.info("TEST 3: RealCloner Initialization")
    logger.info("="*60)
    
    try:
        cloner = RealCloner(clone_dir="templates/test_clones")
        logger.info(f"[✓] RealCloner initialized")
        logger.info(f"    Clone dir: {cloner.clone_dir}")
        logger.info(f"    Session headers configured")
        logger.info(f"    Asset downloader integrated")
        
        # Check clone ID generation
        test_url = "https://example.com/page"
        clone_id = cloner._generate_clone_id(test_url)
        logger.info(f"    Sample clone ID: {clone_id}")
        
        return True
    except Exception as e:
        logger.error(f"[✗] RealCloner initialization failed: {e}")
        return False


def test_form_extraction():
    """Test form extraction functionality"""
    logger.info("\n" + "="*60)
    logger.info("TEST 4: Form Extraction")
    logger.info("="*60)
    
    try:
        from bs4 import BeautifulSoup
        from core.real_cloner import RealCloner
        
        cloner = RealCloner()
        
        html = """
        <html>
            <body>
                <form id="login" action="/login" method="POST">
                    <input type="text" name="username">
                    <input type="password" name="password">
                    <input type="checkbox" name="remember">
                    <button type="submit">Login</button>
                </form>
                <form id="contact" action="/contact" method="GET">
                    <textarea name="message"></textarea>
                    <select name="category">
                        <option>Sales</option>
                        <option>Support</option>
                    </select>
                </form>
            </body>
        </html>
        """
        
        soup = BeautifulSoup(html, 'html.parser')
        forms_info = cloner._extract_form_info(soup)
        
        logger.info(f"[✓] Forms extracted: {len(forms_info)}")
        for i, form in enumerate(forms_info, 1):
            logger.info(f"    Form {i}: {form['id']} ({form['method']})")
            logger.info(f"             Fields: {form['fields']}")
        
        return True
    except Exception as e:
        logger.error(f"[✗] Form extraction failed: {e}")
        return False


def test_meta_extraction():
    """Test metadata extraction"""
    logger.info("\n" + "="*60)
    logger.info("TEST 5: Metadata Extraction")
    logger.info("="*60)
    
    try:
        from bs4 import BeautifulSoup
        from core.real_cloner import RealCloner
        
        cloner = RealCloner()
        
        html = """
        <html>
            <head>
                <title>Test Page</title>
                <meta name="description" content="This is a test page">
                <meta name="keywords" content="test, example, page">
            </head>
            <body>
                <h1>Test Page</h1>
            </body>
        </html>
        """
        
        soup = BeautifulSoup(html, 'html.parser')
        
        title = soup.title.string if soup.title else None
        description = cloner._extract_meta_tag(soup, 'description')
        keywords = cloner._extract_meta_tag(soup, 'keywords')
        
        logger.info(f"[✓] Metadata extracted")
        logger.info(f"    Title: {title}")
        logger.info(f"    Description: {description}")
        logger.info(f"    Keywords: {keywords}")
        
        return True
    except Exception as e:
        logger.error(f"[✗] Metadata extraction failed: {e}")
        return False


def test_asset_types():
    """Test supported asset types"""
    logger.info("\n" + "="*60)
    logger.info("TEST 6: Asset Types")
    logger.info("="*60)
    
    try:
        from features.cloning import AssetDownloader
        
        downloader = AssetDownloader()
        
        logger.info(f"[✓] Supported asset types:")
        for asset_type, extensions in downloader.ASSET_TYPES.items():
            logger.info(f"    {asset_type}: {', '.join(extensions)}")
        
        return True
    except Exception as e:
        logger.error(f"[✗] Asset type test failed: {e}")
        return False


def test_clone_id_generation():
    """Test clone ID generation consistency"""
    logger.info("\n" + "="*60)
    logger.info("TEST 7: Clone ID Generation")
    logger.info("="*60)
    
    try:
        cloner = RealCloner()
        
        test_urls = [
            "https://example.com",
            "https://example.com/",
            "https://example.com/page",
            "https://sub.example.com",
            "https://example.org/test",
        ]
        
        logger.info(f"[✓] Clone IDs generated:")
        clone_ids = []
        for url in test_urls:
            clone_id = cloner._generate_clone_id(url)
            clone_ids.append(clone_id)
            logger.info(f"    {url}")
            logger.info(f"    → {clone_id}")
        
        # Check uniqueness
        unique_ids = len(set(clone_ids))
        logger.info(f"    Unique IDs: {unique_ids}/{len(test_urls)}")
        
        return True
    except Exception as e:
        logger.error(f"[✗] Clone ID generation failed: {e}")
        return False


def run_all_tests():
    """Run all tests and report results"""
    logger.info("\n" + "="*60)
    logger.info("ASSET MANAGER TEST SUITE")
    logger.info("="*60)
    
    tests = [
        ("Asset Downloader", test_asset_downloader),
        ("HTML Parsing", test_html_parsing),
        ("RealCloner", test_real_cloner),
        ("Form Extraction", test_form_extraction),
        ("Metadata Extraction", test_meta_extraction),
        ("Asset Types", test_asset_types),
        ("Clone ID Generation", test_clone_id_generation),
    ]
    
    results = []
    for test_name, test_func in tests:
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            logger.error(f"[✗] Test '{test_name}' crashed: {e}")
            results.append((test_name, False))
    
    # Summary
    logger.info("\n" + "="*60)
    logger.info("TEST SUMMARY")
    logger.info("="*60)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "✓ PASS" if result else "✗ FAIL"
        logger.info(f"{status}: {test_name}")
    
    logger.info("="*60)
    logger.info(f"Results: {passed}/{total} tests passed")
    logger.info("="*60)
    
    return passed == total


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
