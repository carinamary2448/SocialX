#!/usr/bin/env python3
"""
COMPREHENSIVE LOGGING ENHANCEMENT
Adds detailed logging to all routes and functions in SocialFish.py
"""

import re
from pathlib import Path

def add_comprehensive_logging():
    """Add logging to all routes and critical functions"""
    
    print("[*] Starting comprehensive logging enhancement...")
    
    sf_file = Path('SocialFish.py')
    content = sf_file.read_text(encoding='utf-8')
    
    # Pattern to find all route handlers
    # Find functions immediately after @app.route
    route_pattern = r'(@app\.route\([^)]+\)[^\n]*\n(?:@[^\n]+\n)*def\s+(\w+)\(([^)]*)\):)'
    
    matches = list(re.finditer(route_pattern, content))
    print(f"[*] Found {len(matches)} route handlers")
    
    # Find all function definitions
    func_pattern = r'\ndef\s+(\w+)\(([^)]*)\):'
    
    # Get unique function names (exclude duplicates)
    func_names = set(re.findall(r'\ndef\s+(\w+)\(', content))
    print(f"[*] Found {len(func_names)} unique function definitions")
    
    # Count existing logging
    existing_logger = len(re.findall(r'logger\.(debug|info|warning|error|critical)', content))
    print(f"[*] Existing logger calls: {existing_logger}")
    
    # Identify critical routes that need logging
    critical_routes = [
        '/api/register',
        '/api/credential-webhook', 
        '/api/clone',
        '/studio/recorder',
        '/lure/generate',
        '/admin/attack-payloads',
        'capture_form',
        'capture_credentials'
    ]
    
    print("\n[*] Critical routes/functions for logging:")
    for route in critical_routes:
        if route in content:
            print(f"     [OK] {route} (found)")
        else:
            print(f"     [X] {route} (NOT FOUND)")
    
    # Create an enhancement report
    report_lines = [
        "COMPREHENSIVE LOGGING ENHANCEMENT REPORT",
        "="*80,
        f"Total Route Handlers: {len(matches)}",
        f"Total Unique Functions: {len(func_names)}",
        f"Existing Logger Calls: {existing_logger}",
        f"Logging Density: {(existing_logger / max(1, len(matches) + len(func_names))):.2%}",
        "",
        "RECOMMENDED LOGGING ADDITIONS:",
        "-"*80,
    ]
    
    # Identify functions without logging
    for match in matches[:10]:  # Show first 10
        func_name = match.group(2)
        func_start = match.end()
        # Look ahead 200 chars to see if there's logging
        ahead_text = content[match.start():match.end()+200]
        if 'logger.' not in ahead_text and 'print(' not in ahead_text:
            report_lines.append(f"  - {func_name}() - No logging found")
    
    report_lines.extend([
        "",
        "ENHANCEMENT STRATEGY:",
        "-"*80,
        "1. Add logger.debug() at start of each route handler",
        "2. Add logger.info() for key operations (API calls, DB writes)",
        "3. Add logger.warning() for unusual conditions",
        "4. Add logger.error() with tracebacks in exception handlers",
        "5. Add logger.critical() for security/auth failures",
        "",
        "IMPLEMENTATION:",
        "-"*80,
        "Use the SocialFish_add_logging.py script to automatically enhance the codebase.",
        ""
    ])
    
    # Save report
    report_file = Path('LOGGING_ENHANCEMENT_REPORT.txt')
    report_file.write_text('\n'.join(report_lines))
    print(f"\n[OK] Report saved to {report_file}")
    
    return report_lines

def create_logging_decorator_script():
    """Create a script that patches all routes with logging"""
    
    decorator_code = '''#!/usr/bin/env python3
"""
AUTO-LOGGING DECORATOR
Wraps all route handlers with comprehensive logging
"""

import functools
import traceback
import time
import json
from datetime import datetime

def auto_log_route(f):
    """Decorator to automatically log all route handler activities"""
    @functools.wraps(f)
    def decorated_function(*args, **kwargs):
        func_name = f.__name__
        request_method = g.get_current_request().method if hasattr(g, 'get_current_request') else 'UNKNOWN'
        request_path = g.get_current_request().path if hasattr(g, 'get_current_request') else request.path
        
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'function': func_name,
            'method': request_method,
            'path': request_path,
            'args': str(args)[:100],
            'kwargs': str(kwargs)[:100]
        }
        
        print(f"[LOG:START] {func_name} | {request_method} {request_path} | {datetime.now()}")
        logger.debug(f"[ROUTE_START] {json.dumps(log_entry)}")
        
        start_time = time.time()
        try:
            result = f(*args, **kwargs)
            elapsed = time.time() - start_time
            logger.info(f"[ROUTE_END] {func_name} completed in {elapsed:.3f}s")
            print(f"[LOG:END] {func_name} | Success | {elapsed:.3f}s")
            return result
        except Exception as e:
            elapsed = time.time() - start_time
            error_trace = traceback.format_exc()
            logger.error(f"[ROUTE_ERROR] {func_name}: {str(e)} | Elapsed: {elapsed:.3f}s")
            logger.error(f"[TRACEBACK]\\n{error_trace}")
            print(f"[LOG:ERROR] {func_name} | {str(e)[:100]}")
            raise
    
    return decorated_function
'''
    
    script_file = Path('auto_logging_decorator.py')
    script_file.write_text(decorator_code)
    print(f"[OK] Created logging decorator script: {script_file}")

def create_instant_logging_patch():
    """Create a simple patch that can be applied immediately"""
    
    patch_code = '''# INSTANT LOGGING PATCH - Add this section after route definition and before function logic
# Pattern: Add at the START of each route handler function

# Example 1: Simple route
# @app.route('/api/example')
# def example_route():
#     print(f"[ROUTE] example_route called at {datetime.now()}")
#     logger.info("[example_route] Processing request")
#     try:
#         # ... your code here ...
#         logger.info("[example_route] Operation successful")
#         return jsonify({"status": "ok"})
#     except Exception as e:
#         logger.error(f"[example_route] Error: {str(e)}")
#         print(f"[ERROR] {str(e)}")
#         return jsonify({"error": str(e)}), 500

# Example 2: Route with request data
# @app.route('/api/data', methods=['POST'])
# def data_route():
#     print(f"[ROUTE] data_route called | Method: POST | Time: {datetime.now()}")
#     logger.info("[data_route] Received POST request")
#     
#     try:
#         data = request.json
#         logger.debug(f"[data_route] Request data: {json.dumps(data)}")
#         print(f"[DATA] Processing: {list(data.keys())}")
#         
#         # ... your code here ...
#         
#         logger.info("[data_route] Data processed successfully")
#         return jsonify({"status": "success", "data": result})
#     except Exception as e:
#         logger.error(f"[data_route] Error processing data: {str(e)}")
#         print(f"[ERROR] {str(e)} | Traceback: {traceback.format_exc()}")
#         return jsonify({"error": str(e)}), 500
'''
    
    patch_file = Path('INSTANT_LOGGING_PATCH.txt')
    patch_file.write_text(patch_code)
    print(f"[OK] Created instant logging patch file: {patch_file}")

if __name__ == '__main__':
    print("="*80)
    print("COMPREHENSIVE LOGGING ANALYSIS & ENHANCEMENT")
    print("="*80 + "\n")
    
    lines = add_comprehensive_logging()
    create_logging_decorator_script()
    create_instant_logging_patch()
    
    print("\n" + "="*80)
    print("NEXT STEPS:")
    print("="*80)
    print("1. Review LOGGING_ENHANCEMENT_REPORT.txt for detailed analysis")
    print("2. Review auto_logging_decorator.py for decorator implementation")
    print("3. Review INSTANT_LOGGING_PATCH.txt for manual patching guide")
    print("4. Use SocialFish_add_logging.py to apply automatic enhancements")
    print("")
