#!/usr/bin/env python3
"""
Database Schema Checker & Fixer
Identifies and fixes missing columns in database tables
"""

import sqlite3
import sys

def check_and_fix_schema():
    """Check database schema and add missing columns"""
    
    try:
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        
        print("[*] Checking templates table schema...\n")
        
        # Get current columns
        cursor.execute("PRAGMA table_info(templates)")
        columns = cursor.fetchall()
        
        print("Current columns in templates table:")
        col_names = []
        for col in columns:
            col_id, col_name, col_type, notnull, default, pk = col
            col_names.append(col_name)
            print(f"  - {col_name} ({col_type})")
        
        print(f"\nTotal columns: {len(col_names)}\n")
        
        # Check for required columns
        required_columns = {
            'id': 'INTEGER PRIMARY KEY',
            'name': 'TEXT',
            'base_url': 'TEXT',
            'url': 'TEXT',
            'description': 'TEXT',
            'tags': 'TEXT',
            'status': 'TEXT',
            'created_by': 'TEXT',
            'created_at': 'DATETIME',
            'headless': 'INTEGER',
            'stealth': 'INTEGER',
        }
        
        print("Checking for required columns...")
        missing_columns = {}
        for col_name, col_type in required_columns.items():
            if col_name not in col_names:
                missing_columns[col_name] = col_type
                print(f"  MISSING: {col_name} ({col_type})")
            else:
                print(f"  OK: {col_name}")
        
        if missing_columns:
            print(f"\n[!] Found {len(missing_columns)} missing columns")
            print("\nAdding missing columns...\n")
            
            for col_name, col_type in missing_columns.items():
                try:
                    sql = f"ALTER TABLE templates ADD COLUMN {col_name} {col_type}"
                    cursor.execute(sql)
                    print(f"  [+] Added: {col_name}")
                except Exception as e:
                    print(f"  [!] Error adding {col_name}: {str(e)}")
            
            conn.commit()
            print("\n[SUCCESS] All missing columns added!")
        else:
            print("\n[OK] All required columns present!")
        
        # Check other important tables
        print("\n" + "="*60)
        print("Checking creds table schema...\n")
        
        cursor.execute("PRAGMA table_info(creds)")
        creds_columns = cursor.fetchall()
        
        creds_col_names = [col[1] for col in creds_columns]
        print(f"Creds table columns: {len(creds_col_names)}")
        
        required_creds_cols = ['email', 'password', 'username', 'cookies', 'csrf_tokens']
        for col in required_creds_cols:
            if col in creds_col_names:
                print(f"  OK: {col}")
            else:
                print(f"  MISSING: {col}")
        
        # Check sessions table
        print("\n" + "="*60)
        print("Checking sessions table schema...\n")
        
        cursor.execute("PRAGMA table_info(sessions)")
        sessions_columns = cursor.fetchall()
        
        sessions_col_names = [col[1] for col in sessions_columns]
        print(f"Sessions table columns: {len(sessions_col_names)}")
        for col_name in sessions_col_names[:5]:
            print(f"  - {col_name}")
        
        conn.close()
        
        print("\n" + "="*60)
        print("[SUCCESS] Database schema check complete!")
        print("="*60)
        
    except Exception as e:
        print(f"[ERROR] {str(e)}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == '__main__':
    check_and_fix_schema()
