#!/usr/bin/env python3
"""
Realistic authentication flow testers for OAuth 2.0, SSO, and 2FA
"""

import hmac
import hashlib
import json
import time
import base64
import secrets
import re
from typing import Dict, Optional, Tuple
from urllib.parse import urljoin, urlencode, parse_qs, urlparse
import requests
from datetime import datetime, timedelta

class OAuth2Tester:
    """Test OAuth 2.0 authentication flows"""
    
    def __init__(self, client_id: str, client_secret: str, redirect_uri: str):
        self.client_id = client_id
        self.client_secret = client_secret
        self.redirect_uri = redirect_uri
        self.auth_code = None
        self.access_token = None
        self.state = secrets.token_urlsafe(32)
    
    def generate_auth_url(self, auth_endpoint: str, scopes: list = None) -> str:
        """Generate OAuth authorization URL"""
        if scopes is None:
            scopes = ['openid', 'profile', 'email']
        
        params = {
            'client_id': self.client_id,
            'redirect_uri': self.redirect_uri,
            'response_type': 'code',
            'scope': ' '.join(scopes),
            'state': self.state,
            'prompt': 'login'
        }
        
        return f"{auth_endpoint}?{urlencode(params)}"
    
    def exchange_code_for_token(self, token_endpoint: str, auth_code: str, session: requests.Session = None) -> Dict:
        """Exchange authorization code for access token"""
        if session is None:
            session = requests.Session()
        
        data = {
            'grant_type': 'authorization_code',
            'code': auth_code,
            'client_id': self.client_id,
            'client_secret': self.client_secret,
            'redirect_uri': self.redirect_uri
        }
        
        try:
            response = session.post(token_endpoint, data=data, timeout=10)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {'error': str(e)}
    
    def get_user_info(self, userinfo_endpoint: str, access_token: str, session: requests.Session = None) -> Dict:
        """Fetch user information with access token"""
        if session is None:
            session = requests.Session()
        
        headers = {'Authorization': f'Bearer {access_token}'}
        
        try:
            response = session.get(userinfo_endpoint, headers=headers, timeout=10)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            return {'error': str(e)}

class SSO_Tester:
    """Test SSO authentication flows (SAML 2.0)"""
    
    def __init__(self, idp_url: str, sp_url: str):
        self.idp_url = idp_url  # Identity Provider
        self.sp_url = sp_url    # Service Provider
        self.assertion_id = f"_{secrets.token_hex(16)}"
        self.issue_instant = datetime.utcnow().isoformat() + 'Z'
    
    def generate_saml_request(self) -> Tuple[str, str]:
        """Generate SAML 2.0 authentication request"""
        request_id = f"_{secrets.token_hex(16)}"
        
        saml_request = f"""<?xml version="1.0" encoding="UTF-8"?>
<samlp:AuthnRequest xmlns:samlp="urn:oasis:names:tc:SAML:2.0:protocol" 
    xmlns:saml="urn:oasis:names:tc:SAML:2.0:assertion"
    ID="{request_id}" Version="2.0" IssueInstant="{self.issue_instant}"
    Destination="{self.idp_url}"
    AssertionConsumerServiceURL="{self.sp_url}/acs"
    ProtocolBinding="urn:oasis:names:tc:SAML:2.0:bindings:HTTP-POST">
    <saml:Issuer>{self.sp_url}</saml:Issuer>
    <samlp:NameIDPolicy Format="urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified"
        AllowCreate="true"/>
    <samlp:RequestedAuthnContext Comparison="exact">
        <saml:AuthnContextClassRef>urn:oasis:names:tc:SAML:2.0:ac:classes:Password</saml:AuthnContextClassRef>
    </samlp:RequestedAuthnContext>
</samlp:AuthnRequest>"""
        
        # Deflate and base64 encode
        import zlib
        compressed = zlib.compress(saml_request.encode('utf-8'))
        encoded = base64.b64encode(compressed[2:-1]).decode('utf-8')
        
        return request_id, encoded
    
    def parse_saml_response(self, saml_response_b64: str) -> Dict:
        """Parse SAML 2.0 response"""
        import zlib
        
        try:
            decoded = base64.b64decode(saml_response_b64)
            decompressed = zlib.decompress(decoded, -zlib.MAX_WBITS)
            saml_response_xml = decompressed.decode('utf-8')
            
            # Extract key information
            user_match = re.search(r'<saml:NameID[^>]*>(.+?)</saml:NameID>', saml_response_xml)
            email_match = re.search(r'<saml:Attribute Name="email"[^>]*><saml:AttributeValue>(.+?)</saml:AttributeValue>', saml_response_xml)
            
            return {
                'success': True,
                'user': user_match.group(1) if user_match else None,
                'email': email_match.group(1) if email_match else None,
                'response_xml': saml_response_xml
            }
        except Exception as e:
            return {'success': False, 'error': str(e)}

class MFA_Tester:
    """Test Multi-Factor Authentication flows"""
    
    @staticmethod
    def generate_totp(secret: str, period: int = 30) -> str:
        """Generate Time-based OTP (RFC 4226)"""
        import time
        import hmac
        import hashlib
        
        # Decode secret (base32)
        try:
            import base64
            secret_bytes = base64.b32decode(secret)
        except:
            secret_bytes = secret.encode()
        
        # Current time counter
        counter = int(time.time()) // period
        
        # Generate HMAC
        counter_bytes = counter.to_bytes(8, byteorder='big')
        hmac_result = hmac.new(secret_bytes, counter_bytes, hashlib.sha1).digest()
        
        # Dynamic truncation
        offset = hmac_result[-1] & 0x0f
        code = (int.from_bytes(hmac_result[offset:offset+4], 'big') & 0x7fffffff) % 1000000
        
        return str(code).zfill(6)
    
    @staticmethod
    def generate_hotp(secret: str, counter: int) -> str:
        """Generate HMAC-based OTP (RFC 4226)"""
        import hmac
        import hashlib
        
        try:
            import base64
            secret_bytes = base64.b32decode(secret)
        except:
            secret_bytes = secret.encode()
        
        counter_bytes = counter.to_bytes(8, byteorder='big')
        hmac_result = hmac.new(secret_bytes, counter_bytes, hashlib.sha1).digest()
        
        offset = hmac_result[-1] & 0x0f
        code = (int.from_bytes(hmac_result[offset:offset+4], 'big') & 0x7fffffff) % 1000000
        
        return str(code).zfill(6)
    
    @staticmethod
    def detect_sms_2fa_requirements(html: str) -> Dict:
        """Detect SMS 2FA requirements from HTML"""
        indicators = {
            'requires_sms': False,
            'phone_field': False,
            'sms_input': False,
            'verification_code_field': False,
            'patterns_found': []
        }
        
        patterns = {
            'phone_field': [r'type="tel"', r'name.*phone', r'placeholder.*phone'],
            'sms_input': [r'sms.*code|code.*sms', r'verification.*code'],
            'verification': [r'verify.*number|confirm.*phone']
        }
        
        for key, pattern_list in patterns.items():
            for pattern in pattern_list:
                if re.search(pattern, html, re.IGNORECASE):
                    indicators[key] = True
                    indicators['patterns_found'].append(pattern)
        
        indicators['requires_sms'] = indicators['phone_field'] or indicators['sms_input']
        
        return indicators
    
    @staticmethod
    def detect_email_2fa_requirements(html: str) -> Dict:
        """Detect Email 2FA requirements from HTML"""
        indicators = {
            'requires_email': False,
            'confirmation_needed': False,
            'patterns_found': []
        }
        
        patterns = [
            r'confirm.*email',
            r'verify.*email',
            r'confirmation.*code',
            r'email.*verification',
            r'check.*email|email.*check'
        ]
        
        for pattern in patterns:
            if re.search(pattern, html, re.IGNORECASE):
                indicators['requires_email'] = True
                indicators['patterns_found'].append(pattern)
        
        indicators['confirmation_needed'] = bool(indicators['patterns_found'])
        
        return indicators
    
    @staticmethod
    def detect_webauthn_requirements(html: str) -> Dict:
        """Detect WebAuthn/FIDO2 requirements from HTML"""
        indicators = {
            'webauthn_support': False,
            'security_keys': False,
            'biometric': False,
            'patterns_found': []
        }
        
        patterns = {
            'webauthn': [r'webauthn|fido2|credentials\.create|credentials\.get'],
            'security_key': [r'security.*key|yubikey|hardkey'],
            'biometric': [r'fingerprint|face.*recognition|biometric']
        }
        
        for key, pattern_list in patterns.items():
            for pattern in pattern_list:
                if re.search(pattern, html, re.IGNORECASE):
                    indicators[key] = True
                    indicators['patterns_found'].append(pattern)
        
        indicators['webauthn_support'] = indicators['webauthn']
        
        return indicators

class AdvancedAuthFlowTester:
    """Combined tester for realistic auth flow scenarios"""
    
    def __init__(self, target_url: str):
        self.target_url = target_url
        self.session = requests.Session()
        self.flow_log = []
    
    def test_auth_flow(self, auth_type: str) -> Dict:
        """Test complete authentication flow"""
        results = {
            'auth_type': auth_type,
            'timestamp': datetime.now().isoformat(),
            'flow_steps': [],
            'success': False,
            'errors': []
        }
        
        try:
            if auth_type == 'oauth2':
                results = self._test_oauth2_flow(results)
            elif auth_type == 'saml':
                results = self._test_saml_flow(results)
            elif auth_type == '2fa':
                results = self._test_2fa_flow(results)
            elif auth_type == 'hybrid':
                results = self._test_hybrid_flow(results)
        except Exception as e:
            results['errors'].append(str(e))
        
        return results
    
    def _test_oauth2_flow(self, results: Dict) -> Dict:
        """Test OAuth 2.0 flow"""
        results['flow_steps'].append({'step': 1, 'action': 'Fetch login page'})
        
        response = self.session.get(self.target_url)
        results['success'] = response.status_code == 200
        
        # Look for OAuth buttons/links
        oauth_providers = re.findall(r'btn-(?:google|github|microsoft|facebook|apple)', response.text)
        results['oauth_providers'] = oauth_providers
        
        return results
    
    def _test_saml_flow(self, results: Dict) -> Dict:
        """Test SAML flow"""
        results['flow_steps'].append({'step': 1, 'action': 'Generate SAML request'})
        
        sso_tester = SSO_Tester(self.target_url, self.target_url)
        request_id, saml_request = sso_tester.generate_saml_request()
        results['flow_steps'].append({'step': 2, 'action': 'SAML request generated', 'request_id': request_id})
        
        return results
    
    def _test_2fa_flow(self, results: Dict) -> Dict:
        """Test 2FA flow detection"""
        results['flow_steps'].append({'step': 1, 'action': 'Fetch login page'})
        
        response = self.session.get(self.target_url)
        html = response.text
        
        # Check for different 2FA methods
        sms_check = MFA_Tester.detect_sms_2fa_requirements(html)
        email_check = MFA_Tester.detect_email_2fa_requirements(html)
        webauthn_check = MFA_Tester.detect_webauthn_requirements(html)
        
        results['flow_steps'].append({
            'step': 2,
            'action': '2FA detection',
            'sms': sms_check,
            'email': email_check,
            'webauthn': webauthn_check
        })
        
        results['success'] = True
        return results
    
    def _test_hybrid_flow(self, results: Dict) -> Dict:
        """Test hybrid auth flow (basic + 2FA)"""
        results['flow_steps'].append({'step': 1, 'action': 'Hybrid flow - basic auth + 2FA'})
        
        # Get login page
        response = self.session.get(self.target_url)
        
        if response.status_code == 200:
            # Test for 2FA after initial auth
            mfa_required = MFA_Tester.detect_sms_2fa_requirements(response.text) or \
                          MFA_Tester.detect_email_2fa_requirements(response.text)
            
            results['flow_steps'].append({
                'step': 2,
                'action': 'Check for 2FA requirement',
                '2fa_required': any(mfa_required.values())
            })
            
            results['success'] = True
        
        return results
