# COMPRESS APP --------------------------------------------------------------------------------------------------
COMPRESS_MIMETYPES = ['text/html', 'text/css', 'text/xml', 'application/json', 'application/javascript']
COMPRESS_LEVEL = 6
COMPRESS_MIN_SIZE = 500
# ---------------------------------------------------------------------------------------------------------------
# LOCAL CONFIGS--------------------------------------------------------------------------------------------------
import os
import secrets

DATABASE = os.environ.get('SOCIALFISH_DATABASE', "./database.db")

# Default URLs - configurable via environment variables
# IMPORTANT: These should be configured by the user - no GitHub defaults
DEFAULT_CLONE_URL = os.environ.get('SOCIALFISH_DEFAULT_CLONE_URL', 'http://localhost:5000')
DEFAULT_REDIRECT_URL = os.environ.get('SOCIALFISH_DEFAULT_REDIRECT_URL', 'http://localhost:5000')
DEFAULT_STATUS = os.environ.get('SOCIALFISH_DEFAULT_STATUS', 'custom')
DEFAULT_BEEF = os.environ.get('SOCIALFISH_DEFAULT_BEEF', 'no')

# Legacy support for existing imports
url = DEFAULT_CLONE_URL
red = DEFAULT_REDIRECT_URL
sta = DEFAULT_STATUS

# SECURITY: Set a strong secret key in production using environment variable
SECRET_KEY = os.environ.get('SECRET_KEY')
APP_SECRET_KEY = os.environ.get('SOCIALFISH_SECRET_KEY')

# If no secret key is set, generate and save it persistently
if not APP_SECRET_KEY:
    secret_key_file = os.path.join(os.path.dirname(__file__), '..', '.secret_key')
    try:
        if os.path.exists(secret_key_file):
            with open(secret_key_file, 'r') as f:
                APP_SECRET_KEY = f.read().strip()
        else:
            APP_SECRET_KEY = secrets.token_urlsafe(32)
            os.makedirs(os.path.dirname(secret_key_file), exist_ok=True)
            with open(secret_key_file, 'w') as f:
                f.write(APP_SECRET_KEY)
            os.chmod(secret_key_file, 0o600)  # Restrict permissions
    except Exception as e:
        # Fallback if file operations fail
        APP_SECRET_KEY = secrets.token_urlsafe(32)

# HTTPS Configuration
FORCE_HTTPS = os.environ.get('SOCIALFISH_FORCE_HTTPS', 'False').lower() == 'true'
ALLOWED_HOSTS = os.environ.get('SOCIALFISH_ALLOWED_HOSTS', 'localhost,127.0.0.1').split(',')

# Pagination settings for large lists
ITEMS_PER_PAGE = int(os.environ.get('SOCIALFISH_ITEMS_PER_PAGE', '25'))
ENABLE_LAZY_LOADING = os.environ.get('SOCIALFISH_ENABLE_LAZY_LOADING', 'True').lower() == 'true'
# ---------------------------------------------------------------------------------------------------------------