import secrets

def genToken():
    return ''.join(secrets.token_urlsafe(16))
