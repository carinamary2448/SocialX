"""
Live Login Panel - Cookie Analysis Module
Provides full cookie jar analysis with security auditing
"""

import json
import hashlib
import re
from datetime import datetime
from urllib.parse import urlparse, parse_qs

class CookieAnalyzer:
    """Analyze captured cookies for security and credential value"""
    
    def __init__(self):
        self.sensitive_keywords = [
            'session', 'auth', 'token', 'jwt', 'bearer', 'api_key',
            'password', 'secret', 'access', 'refresh', 'csrf', '_ga',
            'fbp', 'wfp', '_fbp', '_ym_uid', '__Secure', '__Host'
        ]
        
    def parse_cookies(self, cookie_header_or_list):
        """Parse Set-Cookie headers or cookie objects"""
        cookies = []
        
        if isinstance(cookie_header_or_list, str):
            # Parse Set-Cookie header format
            cookies = self._parse_set_cookie_header(cookie_header_or_list)
        elif isinstance(cookie_header_or_list, list):
            # Check if it's a list of strings or already parsed dicts
            if cookie_header_or_list and isinstance(cookie_header_or_list[0], str):
                # List of Set-Cookie header strings
                for header in cookie_header_or_list:
                    parsed = self._parse_set_cookie_header(header)
                    cookies.extend(parsed)
            else:
                # Already parsed as list of dicts
                cookies = cookie_header_or_list
        
        return cookies
    
    def _parse_set_cookie_header(self, header):
        """Parse Set-Cookie header value"""
        cookies = []
        parts = header.split(';')
        
        if not parts:
            return cookies
        
        # First part is name=value
        name_value = parts[0].strip()
        if '=' not in name_value:
            return cookies
        
        name, value = name_value.split('=', 1)
        cookie = {
            'name': name.strip(),
            'value': value.strip(),
            'domain': '',
            'path': '/',
            'expires': None,
            'secure': False,
            'httponly': False,
            'samesite': 'None',
            'max_age': None
        }
        
        # Parse attributes
        for part in parts[1:]:
            attr = part.strip()
            if '=' in attr:
                k, v = attr.split('=', 1)
                k = k.strip().lower()
                v = v.strip()
                
                if k == 'domain':
                    cookie['domain'] = v
                elif k == 'path':
                    cookie['path'] = v
                elif k == 'expires':
                    cookie['expires'] = v
                elif k == 'max-age':
                    cookie['max_age'] = int(v)
                elif k == 'samesite':
                    cookie['samesite'] = v
            else:
                attr_lower = attr.lower()
                if attr_lower == 'secure':
                    cookie['secure'] = True
                elif attr_lower == 'httponly':
                    cookie['httponly'] = True
        
        cookies.append(cookie)
        return cookies
    
    def analyze_security(self, cookies):
        """Analyze cookies for security issues"""
        if not cookies:
            return {'status': 'ok', 'findings': [], 'risk_score': 0}
        
        findings = []
        risk_score = 0
        
        for cookie in cookies:
            # Check Secure flag
            if not cookie.get('secure', False):
                findings.append({
                    'severity': 'HIGH',
                    'cookie': cookie['name'],
                    'issue': 'Cookie not marked Secure',
                    'description': 'Can be intercepted via Man-in-the-Middle attacks',
                    'remediation': 'Add Secure flag to Set-Cookie header'
                })
                risk_score += 30
            
            # Check HttpOnly flag
            if not cookie.get('httponly', False):
                findings.append({
                    'severity': 'HIGH',
                    'cookie': cookie['name'],
                    'issue': 'Cookie not marked HttpOnly',
                    'description': 'Vulnerable to XSS attacks and JavaScript access',
                    'remediation': 'Add HttpOnly flag to Set-Cookie header'
                })
                risk_score += 30
            
            # Check SameSite attribute
            samesite = cookie.get('samesite', 'None')
            if samesite == 'None' and not cookie.get('secure'):
                findings.append({
                    'severity': 'MEDIUM',
                    'cookie': cookie['name'],
                    'issue': 'Weak SameSite attribute',
                    'description': 'CSRF attack risk - requires Secure flag if SameSite=None',
                    'remediation': 'Set SameSite=Strict or SameSite=Lax'
                })
                risk_score += 15
            
            # Check for sensitive data patterns
            if self._contains_sensitive_data(cookie['name']):
                findings.append({
                    'severity': 'MEDIUM',
                    'cookie': cookie['name'],
                    'issue': 'Sensitive cookie name detected',
                    'description': f"Cookie name suggests sensitive data: {cookie['name']}",
                    'remediation': 'Ensure proper access controls and encryption'
                })
                risk_score += 20
            
            # Check cookie value size
            if len(cookie.get('value', '')) > 4000:
                findings.append({
                    'severity': 'LOW',
                    'cookie': cookie['name'],
                    'issue': 'Unusually large cookie',
                    'description': f"Cookie size: {len(cookie['value'])} bytes",
                    'remediation': 'Consider using session storage instead'
                })
                risk_score += 5
            
            # Check for base64 encoded data (common for JWT/session tokens)
            if self._is_base64(cookie.get('value', '')):
                findings.append({
                    'severity': 'INFO',
                    'cookie': cookie['name'],
                    'issue': 'Base64-encoded data detected',
                    'description': 'Likely JWT, session token, or encrypted data',
                    'data': cookie.get('value', '')[:100]
                })
        
        # Normalize risk score
        risk_score = min(100, risk_score)
        
        return {
            'status': 'ok',
            'findings': findings,
            'risk_score': risk_score,
            'total_cookies': len(cookies),
            'secure_cookies': len([c for c in cookies if c.get('secure', False)]),
            'httponly_cookies': len([c for c in cookies if c.get('httponly', False)])
        }
    
    def _contains_sensitive_data(self, name):
        """Check if cookie name suggests sensitive data"""
        name_lower = name.lower()
        for keyword in self.sensitive_keywords:
            if keyword in name_lower:
                return True
        return False
    
    def _is_base64(self, s):
        """Check if string looks like base64-encoded data"""
        try:
            import base64
            if len(s) < 4:
                return False
            return bool(re.match(r'^[A-Za-z0-9+/]+={0,2}$', s))
        except:
            return False
    
    def extract_auth_tokens(self, cookies):
        """Extract likely authentication tokens"""
        tokens = []
        
        for cookie in cookies:
            name_lower = cookie['name'].lower()
            
            # JWT detection (jwt, authorization, token, bearer, access_token)
            if any(x in name_lower for x in ['jwt', 'token', 'bearer', 'access']):
                tokens.append({
                    'type': 'JWT/TOKEN',
                    'name': cookie['name'],
                    'value': cookie['value'],
                    'expires': cookie.get('expires'),
                    'secure': cookie.get('secure', False),
                    'httponly': cookie.get('httponly', False)
                })
            
            # Session ID detection
            elif any(x in name_lower for x in ['sessionid', 'session_id', 'sessionkey', 'phpsessid', 'jsessionid']):
                tokens.append({
                    'type': 'SESSION_ID',
                    'name': cookie['name'],
                    'value': cookie['value'][:20] + '...' if len(cookie['value']) > 20 else cookie['value'],
                    'expires': cookie.get('expires'),
                    'secure': cookie.get('secure', False)
                })
            
            # API Key detection
            elif any(x in name_lower for x in ['api_key', 'apikey', 'key', 'secret']):
                tokens.append({
                    'type': 'API_KEY',
                    'name': cookie['name'],
                    'value': '***' + cookie['value'][-4:] if len(cookie['value']) > 4 else '***',
                    'sensitive': True
                })
        
        return tokens
    
    def to_dict(self, cookies):
        """Convert cookies to dictionary format for JSON serialization"""
        return [
            {
                'name': c.get('name', 'unknown'),
                'value': c.get('value', ''),
                'domain': c.get('domain', ''),
                'path': c.get('path', '/'),
                'expires': c.get('expires'),
                'secure': c.get('secure', False),
                'httponly': c.get('httponly', False),
                'samesite': c.get('samesite', 'None'),
                'max_age': c.get('max_age')
            }
            for c in cookies
        ]
    
    def to_netscape_format(self, cookies):
        """Export cookies in Netscape cookie jar format (compatible with curl, wget)"""
        lines = ['# Netscape HTTP Cookie File', '# Generated by SocialFish', '']
        
        for cookie in cookies:
            domain = cookie.get('domain', '')
            domain_specified = '.TRUE' if domain.startswith('.') else 'FALSE'
            flag = 'TRUE' if cookie.get('secure') else 'FALSE'
            
            # Convert expires to Unix timestamp
            try:
                from email.utils import parsedate_to_datetime
                expires = int(parsedate_to_datetime(cookie.get('expires')).timestamp()) if cookie.get('expires') else '0'
            except:
                expires = '0'
            
            name = cookie.get('name', '')
            value = cookie.get('value', '')
            path = cookie.get('path', '/')
            
            line = f"{domain}\t{domain_specified}\t{path}\t{flag}\t{expires}\t{name}\t{value}"
            lines.append(line)
        
        return '\n'.join(lines)
    
    def detect_tracking_cookies(self, cookies):
        """Identify third-party tracking cookies"""
        tracking_patterns = {
            '_ga': 'Google Analytics',
            '_fbp': 'Facebook Pixel',
            '_ym_uid': 'Yandex Metrica',
            '__Secure-3PSID': 'Google',
            'IDE': 'Google DoubleClick',
            'ANID': 'Google DoubleClick',
            'test_cookie': 'Google DoubleClick',
            '__utma': 'Google Analytics (old)',
            'PHPSESSID': 'PHP Session',
            'JSESSIONID': 'Java Session'
        }
        
        tracking = []
        
        for cookie in cookies:
            for pattern, provider in tracking_patterns.items():
                if pattern in cookie.get('name', ''):
                    tracking.append({
                        'cookie': cookie['name'],
                        'provider': provider,
                        'type': 'analytics' if 'analytics' in provider.lower() else 'tracking',
                        'domain': cookie.get('domain', 'unknown')
                    })
                    break
        
        return tracking
