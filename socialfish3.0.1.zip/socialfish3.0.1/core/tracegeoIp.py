import requests
import re

# trace GEO IP -------------------------------------------------------------------------------------------------

def tracegeoIp(ip):
    """Trace geolocation of IP address with validation"""
    # Validate IP format
    ip_pattern = r'^(\d{1,3}\.){3}\d{1,3}$|^127\.0\.0\.1$|^::1$|^[a-f0-9:]+$'
    
    if not re.match(ip_pattern, ip):
        return {'error': 'Invalid IP format', 'country_code': 'UN', 'country_name': 'Unknown'}
    
    try:
        if '127.0.0.1' == ip or '::1' == ip:
            url = 'https://geoip-db.com/json/'
        else:
            url = 'https://geoip-db.com/jsonp/' + ip
        
        # Use timeout and verify SSL
        result = requests.get(url, timeout=10, verify=True).json()
        
        # Ensure country_code exists with default fallback
        if 'country_code' not in result:
            result['country_code'] = 'UN'
        if 'country_name' not in result:
            result['country_name'] = 'Unknown'
            
        return result
    except requests.exceptions.Timeout:
        return {'error': 'Request timeout. Check your network connection.', 'country_code': 'UN', 'country_name': 'Unknown'}
    except requests.exceptions.ConnectionError:
        return {'error': 'Connection failed. Verify your network connection.', 'country_code': 'UN', 'country_name': 'Unknown'}
    except (ValueError, requests.exceptions.JSONDecodeError):
        return {'error': 'Invalid response format from GeoIP service', 'country_code': 'UN', 'country_name': 'Unknown'}
    except Exception as e:
        print(f'[-] GeoIP trace error: {str(e)}')
        return {'error': 'Trace failed. Verify your network connection.', 'country_code': 'UN', 'country_name': 'Unknown'}
# --------------------------------------------------------------------------------------------------------------