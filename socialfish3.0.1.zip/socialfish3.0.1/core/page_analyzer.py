#!/usr/bin/env python3
"""
AI-powered page structure analyzer for intelligent cloning and form detection
Uses ML patterns to identify login forms, OAuth endpoints, 2FA elements, etc.
"""

import re
import json
from typing import Dict, List, Optional, Tuple
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup
import hashlib

class PageAnalyzer:
    """Analyze website structure using AI-like pattern recognition"""
    
    # Patterns for detecting common authentication elements
    OAUTH_PATTERNS = {
        'google': [r'google.*oauth|accounts\.google', r'client_id.*google', r'oauth2.*google'],
        'github': [r'github.*oauth|github\.com/login/oauth', r'client_id.*github'],
        'microsoft': [r'microsoft.*oauth|login\.microsoftonline', r'client_id.*microsoft'],
        'facebook': [r'facebook.*oauth|facebook\.com/v\d+/dialog'],
        'linkedin': [r'linkedin.*oauth|authorization.*linkedin'],
        'apple': [r'apple.*oauth|appleid\.apple\.com']
    }
    
    SSO_PATTERNS = {
        'saml': [r'saml|assertionconsumerservice', r'samlresponse', r'samlrequest'],
        'openid': [r'openid.*connect|oidc', r'\.well-known/openid-configuration'],
        'ldap': [r'ldap', r'active.*directory|ad\.'],
        'okta': [r'okta\.com', r'okta-hosted.*login'],
        'azure': [r'aad\.azure\.com|login\.microsoftonline\.com/.*oauth', r'tenant']
    }
    
    MFA_PATTERNS = {
        '2fa': [r'two.?factor|2fa', r'otp.*code|secret.*key'],
        'sms': [r'sms|text.*message|phone.*number', r'verify.*phone|send.*sms'],
        'email': [r'verify.*email|confirmation.*code', r'email.*verification'],
        'totp': [r'authenticator|google.*authenticator|totp'],
        'webauthn': [r'fido|webauthn|security.*key']
    }
    
    def __init__(self, page_html: str, base_url: str):
        """Initialize analyzer with page HTML and base URL"""
        self.html = page_html
        self.base_url = base_url
        self.soup = BeautifulSoup(page_html, 'html.parser')
        self.domain = urlparse(base_url).netloc
        self.analysis_results = {}
    
    def analyze(self) -> Dict:
        """Run complete analysis and return structured results"""
        return {
            'auth_type': self._detect_auth_type(),
            'auth_endpoints': self._extract_auth_endpoints(),
            'forms': self._analyze_forms(),
            'csrf_tokens': self._extract_csrf_tokens(),
            'api_endpoints': self._extract_api_endpoints(),
            'scripts': self._analyze_scripts(),
            'cookies_required': self._detect_required_cookies(),
            'headers_required': self._detect_required_headers(),
            'javascript_events': self._analyze_js_events(),
            'payload_injection_points': self._find_injection_points(),
            'page_structure': self._analyze_structure(),
            'suspicious_elements': self._find_suspicious_elements()
        }
    
    def _detect_auth_type(self) -> Dict[str, any]:
        """Detect type of authentication used on page"""
        results = {'type': 'unknown', 'providers': [], 'flow': 'basic'}
        
        # Check OAuth providers
        for provider, patterns in self.OAUTH_PATTERNS.items():
            for pattern in patterns:
                if re.search(pattern, self.html, re.IGNORECASE):
                    results['providers'].append(provider)
                    results['type'] = 'oauth'
        
        # Check SSO methods
        for method, patterns in self.SSO_PATTERNS.items():
            for pattern in patterns:
                if re.search(pattern, self.html, re.IGNORECASE):
                    if results['type'] != 'oauth':
                        results['type'] = 'sso'
                    results['providers'].append(method)
        
        # Check for 2FA/MFA
        has_mfa = False
        for mfa_type, patterns in self.MFA_PATTERNS.items():
            for pattern in patterns:
                if re.search(pattern, self.html, re.IGNORECASE):
                    has_mfa = True
                    results['providers'].append(f"mfa_{mfa_type}")
        
        if has_mfa:
            results['flow'] = 'multi_factor'
        
        # Fallback to basic auth
        if results['type'] == 'unknown':
            if self._has_login_form():
                results['type'] = 'basic'
                results['flow'] = 'simple'
        
        return results
    
    def _extract_auth_endpoints(self) -> List[str]:
        """Extract authentication endpoints from page"""
        endpoints = []
        
        # Find form actions
        for form in self.soup.find_all('form'):
            action = form.get('action', '')
            if action:
                if action.startswith('http'):
                    endpoints.append(action)
                else:
                    endpoints.append(urljoin(self.base_url, action))
        
        # Find OAuth authorize URLs
        oauth_urls = re.findall(r'https?://[^\s"\'<>]+(?:oauth|authorize|login)[^\s"\'<>]*', self.html, re.IGNORECASE)
        endpoints.extend(oauth_urls)
        
        # Find API endpoints
        api_urls = re.findall(r'https?://[^\s"\'<>]+/api/[^\s"\'<>]*', self.html)
        endpoints.extend(api_urls)
        
        return list(set(endpoints))
    
    def _analyze_forms(self) -> List[Dict]:
        """Analyze all forms on the page"""
        forms = []
        
        for form_idx, form in enumerate(self.soup.find_all('form')):
            form_data = {
                'id': form.get('id', f'form_{form_idx}'),
                'name': form.get('name', ''),
                'action': form.get('action', ''),
                'method': form.get('method', 'GET').upper(),
                'fields': [],
                'has_csrf': False,
                'encoding': form.get('enctype', 'application/x-www-form-urlencoded')
            }
            
            # Analyze form fields
            for field in form.find_all(['input', 'select', 'textarea']):
                field_info = {
                    'type': field.get('type', 'text'),
                    'name': field.get('name', ''),
                    'id': field.get('id', ''),
                    'value': field.get('value', ''),
                    'required': field.has_attr('required'),
                    'autocomplete': field.get('autocomplete', '')
                }
                
                # Detect CSRF tokens
                if 'csrf' in field.get('name', '').lower() or 'token' in field.get('name', '').lower():
                    form_data['has_csrf'] = True
                
                form_data['fields'].append(field_info)
            
            forms.append(form_data)
        
        return forms
    
    def _extract_csrf_tokens(self) -> Dict[str, str]:
        """Extract CSRF tokens and similar protection mechanisms"""
        tokens = {}
        
        # Find hidden inputs that look like tokens
        for form in self.soup.find_all('form'):
            for input_field in form.find_all('input', {'type': 'hidden'}):
                name = input_field.get('name', '').lower()
                if any(keyword in name for keyword in ['csrf', 'token', 'nonce', 'state', '_token', 'authenticity']):
                    tokens[input_field.get('name', 'unknown')] = input_field.get('value', '')
        
        # Find meta tags with tokens
        for meta in self.soup.find_all('meta'):
            name = meta.get('name', '').lower()
            if 'token' in name or 'csrf' in name:
                tokens[meta.get('name', 'unknown')] = meta.get('content', '')
        
        # Find JavaScript variables
        js_match = re.search(r'(?:csrf|token|nonce)["\']?\s*[=:]\s*["\']([a-f0-9]{32,})["\']', self.html, re.IGNORECASE)
        if js_match:
            tokens['js_token'] = js_match.group(1)
        
        return tokens
    
    def _extract_api_endpoints(self) -> List[str]:
        """Extract API endpoints from page resources and JavaScript"""
        endpoints = []
        
        # Find fetch/XHR calls
        fetch_pattern = r'(?:fetch|XMLHttpRequest)\(["\']([^"\']+)["\']'
        endpoints.extend(re.findall(fetch_pattern, self.html))
        
        # Find axios calls
        axios_pattern = r'axios\.(?:get|post|put|delete)\(["\']([^"\']+)["\']'
        endpoints.extend(re.findall(axios_pattern, self.html))
        
        # Find jQuery AJAX
        ajax_pattern = r'\$\.ajax\(\{[^}]*url["\']?\s*[=:]\s*["\']([^"\']+)["\']'
        endpoints.extend(re.findall(ajax_pattern, self.html))
        
        return list(set(endpoints))
    
    def _analyze_scripts(self) -> List[Dict]:
        """Analyze inline and external scripts"""
        scripts = []
        
        # External scripts
        for script in self.soup.find_all('script', {'src': True}):
            scripts.append({
                'type': 'external',
                'src': script.get('src', ''),
                'integrity': script.get('integrity', ''),
                'async': script.has_attr('async'),
                'defer': script.has_attr('defer')
            })
        
        # Inline scripts - look for sensitive content
        for script in self.soup.find_all('script', {'src': False}):
            content = script.string or ''
            if len(content) > 0 and any(keyword in content.lower() for keyword in ['auth', 'token', 'api', 'key']):
                scripts.append({
                    'type': 'inline',
                    'size': len(content),
                    'has_auth': True,
                    'preview': content[:200]
                })
        
        return scripts
    
    def _detect_required_cookies(self) -> List[str]:
        """Detect cookies that might be required"""
        cookies = []
        
        # Look for cookie setting/checking in HTML
        cookie_pattern = r'document\.cookie|Set-Cookie|cookie.*=|getCookie|setCookie'
        if re.search(cookie_pattern, self.html, re.IGNORECASE):
            cookies.append('session_id')
            cookies.append('auth_token')
            cookies.append('csrf_token')
        
        return cookies
    
    def _detect_required_headers(self) -> List[str]:
        """Detect headers that might be required"""
        headers = []
        
        # Check for API/XHR requirements
        if 'api' in self.html.lower() or 'fetch' in self.html.lower():
            headers.append('X-Requested-With: XMLHttpRequest')
            headers.append('Accept: application/json')
        
        # Check for specific frameworks
        if 'csrf' in self.html.lower():
            headers.append('X-CSRF-Token')
        
        return headers
    
    def _analyze_js_events(self) -> Dict[str, List[str]]:
        """Analyze JavaScript event handlers"""
        events = {}
        
        # Look for event handlers
        for event_type in ['onclick', 'onsubmit', 'onchange', 'onload', 'onerror']:
            pattern = f'{event_type}=["\']([^"\']+)["\']'
            matches = re.findall(pattern, self.html, re.IGNORECASE)
            if matches:
                events[event_type] = matches
        
        return events
    
    def _find_injection_points(self) -> List[Dict]:
        """Find potential injection/hook points in the page"""
        injection_points = []
        
        # Form fields
        for form in self.soup.find_all('form'):
            for field in form.find_all(['input', 'textarea']):
                if field.get('name'):
                    injection_points.append({
                        'type': 'form_field',
                        'name': field.get('name'),
                        'location': 'form',
                        'payload_type': 'keylogger'
                    })
        
        # JavaScript timers - for payload injection
        if 'setInterval' in self.html or 'setTimeout' in self.html:
            injection_points.append({
                'type': 'js_timer',
                'location': 'script',
                'payload_type': 'form_hijack'
            })
        
        # Global JavaScript objects
        if 'window.' in self.html or 'document.' in self.html:
            injection_points.append({
                'type': 'global_override',
                'location': 'window',
                'payload_type': 'credential_capture'
            })
        
        return injection_points
    
    def _analyze_structure(self) -> Dict:
        """Analyze overall page structure"""
        structure = {
            'title': self.soup.title.string if self.soup.title else '',
            'has_header': bool(self.soup.find(['header', 'nav'])),
            'has_footer': bool(self.soup.find(['footer', 'footerContent'])),
            'forms_count': len(self.soup.find_all('form')),
            'images_count': len(self.soup.find_all('img')),
            'links_count': len(self.soup.find_all('a')),
            'inputs_count': len(self.soup.find_all('input')),
            'scripts_count': len(self.soup.find_all('script')),
            'stylesheets_count': len(self.soup.find_all('link', {'rel': 'stylesheet'})),
            'contains_recaptcha': 'recaptcha' in self.html.lower(),
            'contains_hcaptcha': 'hcaptcha' in self.html.lower(),
        }
        
        return structure
    
    def _find_suspicious_elements(self) -> List[str]:
        """Identify suspicious security measures"""
        suspicious = []
        
        if 'reCAPTCHA' in self.html or 'recaptcha' in self.html.lower():
            suspicious.append('reCAPTCHA detected')
        
        if 'botonet' in self.html.lower() or 'bot' in self.html.lower():
            suspicious.append('Bot detection code present')
        
        if 'cloudflare' in self.html.lower():
            suspicious.append('Cloudflare protection detected')
        
        if 'csp-report' in self.html or 'content-security-policy' in self.html:
            suspicious.append('Content Security Policy detected')
        
        return suspicious
    
    def _has_login_form(self) -> bool:
        """Check if page has login form"""
        for form in self.soup.find_all('form'):
            for field in form.find_all('input'):
                if 'password' in field.get('name', '').lower() or 'password' in field.get('type', '').lower():
                    return True
        return False
    
    @staticmethod
    def generate_clone_hash(analysis: Dict) -> str:
        """Generate unique hash for clone based on analysis"""
        signature = json.dumps(analysis, sort_keys=True, default=str)
        return hashlib.sha256(signature.encode()).hexdigest()[:16]
