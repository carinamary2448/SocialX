# Run this script to reorganize the project structure
# Requires: Windows PowerShell or compatible shell

# Navigate to project root
cd "c:\Users\user\Downloads\workedproject\RealXP"

# Verify directories exist
if (-not (Test-Path "utilities")) {
    Write-Host "utilities directory not found. Creating..."
}

if (-not (Test-Path "features/cloning")) {
    Write-Host "features/cloning directory not found. Creating..."
}

Write-Host "Starting project reorganization..."
Write-Host ""

# Array of files to move to utilities
$filesToMove = @(
    # Testing Scripts
    "automated_test.py",
    "automated_browser_test.py", 
    "automated_browser_advanced.py",
    "final_comprehensive_tests.py",
    "comprehensive_test_and_browser.py",
    "quick_test_capture.py",
    
    # Debugging Scripts
    "comprehensive_debug.py",
    "verify_debug_logging.py",
    "debug_report.txt",
    "server.stderr.log",
    "server.stdout.log",
    
    # Analysis Scripts
    "analyze_logging.py",
    "ui_bug_scanner.py",
    "critical_scanner.py",
    
    # Database & Schema
    "check_schema.py",
    "check_and_fix_schema.py",
    "verify_schema.py",
    "fix_schema.py",
    "fix_data_capture.py",
    
    # Cleanup
    "cleanup_duplicates.py",
    "cleanup_route_duplicates.py",
    
    # Audit
    "comprehensive_bug_audit.py",
    "comprehensive_system_fixer.py",
    "final_system_verification.py",
    "COMPREHENSIVE_BUG_AUDIT_REPORT.txt",
    
    # Utilities
    "auto_logging_decorator.py",
    "automation_master.py"
)

$moved = 0
$failed = 0
$notfound = 0

foreach ($file in $filesToMove) {
    if (Test-Path $file) {
        try {
            Move-Item -Path $file -Destination "utilities/$file" -Force
            Write-Host "[+] Moved: $file" -ForegroundColor Green
            $moved++
        }
        catch {
            Write-Host "[-] Failed to move: $file" -ForegroundColor Red
            Write-Host "    Error: $_"
            $failed++
        }
    }
    else {
        Write-Host "[?] Not found: $file" -ForegroundColor Yellow
        $notfound++
    }
}

# Move report files
$reportFiles = @(
    "COMPREHENSIVE_ANALYSIS_REPORT.txt",
    "PROJECT_ANALYSIS_FROM_MD_FILES.txt",
    "FINAL_SYSTEM_VERIFICATION_REPORT.txt",
    "test_output.txt"
)

foreach ($file in $reportFiles) {
    if (Test-Path $file) {
        try {
            Move-Item -Path $file -Destination "utilities/$file" -Force
            Write-Host "[+] Moved report: $file" -ForegroundColor Green
            $moved++
        }
        catch {
            Write-Host "[-] Failed to move report: $file" -ForegroundColor Red
            $failed++
        }
    }
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Migration Summary:" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Moved: $moved files" -ForegroundColor Green
Write-Host "Failed: $failed files" -ForegroundColor Yellow
Write-Host "Not found: $notfound files" -ForegroundColor Yellow
Write-Host ""

# List remaining files in root
Write-Host "Files remaining in root (sample):" -ForegroundColor Cyan
Get-ChildItem -Filter "*.py" -File | Select-Object -First 15 | ForEach-Object { Write-Host "  - $($_.Name)" }

Write-Host ""
Write-Host "Migration complete!"
Write-Host "Next steps:"
Write-Host "1. Update imports in SocialFish.py"
Write-Host "2. Update requirements.txt if needed"
Write-Host "3. Run tests: python utilities/comprehensive_test_and_browser.py"
Write-Host "4. Verify database: python utilities/verify_schema.py"
