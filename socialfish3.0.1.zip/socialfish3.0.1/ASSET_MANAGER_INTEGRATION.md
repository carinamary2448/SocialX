# Asset Manager Integration Guide

## Overview

The enhanced `AssetDownloader` in `features/cloning/asset_manager.py` now provides comprehensive HTML asset processing. When you clone a website, ALL assets (CSS, JS, images, fonts, videos, favicons) are:

1. **Downloaded** to local storage
2. **Analyzed** for dependencies
3. **Fixed** in HTML to reference local copies
4. **Optimized** to reduce page load times
5. **Tracked** for debugging and verification

## Key Features

### 1. Complete Asset Coverage

The asset manager handles:
- **Stylesheets**: CSS files with @import and url() processing
- **Scripts**: JavaScript files with sourcemaps
- **Images**: PNG, JPG, GIF, WebP with responsive srcset support
- **Fonts**: @font-face rules with all font variants
- **Media**: Video and audio files with proper streaming
- **Favicon**: .ico, .png formats
- **Tracking Prevention**: Removes analytics and trackers automatically

### 2. Smart HTML Fixing

The `download_and_fix_html()` method:

```python
fixed_html, assets_info = asset_downloader.download_and_fix_html(
    html_content,
    base_url="https://example.com",
    clone_path=Path("templates/clones/example_xyz/")
)
```

Returns:
- **fixed_html**: Complete HTML with all assets relinked to local paths
- **assets_info**: Detailed statistics about what was processed

### 3. Asset Organization

Downloaded assets are organized by type:

```
templates/clones/example_abc123/
├── index.html              # Fixed HTML with local asset refs
├── metadata.json           # Clone metadata
├── css/
│   ├── bootstrap.min.css
│   ├── style.css
│   └── ...
├── js/
│   ├── jquery.min.js
│   ├── app.js
│   └── ...
├── images/
│   ├── logo.png
│   ├── banner.jpg
│   └── ...
├── fonts/
│   ├── Arial-Regular.woff2
│   ├── OpenSans-Bold.woff
│   └── ...
├── media/
│   ├── video.mp4
│   ├── audio.mp3
│   └── ...
└── other/
    ├── favicon.ico
    └── ...
```

## Usage Examples

### Example 1: Basic Website Cloning

```python
from core.real_cloner import RealCloner

cloner = RealCloner()

result = cloner.clone_website(
    target_url="https://example.com",
    include_assets=True  # Download all assets
)

print(f"Clone ID: {result['clone_id']}")
print(f"Total assets: {result['metadata']['fixed_elements_count']}")
print(f"Total size: {result['metadata']['total_size_kb']:.1f} KB")
```

### Example 2: Asset Download with Tracking

```python
from features.cloning import AssetDownloader
from pathlib import Path

downloader = AssetDownloader(clone_dir="templates/clones")

# Process a website's HTML
html_content = """
<html>
  <head>
    <link rel="stylesheet" href="https://cdn.example.com/style.css">
    <script src="https://cdn.example.com/app.js"></script>
  </head>
  <body>
    <img src="/images/logo.png" srcset="/images/logo-2x.png 2x">
  </body>
</html>
"""

fixed_html, info = downloader.download_and_fix_html(
    html_content,
    base_url="https://example.com",
    clone_path=Path("templates/clones/example_xyz/")
)

print(f"Fixed elements: {info['fixed_elements']}")
print(f"Total size: {info['total_size'] / 1024 / 1024:.1f} MB")
print(f"Assets by type: {info['by_type']}")
```

### Example 3: Custom Asset Processing

```python
from features.cloning import AssetDownloader

downloader = AssetDownloader()

# Set custom clone ID and base URL
downloader.clone_id = "my_clone_123"
downloader.base_url = "https://mysite.com"

# Download specific asset
asset_info = downloader._download_and_replace_asset(
    url="/images/pic.png",
    asset_type="images",
    clone_path=Path("templates/clones/my_clone_123/")
)

if asset_info:
    print(f"Downloaded: {asset_info['local_url']}")
    print(f"Size: {asset_info['size']} bytes")
```

### Example 4: CSS Processing with Fonts

```python
# The asset manager automatically:
# 1. Finds all @import statements
# 2. Downloads imported stylesheets
# 3. Finds all @font-face rules
# 4. Downloads font files (woff, woff2, ttf, eot)
# 5. Updates CSS to reference local files

# Example CSS that will be processed:
css = """
@import url('https://fonts.googleapis.com/css2?family=Roboto');

@font-face {
  font-family: 'CustomFont';
  src: url('https://cdn.example.com/font.woff2') format('woff2'),
       url('https://cdn.example.com/font.woff') format('woff');
}

body {
  background-image: url('/images/bg.jpg');
  font-family: 'Roboto', 'CustomFont', sans-serif;
}
"""

# After processing, URLs will point to:
# /clone/clone_id/css/imported_stylesheet_hash.css
# /clone/clone_id/fonts/font_hash.woff2
# /clone/clone_id/images/bg_hash.jpg
```

### Example 5: Responsive Images

```python
# Original HTML:
html = """
<img src="/images/pic.jpg"
     srcset="/images/pic-small.jpg 480w,
             /images/pic-medium.jpg 1024w,
             /images/pic-large.jpg 2048w"
     alt="Responsive image">
"""

# After processing:
# - All variants are downloaded
# - srcset is relinked:
#   /clone/id/images/pic_small_hash.jpg 480w,
#   /clone/id/images/pic_medium_hash.jpg 1024w,
#   /clone/id/images/pic_large_hash.jpg 2048w
```

### Example 6: Tracking Prevention

```python
# Automatically removed:
# - Google Analytics (ga.js, analytics.js, gtag.js)
# - Facebook Pixel
# - Segment
# - Mixpanel
# - Any script from tracking domains

# This prevents the cloned page from notifying the original site
# that it has been cloned and accessed
```

## Configuration

### Asset Manager Settings

```python
from features.cloning import AssetDownloader

downloader = AssetDownloader(
    clone_dir="templates/clones",  # Where to store clones
    timeout=15,                     # Request timeout (seconds)
    max_retries=3                   # Retry failed downloads
)

# Adjust file size limits
downloader.MAX_FILE_SIZE = 50 * 1024 * 1024  # 50MB instead of 20MB

# Clear cache if needed
downloader.clear_cache()
```

### Supported Asset Types

```python
ASSET_TYPES = {
    'css': ['.css'],
    'js': ['.js', '.mjs'],
    'images': ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg', '.ico'],
    'fonts': ['.woff', '.woff2', '.ttf', '.eot', '.otf'],
    'media': ['.mp4', '.webm', '.ogg', '.mp3', '.wav', '.m4a'],
    'html': ['.html', '.htm'],
    'other': ['.ico']
}
```

## Integration with Flask

```python
from flask import Flask, send_file
from core.real_cloner import RealCloner

app = Flask(__name__)
cloner = RealCloner()

@app.route('/clone/<clone_id>')
def serve_clone(clone_id):
    """Serve cloned website"""
    html = cloner.get_clone_html(clone_id)
    if html:
        return html, 200, {'Content-Type': 'text/html; charset=utf-8'}
    return "Clone not found", 404

@app.route('/clone/<clone_id>/<asset_type>/<filename>')
def serve_asset(clone_id, asset_type, filename):
    """Serve downloaded assets"""
    asset_path = cloner.clone_dir / clone_id / asset_type / filename
    if asset_path.exists():
        return send_file(asset_path)
    return "Asset not found", 404

@app.route('/api/clone', methods=['POST'])
def create_clone():
    """Create new clone via API"""
    url = request.json.get('url')
    result = cloner.clone_website(url, include_assets=True)
    return result
```

## Performance Tips

1. **Asset Caching**: The asset manager caches downloads. Same URL won't be downloaded twice.

2. **Size Limits**: Large files (>20MB) are skipped to avoid huge clones. Adjust `MAX_FILE_SIZE` if needed.

3. **Timeout Settings**: Adjust `timeout` parameter for slow networks.

4. **Parallel Processing**: For multiple clones, consider using Python's `ThreadPoolExecutor`.

5. **Storage**: Monitor disk usage. A full clone of a complex website can be 50-500MB.

## Troubleshooting

### Broken Images/Fonts in Clone

Check the metadata.json for what was downloaded:

```python
import json

metadata_file = Path("templates/clones/clone_id/metadata.json")
metadata = json.load(metadata_file.open())

print(f"Fixed elements: {metadata['fixed_elements_count']}")
print(f"Total size: {metadata['total_size_kb']} KB")

# Check which assets failed
for asset_type, count in metadata['assets_info']['by_type'].items():
    print(f"{asset_type}: {count} items")
```

### Missing Assets

1. Check the clone logs for download errors
2. Verify the `base_url` is correct
3. Check if assets are behind a login/auth
4. Some assets might be blocked by CORS

### Performance Issues

1. Reduce `MAX_FILE_SIZE` to skip heavy videos
2. Disable asset downloading for specific sites
3. Use `include_assets=False` for metadata-only clones

## Security Notes

⚠️ **Important**: Downloaded clones contain the actual content of the original website. Be aware of:

- **Copyright**: Cloned content may be protected
- **Privacy**: Cloned pages may contain sensitive information
- **Storage**: Large clones consume significant disk space
- **Updates**: Clones are static snapshots; they won't update automatically

## Advanced Customization

Extend `AssetDownloader` for custom behavior:

```python
class CustomAssetDownloader(AssetDownloader):
    def _download_and_replace_asset(self, url, asset_type, clone_path):
        # Custom logic before download
        result = super()._download_and_replace_asset(url, asset_type, clone_path)
        # Custom logic after download
        return result
    
    def optimize_javascript(self, js_content):
        # Custom JS optimization
        return js_content
    
    def optimize_css(self, css_content):
        # Custom CSS optimization
        return css_content
```

## See Also

- [features/cloning/asset_manager.py](features/cloning/asset_manager.py) - Core implementation
- [core/real_cloner.py](core/real_cloner.py) - Website cloning integration
- [features/cloning/form_capture.py](features/cloning/form_capture.py) - Form analysis
- [SocialFish.py](SocialFish.py) - Main Flask application
