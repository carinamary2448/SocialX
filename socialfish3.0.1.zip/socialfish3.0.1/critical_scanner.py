#!/usr/bin/env python3
"""
CRITICAL ISSUES SCANNER FOR SOCIALFISH V3.0
Identifies and reports all critical security, database, and code issues
"""

import sqlite3
import os
import re
import sys
from pathlib import Path

class CriticalIssuesScanner:
    """Comprehensive critical issues scanner"""
    
    def __init__(self):
        self.critical_issues = []
        self.warnings = []
        self.database = "./database.db"
        
    def scan_all(self):
        """Run all critical scans"""
        print("\n" + "="*80)
        print("CRITICAL ISSUES SCANNER - SOCIALFISH V3.0")
        print("="*80 + "\n")
        
        self.scan_database_integrity()
        self.scan_security_issues()
        self.scan_code_issues()
        self.scan_configuration()
        self.scan_dependencies()
        
        self.report_and_exit()
    
    def add_critical(self, issue, file="", line=0):
        """Add critical issue"""
        self.critical_issues.append({
            "severity": "CRITICAL",
            "issue": issue,
            "file": file,
            "line": line
        })
    
    def add_warning(self, issue, file="", line=0):
        """Add warning"""
        self.warnings.append({
            "severity": "WARNING",
            "issue": issue,
            "file": file,
            "line": line
        })
    
    def scan_database_integrity(self):
        """Scan database for critical issues"""
        print("[*] Scanning database integrity...")
        
        if not os.path.exists(self.database):
            self.add_critical("Database file missing - application cannot function")
            return
        
        try:
            conn = sqlite3.connect(self.database)
            cursor = conn.cursor()
            
            # Check if tables exist
            cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
            tables = [row[0] for row in cursor.fetchall()]
            
            required_tables = ['creds', 'sessions', 'templates', 'lures']
            for table in required_tables:
                if table not in tables:
                    self.add_critical(f"Critical table missing: {table}")
            
            # Check creds table columns
            cursor.execute("PRAGMA table_info(creds)")
            columns = [row[1] for row in cursor.fetchall()]
            required_cols = ['id', 'username', 'password', 'url']
            for col in required_cols:
                if col not in columns:
                    self.add_critical(f"Creds table missing critical column: {col}")
            
            # Check for database corruption
            try:
                cursor.execute("SELECT COUNT(*) FROM creds")
                cursor.execute("SELECT COUNT(*) FROM sessions")
                print("  [OK] Database integrity check passed")
            except sqlite3.DatabaseError as e:
                self.add_critical(f"Database corruption detected: {str(e)}")
            
            conn.close()
            
        except Exception as e:
            self.add_critical(f"Database access error: {str(e)}")
    
    def scan_security_issues(self):
        """Scan for security vulnerabilities"""
        print("[*] Scanning for security vulnerabilities...")
        
        try:
            with open("SocialFish.py", "r", encoding='utf-8', errors='ignore') as f:
                content = f.read()
                lines = content.split('\n')
            
            # Check for SQL injection risks
            sql_injection_patterns = [
                r'execute.*\+.*\+',
                r'query.*%' + r's.*%',
                r'query.*f".*\{',
            ]
            for pattern in sql_injection_patterns:
                for i, line in enumerate(lines):
                    if re.search(pattern, line) and 'parameterized' not in line:
                        if 'execute' in line and '?' not in line:
                            self.add_warning(f"Potential SQL injection: {line.strip()}", "SocialFish.py", i+1)
            
            # Check for hardcoded credentials
            cred_patterns = [
                r'password\s*=\s*["\'].*["\']',
                r'api_key\s*=\s*["\'].*["\']',
                r'secret\s*=\s*["\'].*["\']',
            ]
            for pattern in cred_patterns:
                for i, line in enumerate(lines):
                    if re.search(pattern, line) and 'admin' not in line.lower():
                        self.add_critical(f"Hardcoded credentials detected: {line.strip()}", "SocialFish.py", i+1)
            
            # Check for insecure random
            if 'random.random()' in content or 'random.randint' in content:
                self.add_warning("Non-cryptographic random usage detected", "SocialFish.py")
            
            # Check for eval/exec usage
            if re.search(r'\beval\s*\(', content):
                self.add_critical("eval() usage found - critical security risk", "SocialFish.py")
            if re.search(r'\bexec\s*\(', content):
                self.add_critical("exec() usage found - critical security risk", "SocialFish.py")
            
            # Check for pickle usage
            if 'pickle' in content and 'untrusted' not in content:
                self.add_warning("Pickle usage may be unsafe if deserializing untrusted data", "SocialFish.py")
            
            print("  [OK] Security scan completed")
            
        except Exception as e:
            self.add_warning(f"Could not complete security scan: {str(e)}")
    
    def scan_code_issues(self):
        """Scan for critical code issues"""
        print("[*] Scanning for critical code issues...")
        
        py_files = list(Path(".").rglob("*.py"))
        critical_found = False
        
        for py_file in py_files:
            if '__pycache__' in str(py_file):
                continue
            
            try:
                with open(py_file, 'r', encoding='utf-8', errors='ignore') as f:
                    lines = f.readlines()
                
                for i, line in enumerate(lines):
                    # Check for missing error handling in critical sections
                    if 'database' in line.lower() and 'try' not in lines[max(0, i-3):i]:
                        if 'execute' in line or 'connect' in line:
                            self.add_warning(f"Database operation without try-except: {line.strip()}", str(py_file), i+1)
                    
                    # Check for infinite loops
                    if 'while True:' in line:
                        self.add_warning(f"Infinite loop detected: {line.strip()}", str(py_file), i+1)
                    
                    # Check for uninitialized variables
                    if 'assert' in line and 'variable' not in line:
                        self.add_warning(f"Assert statement in code: {line.strip()}", str(py_file), i+1)
                
                # Try to compile to check syntax
                try:
                    compile(''.join(lines), str(py_file), 'exec')
                except SyntaxError as e:
                    self.add_critical(f"Syntax error: {str(e)}", str(py_file), e.lineno)
                    critical_found = True
                
            except Exception as e:
                self.add_warning(f"Could not scan {py_file}: {str(e)}")
        
        if not critical_found:
            print("  [OK] Code scan completed - no syntax errors found")
    
    def scan_configuration(self):
        """Scan for configuration issues"""
        print("[*] Scanning configuration...")
        
        # Check core config
        if not os.path.exists("core/config.py"):
            self.add_critical("core/config.py missing - critical configuration file")
        else:
            try:
                with open("core/config.py", "r", encoding='utf-8', errors='ignore') as f:
                    config = f.read()
                
                if 'SECRET_KEY' not in config or not re.search(r'SECRET_KEY\s*=\s*["\'].{10,}', config):
                    self.add_warning("SECRET_KEY not properly configured or weak")
                
                if 'DEBUG = True' in config:
                    self.add_critical("DEBUG mode enabled in production configuration")
                
            except Exception as e:
                self.add_warning(f"Could not scan config: {str(e)}")
        
        # Check requirements
        if not os.path.exists("requirements.txt"):
            self.add_warning("requirements.txt missing - dependency tracking not available")
        
        print("  [OK] Configuration scan completed")
    
    def scan_dependencies(self):
        """Scan for missing critical dependencies"""
        print("[*] Scanning dependencies...")
        
        try:
            with open("SocialFish.py", "r", encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            required_imports = [
                ('flask', 'Flask'),
                ('flask_socketio', 'Socket.IO'),
                ('sqlite3', 'SQLite3'),
            ]
            
            missing = []
            for module, name in required_imports:
                if f'import {module}' not in content and f'from {module}' not in content:
                    missing.append(f"{name} ({module})")
            
            if missing:
                self.add_critical(f"Critical imports missing: {', '.join(missing)}")
            else:
                print("  [OK] All critical dependencies imported")
                
        except Exception as e:
            self.add_warning(f"Could not scan dependencies: {str(e)}")
    
    def report_and_exit(self):
        """Generate report and determine exit status"""
        print("\n" + "="*80)
        print("SCAN RESULTS")
        print("="*80 + "\n")
        
        if self.critical_issues:
            print(f"🔴 CRITICAL ISSUES FOUND: {len(self.critical_issues)}\n")
            for i, issue in enumerate(self.critical_issues, 1):
                print(f"{i}. {issue['issue']}")
                if issue['file']:
                    print(f"   File: {issue['file']}")
                if issue['line']:
                    print(f"   Line: {issue['line']}")
                print()
        else:
            print("[OK] NO CRITICAL ISSUES FOUND\n")
        
        if self.warnings:
            print(f"⚠️  WARNINGS: {len(self.warnings)}\n")
            for i, warn in enumerate(self.warnings[:10], 1):  # Show first 10
                print(f"{i}. {warn['issue']}")
                if warn['file']:
                    print(f"   File: {warn['file']}")
            if len(self.warnings) > 10:
                print(f"\n... and {len(self.warnings) - 10} more warnings")
        
        print("\n" + "="*80)
        if self.critical_issues:
            print(f"STATUS: 🔴 CRITICAL - {len(self.critical_issues)} critical issues found")
            return 1
        else:
            print("STATUS: [OK] SAFE - No critical issues detected")
            return 0

if __name__ == "__main__":
    scanner = CriticalIssuesScanner()
    exit_code = scanner.scan_all()
    sys.exit(exit_code)
