#!/usr/bin/env python3
"""
UI/UX BUG SCANNER & TESTER
Scans for missing buttons, incomplete panels, routing issues, and data display problems
"""

import os
import re
import sqlite3
import json
from pathlib import Path
from datetime import datetime

DATABASE = "database.db"
TEMPLATES_DIR = "templates/admin"

class UIBugScanner:
    def __init__(self):
        self.issues = []
        self.warnings = []
        self.missing_features = []
        
    def scan_all(self):
        print("\n" + "="*80)
        print("          🔍 COMPREHENSIVE UI/UX BUG SCANNER")
        print("="*80 + "\n")
        
        self.scan_html_files()
        self.scan_missing_buttons()
        self.scan_table_columns()
        self.scan_panel_integration()
        self.scan_websocket_events()
        self.scan_data_display()
        self.scan_routes()
        
        self.print_report()
        
    def scan_html_files(self):
        """Scan HTML templates for structure issues"""
        print("[*] Scanning HTML templates...")
        for html_file in Path(TEMPLATES_DIR).glob("*.html"):
            with open(html_file, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                
            # Check for missing closing tags
            if content.count('<div') != content.count('</div'):
                self.issues.append(f"❌ {html_file.name}: Mismatched <div> tags")
                
            # Check for scripts without src or content
            scripts = re.findall(r'<script[^>]*>', content)
            for script in scripts:
                if 'src=' not in script and not re.search(r'<script[^>]*>.*?</script>', content, re.DOTALL):
                    self.warnings.append(f"⚠️  {html_file.name}: Empty or incomplete <script> tag")
                    
    def scan_missing_buttons(self):
        """Scan for missing action buttons in panels"""
        print("[*] Scanning for missing action buttons...")
        
        index_html = "templates/admin/index.html"
        with open(index_html, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
            
        # Check successful attacks table
        if "Successful attacks" in content:
            # Expected columns
            required_columns = ["url", "ip", "browser", "operating system", "date", "port scan", "post log"]
            found_columns = [col for col in required_columns if col.lower() in content.lower()]
            missing_cols = set(required_columns) - set(found_columns)
            
            if missing_cols:
                self.issues.append(f"❌ Successful Attacks Table: Missing columns - {missing_cols}")
            
            # Check for action buttons
            required_buttons = ["View", "Export", "Delete", "Copy", "Share"]
            found_buttons = [btn for btn in required_buttons if btn in content]
            missing_buttons = set(required_buttons) - set(found_buttons)
            
            for btn in missing_buttons:
                self.warnings.append(f"⚠️  Successful Attacks Table: Missing '{btn}' button")
                
        # Check credentials panel
        if "Captured Credentials" in content or "credentialsPanel" in content:
            if "Copy" not in content:
                self.warnings.append("⚠️  Credentials Panel: Missing 'Copy' button")
            if "Delete" not in content:
                self.warnings.append("⚠️  Credentials Panel: Missing 'Delete' button")
            if "Export" not in content:
                self.warnings.append("⚠️  Credentials Panel: Missing 'Export' button")
                
    def scan_table_columns(self):
        """Scan for incomplete table definitions"""
        print("[*] Scanning table column definitions...")
        
        # Check index.html for table headers
        index_html = "templates/admin/index.html"
        with open(index_html, 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
            
        # Find all table sections
        tables = re.findall(r'<table[^>]*>.*?</table>', content, re.DOTALL)
        
        table_count = 0
        for table in tables[:5]:  # Check first 5 tables
            table_count += 1
            headers = re.findall(r'<th>([^<]+)</th>', table)
            rows = re.findall(r'<tr[^>]*>.*?</tr>', table, re.DOTALL)
            
            if headers and rows:
                # Count columns in rows
                for row in rows[:3]:  # Check first 3 rows
                    cols = re.findall(r'<td[^>]*>.*?</td>', row, re.DOTALL)
                    if len(cols) < len(headers):
                        self.warnings.append(
                            f"⚠️  Table {table_count}: Column mismatch - "
                            f"Headers: {len(headers)}, Columns: {len(cols)}"
                        )
                        
    def scan_panel_integration(self):
        """Scan for disconnected panels and missing integration"""
        print("[*] Scanning panel integration...")
        
        live_panel = "templates/admin/live_login_panel.html"
        if os.path.exists(live_panel):
            with open(live_panel, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                
            # Check for all expected sections
            expected_sections = [
                "Live Victim Sessions",
                "Captured Credentials",
                "Cookies Analysis",
                "OTP",
                "Network Activity",
                "MFA Detection",
                "Session Timeline",
                "Webhooks",
                "Analytics"
            ]
            
            for section in expected_sections:
                if section not in content:
                    self.warnings.append(f"⚠️  Live Login Panel: Missing '{section}' section")
                    
        # Check OTP panel
        otp_panel = "templates/admin/otp_panel.html"
        if os.path.exists(otp_panel):
            with open(otp_panel, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                if "Session ID" not in content:
                    self.warnings.append("⚠️  OTP Panel: Missing Session ID display")
                    
    def scan_websocket_events(self):
        """Scan for WebSocket event mismatches"""
        print("[*] Scanning WebSocket event definitions...")
        
        # Check SocialFish.py for emitted events
        with open("SocialFish.py", 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
            
        emitted_events = set(re.findall(r"socketio\.emit\('([^']+)'", content))
        
        # Check HTML files for listeners
        for html_file in Path(TEMPLATES_DIR).glob("*.html"):
            with open(html_file, 'r', encoding='utf-8', errors='ignore') as f:
                html_content = f.read()
                
            listened_events = set(re.findall(r"socket\.on\('([^']+)'", html_content))
            
            missing_listeners = emitted_events - listened_events
            if missing_listeners:
                self.issues.append(
                    f"❌ {html_file.name}: Missing event listeners - {missing_listeners}"
                )
                
    def scan_data_display(self):
        """Scan for missing data display elements"""
        print("[*] Scanning data display elements...")
        
        # Check if credentials are displayed properly
        with open("templates/admin/index.html", 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
            
        # Successful attacks table data mapping
        if "{% for item in data %}" in content:
            # Find what fields are being used
            fields = re.findall(r'\{\{item\[(\d+)\]', content)
            if fields:
                max_field = max(int(f) for f in fields)
                if max_field > 8:
                    self.issues.append(
                        f"❌ index.html: Credential table accesses field {max_field}, "
                        f"but database may not have that many columns"
                    )
        
        # Check live panel data binding
        live_file = "templates/admin/live_login_panel.html"
        if os.path.exists(live_file):
            with open(live_file, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                
            # Check for undefined data references
            js_refs = re.findall(r'session\.(\w+)|data\.(\w+)|s\.(\w+)', content)
            if not js_refs:
                self.warnings.append("⚠️  Live Panel: May have undefined data references")
                
    def scan_routes(self):
        """Scan for missing or incomplete routes"""
        print("[*] Scanning routes...")
        
        with open("SocialFish.py", 'r', encoding='utf-8', errors='ignore') as f:
            content = f.read()
            
        routes = re.findall(r'@app\.route\(["\']([^"\']+)["\']', content)
        
        expected_routes = [
            "/",
            "/creds",
            "/sessions",
            "/api/sessions",
            "/studio/live-panel",
            "/studio/otp-panel",
            "/admin/attack-payloads",
            "/api/credentials",
            "/api/export"
        ]
        
        found_routes = set(routes)
        missing_routes = set(expected_routes) - found_routes
        
        if missing_routes:
            for route in missing_routes:
                self.warnings.append(f"⚠️  Missing route: {route}")
                
    def print_report(self):
        """Print comprehensive report"""
        print("\n" + "="*80)
        print("📊 SCAN RESULTS")
        print("="*80 + "\n")
        
        if self.issues:
            print("❌ CRITICAL ISSUES:")
            for issue in self.issues:
                print(f"   {issue}")
            print()
            
        if self.warnings:
            print("⚠️  WARNINGS:")
            for warning in self.warnings:
                print(f"   {warning}")
            print()
            
        print(f"📈 SUMMARY:")
        print(f"   Critical Issues: {len(self.issues)}")
        print(f"   Warnings: {len(self.warnings)}")
        print(f"   Total: {len(self.issues) + len(self.warnings)}")
        
        if not self.issues and not self.warnings:
            print("   [OK] No critical issues found!")
            
        print("\n" + "="*80 + "\n")


class UIPanelTester:
    """Test all pages from login menu"""
    
    def __init__(self):
        self.test_results = []
        
    def test_all_panels(self):
        print("\n" + "="*80)
        print("          🧪 UI PANEL FUNCTIONALITY TEST")
        print("="*80 + "\n")
        
        # Define all accessible panels
        panels = {
            "Dashboard": "/",
            "Credentials": "/creds",
            "Sessions": "/sessions",
            "Live Panel": "/studio/live-panel",
            "OTP Panel": "/studio/otp-panel",
            "Webhooks": "/admin/webhooks",
            "Templates": "/admin/templates",
            "Companies": "/admin/companies",
            "Lures": "/admin/lures"
        }
        
        print("[*] Testing panel accessibility...\n")
        
        for name, route in panels.items():
            # Test route exists in SocialFish.py
            with open("SocialFish.py", 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                
            if f'@app.route("{route}"' in content or f"@app.route('{route}'" in content:
                print(f"[OK] {name:20} ({route:30}) - ROUTE FOUND")
                self.test_results.append((name, "PASS"))
            else:
                print(f"❌ {name:20} ({route:30}) - ROUTE MISSING")
                self.test_results.append((name, "FAIL"))
                
        # Summary
        print("\n" + "-"*80)
        passed = sum(1 for _, r in self.test_results if r == "PASS")
        failed = sum(1 for _, r in self.test_results if r == "FAIL")
        print(f"\nTest Results: {passed}/{len(self.test_results)} PASSED")
        if failed > 0:
            print(f"⚠️  {failed} routes need to be created or fixed")
            
        print("\n" + "="*80 + "\n")


def main():
    print("\n" + "█"*80)
    print("█" + " "*78 + "█")
    print("█" + "  🎨 SocialFish UI/UX Bug Scanner & Tester".center(78) + "█")
    print("█" + " "*78 + "█")
    print("█"*80)
    
    # Run bug scanner
    scanner = UIBugScanner()
    scanner.scan_all()
    
    # Run panel tester
    tester = UIPanelTester()
    tester.test_all_panels()
    
    print("\n✨ Scan Complete! Check recommendations above.\n")


if __name__ == "__main__":
    main()
