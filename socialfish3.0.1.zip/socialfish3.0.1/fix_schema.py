#!/usr/bin/env python3
"""
Fix database schema issues - Add missing columns to existing tables
"""

import sqlite3
import os

def fix_templates_table():
    """Add beef column to templates table if missing"""
    db_path = './database.db'
    
    if not os.path.exists(db_path):
        print(f"[-] Database not found: {db_path}")
        return False
    
    try:
        conn = sqlite3.connect(db_path)
        cur = conn.cursor()
        
        # Check if beef column exists in templates table
        cur.execute("PRAGMA table_info(templates)")
        columns = [row[1] for row in cur.fetchall()]
        
        print(f"[*] Templates table columns: {columns}")
        
        if 'beef' not in columns:
            print("[+] Adding 'beef' column to templates table...")
            cur.execute("ALTER TABLE templates ADD COLUMN beef text DEFAULT 'no'")
            conn.commit()
            print("[OK] Successfully added 'beef' column to templates table")
        else:
            print("[OK] 'beef' column already exists in templates table")
        
        # Also check for other potentially missing columns
        expected_columns = {
            'templates': ['id', 'name', 'base_url', 'description', 'tags', 'url', 'status', 'beef', 'webhook', 'created_at', 'updated_at'],
            'config': ['id', 'url', 'red', 'status', 'beef'],
            'lure_urls': ['id', 'template_id', 'lure_hash', 'full_url', 'target_url', 'click_count', 'created_at']
        }
        
        for table_name, expected in expected_columns.items():
            try:
                cur.execute(f"PRAGMA table_info({table_name})")
                existing = [row[1] for row in cur.fetchall()]
                
                missing = [col for col in expected if col not in existing]
                if missing:
                    print(f"[!] Table '{table_name}' missing columns: {missing}")
                    
                    # Try to add missing columns
                    for col in missing:
                        try:
                            if col in ['beef', 'target_url']:
                                cur.execute(f"ALTER TABLE {table_name} ADD COLUMN {col} text DEFAULT 'no'")
                            elif col == 'webhook':
                                cur.execute(f"ALTER TABLE {table_name} ADD COLUMN {col} text")
                            else:
                                cur.execute(f"ALTER TABLE {table_name} ADD COLUMN {col} text")
                            conn.commit()
                            print(f"[+] Added '{col}' to {table_name}")
                        except Exception as e:
                            print(f"[-] Error adding {col}: {e}")
            except Exception as e:
                print(f"[-] Error checking {table_name}: {e}")
        
        conn.close()
        print("[OK] Schema fix completed successfully")
        return True
        
    except Exception as e:
        print(f"[-] Error: {e}")
        return False

if __name__ == '__main__':
    print("=" * 60)
    print("SocialFish Database Schema Fix")
    print("=" * 60)
    fix_templates_table()
    print("=" * 60)
