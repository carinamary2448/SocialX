#!/usr/bin/env python3
"""
Automated Browser Testing - End-to-End Phishing Campaign Flow
Automates real browser interactions: visit lure -> submit credentials -> verify capture
"""

import subprocess
import time
import sqlite3
import requests
import json
from datetime import datetime

# Check for Selenium
try:
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    SELENIUM_AVAILABLE = True
except ImportError:
    SELENIUM_AVAILABLE = False
    print("[*] Selenium not available. Install with: pip install selenium")

BASE = "http://127.0.0.1:5000"

def get_cred_count():
    """Get current credential count"""
    try:
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM creds")
        count = cursor.fetchone()[0]
        conn.close()
        return count
    except:
        return 0

def get_latest_cred():
    """Get most recently captured credential"""
    try:
        conn = sqlite3.connect('database.db')
        cursor = conn.cursor()
        cursor.execute("""
            SELECT id, email, username, password, rip, browser, pdate 
            FROM creds ORDER BY id DESC LIMIT 1
        """)
        row = cursor.fetchone()
        conn.close()
        return row
    except:
        return None

def generate_lure():
    """Generate a test lure URL"""
    print("\n[*] Generating test lure campaign...")
    try:
        data = {
            "template_id": 1,
            "target_url": "https://example.com",
            "campaign_name": f"Browser_Test_{datetime.now().strftime('%H%M%S')}"
        }
        resp = requests.post(f"{BASE}/api/generate-lure", json=data, timeout=5)
        if resp.status_code != 200:
            print(f"[!] Lure generation returned {resp.status_code}")
            return None
        
        # Try parsing as JSON, otherwise extract from HTML
        try:
            result = resp.json()
            lure_url = result.get('lure_url')
            lure_hash = result.get('lure_hash')
        except:
            # Response was HTML, extract from database instead
            conn = sqlite3.connect('database.db')
            cursor = conn.cursor()
            cursor.execute("SELECT lure_hash, full_url FROM lure_urls ORDER BY id DESC LIMIT 1")
            row = cursor.fetchone()
            conn.close()
            if row:
                lure_hash, lure_url = row
            else:
                print("[!] Could not get lure URL")
                return None
        
        lure_url = f"{BASE}/capture/{lure_hash}"
        print(f"[+] Lure generated: {lure_url}")
        return lure_url
    except Exception as e:
        print(f"[!] Error: {e}")
        return None

def test_with_selenium(lure_url):
    """Test using Selenium WebDriver"""
    if not SELENIUM_AVAILABLE:
        print("[!] Selenium not installed")
        return False
    
    print("\n[*] Testing with Selenium WebDriver...")
    print(f"[*] Opening lure: {lure_url}")
    
    try:
        # Options for Chrome
        options = webdriver.ChromeOptions()
        options.add_argument('--no-sandbox')
        options.add_argument('--disable-dev-shm-usage')
        
        # Start Chrome driver
        driver = webdriver.Chrome(options=options)
        
        # Record count before
        before = get_cred_count()
        print(f"[*] Credentials in DB before: {before}")
        
        # Open lure page
        driver.get(lure_url)
        print(f"[+] Page loaded in browser")
        
        # Wait for form to load
        time.sleep(2)
        
        # Find and fill email field
        print("[*] Filling form fields...")
        email_input = driver.find_element(By.NAME, "email")
        email_input.send_keys("browser_test@example.com")
        print("[+] Email entered: browser_test@example.com")
        
        # Find and fill password field
        password_input = driver.find_element(By.NAME, "password")
        password_input.send_keys("browser_password_123")
        print("[+] Password entered: browser_password_123")
        
        # Submit form
        print("[*] Submitting form...")
        submit_button = driver.find_element(By.TAG_NAME, "button")
        submit_button.click()
        
        # Wait for submission to process
        time.sleep(2)
        
        # Check if credentials were captured
        after = get_cred_count()
        print(f"[*] Credentials in DB after: {after}")
        
        if after > before:
            print(f"[+] NEW CREDENTIAL CAPTURED! ({after - before} new)")
            
            latest = get_latest_cred()
            if latest:
                cred_id, email, username, password, rip, browser, pdate = latest
                print(f"\n[+] CAPTURED DATA:")
                print(f"    ID: {cred_id}")
                print(f"    Email: {email}")
                print(f"    Username: {username}")
                print(f"    Password: {password}")
                print(f"    Victim IP: {rip}")
                print(f"    Browser: {browser}")
                print(f"    Date: {pdate}")
        else:
            print("[!] No new credentials captured")
        
        driver.quit()
        return after > before
        
    except Exception as e:
        print(f"[!] Selenium error: {e}")
        import traceback
        traceback.print_exc()
        return False

def test_with_requests(lure_url):
    """Test form submission with requests library"""
    print("\n[*] Testing with requests library (simulated browser)...")
    print(f"[*] URL: {lure_url}")
    
    # Get the lure hash
    lure_hash = lure_url.split('/capture/')[-1]
    
    # Record count before
    before = get_cred_count()
    print(f"[*] Credentials in DB before: {before}")
    
    # Prepare form data (simulating browser form submission)
    form_data = {
        "email": "requests_test@example.com",
        "password": "requests_password_xyz"
    }
    
    print("[*] Submitting form data...")
    try:
        response = requests.post(
            lure_url,
            data=form_data,
            headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Referer': BASE
            },
            timeout=5,
            allow_redirects=True
        )
        print(f"[+] Form submitted (Response: {response.status_code})")
        
        # Wait for webhook to process
        time.sleep(1)
        
        # Check if captured
        after = get_cred_count()
        print(f"[*] Credentials in DB after: {after}")
        
        if after > before:
            print(f"[+] NEW CREDENTIAL CAPTURED! ({after - before} new)")
            
            latest = get_latest_cred()
            if latest:
                cred_id, email, username, password, rip, browser, pdate = latest
                print(f"\n[+] CAPTURED DATA:")
                print(f"    ID: {cred_id}")
                print(f"    Email: {email}")
                print(f"    Username: {username}")
                print(f"    Password: {password}")
                print(f"    Victim IP: {rip}")
                print(f"    Browser: {browser}")
                print(f"    Date: {pdate}")
            return True
        else:
            print("[!] No new credentials captured")
            return False
            
    except Exception as e:
        print(f"[!] Error: {e}")
        return False

def main():
    print("\n" + "="*80)
    print("AUTOMATED BROWSER TESTING - END-TO-END PHISHING WORKFLOW")
    print("="*80)
    
    # Check server
    print("\n[*] Checking if server is running...")
    try:
        resp = requests.get(f"{BASE}/", timeout=3)
        print("[+] Server is running")
    except:
        print("[!] Server not running. Start with: python SocialFish.py admin password")
        return
    
    # Generate lure
    lure_url = generate_lure()
    if not lure_url:
        print("[!] Failed to generate lure")
        return
    
    print("\n" + "-"*80)
    print("AUTOMATED BROWSER TESTS")
    print("-"*80)
    
    # Test with requests first (always works)
    requests_result = test_with_requests(lure_url)
    
    # Test with Selenium if available
    selenium_result = False
    if SELENIUM_AVAILABLE:
        print("\n" + "-"*80)
        selenium_result = test_with_selenium(lure_url)
    else:
        print("\n[*] Selenium not installed - skipping browser automation")
        print("    Install with: pip install selenium")
        print("    Then download ChromeDriver from: https://chromedriver.chromium.org/")
    
    # Summary
    print("\n" + "="*80)
    print("TEST SUMMARY")
    print("="*80)
    print(f"Requests Test (simulated): {'PASS' if requests_result else 'FAIL'}")
    print(f"Selenium Test (real browser): {'PASS' if selenium_result else 'SKIP/FAIL'}")
    
    # Final statistics
    total_creds = get_cred_count()
    print(f"\nTotal credentials in database: {total_creds}")
    
    print("\n[+] Automated browser testing complete!")
    print("[*] Check database: sqlite3 database.db \"SELECT * FROM creds;\"")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n[*] Test interrupted")
