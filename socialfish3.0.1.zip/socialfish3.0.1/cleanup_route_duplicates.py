#!/usr/bin/env python3
"""Remove duplicate route definitions in SocialFish.py"""

with open('SocialFish.py', 'r') as f:
    lines = f.readlines()

print(f"Original file: {len(lines)} lines")

# Remove lines from BOTTOM TO TOP to avoid index shifting

# Identify ranges to remove (0-based indexing):
# Lines 1809-1816: Orphaned MOBILE API @app.route decorators
# Lines 1817-2168: First full duplicate of selenium/tabjack/file-upload/stealth/captcha/mock/recording/recording_studio/templates/lures/sessions
# Lines 2169-2536: Second full duplicate
# Lines 2537-2846: Third full duplicate

remove_ranges = [
    (2536, 2846),  # 0-based: lines 2537-2846 (third duplicate)
    (2168, 2536),  # 0-based: lines 2169-2536 (second duplicate)
    (1816, 2168),  # 0-based: lines 1817-2168 (first duplicate)
    (1808, 1816),  # 0-based: lines 1809-1816 (orphaned decorators)
]

# Build set of indices to remove
remove_indices = set()
for start, end in remove_ranges:
    for i in range(start, end):
        if i < len(lines):
            remove_indices.add(i)
            
print(f"Removal ranges: {remove_ranges}")
print(f"Total indices to remove: {len(remove_indices)}")

# Create new file content
output_lines = []
for i, line in enumerate(lines):
    if i not in remove_indices:
        output_lines.append(line)

# Write back
with open('SocialFish.py', 'w') as f:
    f.writelines(output_lines)

print(f"New file: {len(output_lines)} lines")
print(f"Lines removed: {len(lines) - len(output_lines)}")
print("[OK] Cleanup complete!")

