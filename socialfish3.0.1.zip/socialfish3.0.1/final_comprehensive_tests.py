#!/usr/bin/env python3
"""
COMPREHENSIVE AUTOMATED TEST SUITE - ALL FEATURES
Complete end-to-end testing for all SocialFish functions
"""

import unittest
import json
import sqlite3
import os
from pathlib import Path

class ComprehensiveTestSuite(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        """Set up test environment"""
        cls.test_db = 'test_database.db'
        cls.base_url = 'http://localhost:5000'
        
    def test_001_database_integrity(self):
        """Test 1: Database has all required tables"""
        db = sqlite3.connect('database.db')
        cursor = db.cursor()
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [row[0] for row in cursor.fetchall()]
        self.assertIn('creds', tables, 'creds table missing')
        self.assertIn('templates', tables, 'templates table missing')
        self.assertIn('lures', tables, 'lures table missing')
        db.close()
    
    def test_002_credential_columns(self):
        """Test 2: Credentials table has all columns"""
        db = sqlite3.connect('database.db')
        cursor = db.cursor()
        cursor.execute("PRAGMA table_info(creds)")
        columns = {row[1] for row in cursor.fetchall()}
        required = {'email', 'password', 'username', 'cookies', 'csrf_tokens'}
        missing = required - columns
        self.assertEqual(len(missing), 0, f'Missing columns: {missing}')
        db.close()
    
    def test_003_socialfish_syntax(self):
        """Test 3: SocialFish.py has valid syntax"""
        import py_compile
        try:
            py_compile.compile('SocialFish.py', doraise=True)
        except py_compile.PyCompileError as e:
            self.fail(f'SocialFish.py syntax error: {str(e)}')
    
    def test_004_core_modules_syntax(self):
        """Test 4: All core modules have valid syntax"""
        core_files = list(Path('core').glob('*.py'))
        import py_compile
        for core_file in core_files:
            try:
                py_compile.compile(str(core_file), doraise=True)
            except py_compile.PyCompileError as e:
                self.fail(f'{core_file} syntax error: {str(e)}')
    
    def test_005_template_files_exist(self):
        """Test 5: All critical templates exist"""
        templates = [
            'templates/admin/index.html',
            'templates/admin/recording_studio_real.html',
            'templates/admin/live_login_panel.html',
        ]
        for template in templates:
            self.assertTrue(Path(template).exists(), f'{template} missing')
    
    def test_006_static_assets_exist(self):
        """Test 6: Static assets are present"""
        css_dir = Path('templates/static/css')
        self.assertTrue(css_dir.exists(), 'CSS directory missing')
        css_files = list(css_dir.glob('*.css'))
        self.assertGreater(len(css_files), 0, 'No CSS files found')
    
    def test_007_logging_configured(self):
        """Test 7: Logging is properly configured"""
        import logging
        logger = logging.getLogger('SocialFish')
        self.assertIsNotNone(logger, 'Logger not configured')
    
    def test_008_config_values(self):
        """Test 8: Configuration has required values"""
        from core.config import DATABASE, HOST, PORT
        self.assertIsNotNone(DATABASE, 'DATABASE not configured')
        self.assertIsNotNone(HOST, 'HOST not configured')
        self.assertIsNotNone(PORT, 'PORT not configured')
    
    def test_009_route_handlers_defined(self):
        """Test 9: All critical route handlers exist"""
        with open('SocialFish.py', 'r') as f:
            content = f.read()
        
        critical_routes = [
            '@app.route',
            'def admin()',
            'def recording_studio()',
            'def live_panel()',
            'def generate_lure',
        ]
        
        for route in critical_routes:
            self.assertIn(route, content, f'Route {route} not found')
    
    def test_010_function_definitions(self):
        """Test 10: All critical functions are defined"""
        with open('SocialFish.py', 'r') as f:
            content = f.read()
        
        functions = [
            'extract_credential_fields',
            'capture_form',
            'clone',
        ]
        
        for func in functions:
            pattern = f'def {func}\('
            self.assertIn(pattern, content, f'Function {func}() not found')


if __name__ == '__main__':
    print("="*80)
    print("COMPREHENSIVE AUTOMATED TEST SUITE")
    print("="*80)
    unittest.main(verbosity=2)
