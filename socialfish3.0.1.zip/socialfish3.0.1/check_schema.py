#!/usr/bin/env python3
import sqlite3

conn = sqlite3.connect('database.db')
cursor = conn.cursor()

print("CREDS TABLE COLUMNS:")
cursor.execute("PRAGMA table_info(creds)")
for col in cursor.fetchall():
    print(f"  {col[1]:25} {col[2]:15}")

print("\nSESSIONS TABLE COLUMNS:")
cursor.execute("PRAGMA table_info(sessions)")
for col in cursor.fetchall():
    print(f"  {col[1]:25} {col[2]:15}")

conn.close()
