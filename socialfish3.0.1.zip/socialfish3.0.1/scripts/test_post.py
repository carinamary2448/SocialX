import requests
url = 'http://127.0.0.1:5000/capture/form'
payload = {'form_data': {'email':'attacker@example.com','password':'P@ssw0rd'}, 'page_url':'http://localhost/clone/test', 'clone_id':'test'}
resp = requests.post(url, json=payload)
print('STATUS', resp.status_code)
print(resp.text[:500])
