import urllib.request, urllib.parse, urllib.error
base='http://127.0.0.1:5000'
try:
    r = urllib.request.urlopen(base+'/')
    print('GET / ->', r.getcode())
except Exception as e:
    print('GET / error:', e)

# Test victim-facing /login POST (exempted)
try:
    data=urllib.parse.urlencode({'username':'attacker','password':'pw'}).encode()
    req=urllib.request.Request(base+'/login', data=data)
    resp=urllib.request.urlopen(req)
    print('POST /login ->', resp.getcode())
except Exception as e:
    print('POST /login error:', e)
